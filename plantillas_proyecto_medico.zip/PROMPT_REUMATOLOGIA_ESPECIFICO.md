# 🦴 REUMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/reumatologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Reumatología"
[NOMBRE_ESPECIALIDAD] → "Reumatología"
[COLOR_TEMA] → "amber-500"
```

### 🦴 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bone h-8 w-8 text-indigo-300">
    <path d="M17 10c.7-.7 1.69 0 2.5 0a2.5 2.5 0 1 0 0-5 .5.5 0 0 1-.5-.5 2.5 2.5 0 1 0-5 0c0 .81.7 1.8 0 2.5l-7 7c-.7.7-1.69 0-2.5 0a2.5 2.5 0 0 0 0 5c.28 0 .5.22.5.5a2.5 2.5 0 1 0 5 0c0-.81-.7-1.8 0-2.5Z"/>
</svg>
```

## 🏗️ Secciones Médicas Reumatológicas

### 1️⃣ Síntomas Articulares
- **Icono**: `lucide-bone` (amber-500)
- **Contenido**: Dolor, rigidez, inflamación, limitación funcional
- **Alertas**: Artritis aguda monoarticular, síntomas sistémicos

### 2️⃣ Exploración Articular Sistemática
- **Icono**: `lucide-search` (green-400)
- **Contenido**: Articulaciones grandes y pequeñas, deformidades
- **Alertas**: Deformidades articulares, artritis múltiple

### 3️⃣ Enfermedades Autoinmunes
- **Icono**: `lucide-shield-alert` (red-400)
- **Contenido**: ANA, anti-DNA, FR, anti-CCP, manifestaciones sistémicas
- **Alertas**: ANA positivo + síntomas, manifestaciones sistémicas

### 4️⃣ Escalas Reumatológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: DAS28, HAQ, BASDAI, actividad enfermedad
- **Escalas automáticas**: Cálculo automático DAS28

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkReumaAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas reumatológicas
    if (document.getElementById('artritis-monoarticular-aguda')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 ARTRITIS AGUDA MONOARTICULAR - Descartar séptica',
            color: 'red'
        });
    }
    
    if (document.getElementById('fiebre-artritis')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🌡️ FIEBRE + ARTRITIS - Evaluar enfermedad sistémica',
            color: 'orange'
        });
    }
    
    // Calcular escalas
    calculateDAS28();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateDAS28() {
    const articulacionesSensibles = document.getElementById('articulaciones-sensibles')?.value;
    const articulacionesInflamadas = document.getElementById('articulaciones-inflamadas')?.value;
    const vsg = document.getElementById('vsg')?.value;
    const evaluacionGlobal = document.getElementById('evaluacion-global-paciente')?.value;
    
    if (articulacionesSensibles && articulacionesInflamadas && vsg && evaluacionGlobal) {
        const das28 = 0.56 * Math.sqrt(articulacionesSensibles) + 
                      0.28 * Math.sqrt(articulacionesInflamadas) + 
                      0.70 * Math.log(vsg) + 
                      0.014 * evaluacionGlobal;
        
        let actividad = '';
        if (das28 < 2.6) actividad = 'Remisión';
        else if (das28 < 3.2) actividad = 'Actividad baja';
        else if (das28 <= 5.1) actividad = 'Actividad moderada';
        else actividad = 'Actividad alta';
        
        escalas.push({
            nombre: 'DAS28',
            valor: Math.round(das28 * 100) / 100,
            interpretacion: actividad,
            color: das28 < 2.6 ? 'green' : das28 < 3.2 ? 'yellow' : das28 <= 5.1 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkReumaAlertsAndScales;
```
