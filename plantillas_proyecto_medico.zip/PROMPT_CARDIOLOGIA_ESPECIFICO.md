# ❤️ CARDIOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/cardiologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Cardiología"
[NOMBRE_ESPECIALIDAD] → "Cardiología"
[COLOR_TEMA] → "red-500"
```

### ❤️ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-heart h-8 w-8 text-indigo-300">
    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>
</svg>
```

## 🏗️ Secciones Médicas Cardiológicas

### 1️⃣ Síntomas Cardiovasculares
```html
<div class="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl overflow-hidden">
    <div class="p-4 cursor-pointer hover:bg-white/5 transition-colors" onclick="toggleSection('sintomas')">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5 text-red-500">
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>
                </svg>
                <div>
                    <h3 class="font-semibold text-white">Síntomas Cardiovasculares</h3>
                    <p class="text-sm text-white/70">Dolor torácico, disnea y palpitaciones</p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <div class="flex items-center gap-2">
                    <div class="w-16 h-2 bg-white/20 rounded-full overflow-hidden">
                        <div class="h-full bg-gradient-to-r from-indigo-400 to-blue-500 transition-all" id="progress-sintomas" style="width: 0%;"></div>
                    </div>
                    <span class="text-xs text-white/70" id="percent-sintomas">0%</span>
                </div>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5 text-white/70" id="chevron-sintomas">
                    <path d="m18 15-6-6-6 6"></path>
                </svg>
            </div>
        </div>
    </div>
    <div id="content-sintomas" style="height: auto; opacity: 1;">
        <div class="p-6 border-t border-white/10 bg-white/5">
            <div class="space-y-6">
                <!-- Dolor Torácico -->
                <div>
                    <label class="text-white font-semibold text-lg mb-3 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4 text-red-400">
                            <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>
                        </svg>
                        Dolor Torácico
                    </label>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-anginoso" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-anginoso" class="text-white text-sm cursor-pointer">Dolor anginoso típico</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-atipico" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-atipico" class="text-white text-sm cursor-pointer">Dolor torácico atípico</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-opresivo" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-opresivo" class="text-white text-sm cursor-pointer">Dolor opresivo</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-punzante" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-punzante" class="text-white text-sm cursor-pointer">Dolor punzante</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-esfuerzo" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-esfuerzo" class="text-white text-sm cursor-pointer">Dolor con esfuerzo</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dolor-reposo" class="h-4 w-4 rounded border-white/20">
                            <label for="dolor-reposo" class="text-white text-sm cursor-pointer">Dolor en reposo</label>
                        </div>
                    </div>
                </div>
                
                <div class="border-t border-white/20"></div>
                
                <!-- Disnea -->
                <div>
                    <label class="text-white font-semibold text-lg mb-3 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4 text-blue-400">
                            <path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/>
                            <path d="M9.6 4.6A2 2 0 1 1 11 8H2"/>
                            <path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>
                        </svg>
                        Disnea
                    </label>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="disnea-esfuerzo" class="h-4 w-4 rounded border-white/20">
                            <label for="disnea-esfuerzo" class="text-white text-sm cursor-pointer">Disnea de esfuerzo</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="disnea-reposo" class="h-4 w-4 rounded border-white/20">
                            <label for="disnea-reposo" class="text-white text-sm cursor-pointer">Disnea de reposo</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="ortopnea" class="h-4 w-4 rounded border-white/20">
                            <label for="ortopnea" class="text-white text-sm cursor-pointer">Ortopnea</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="dnp" class="h-4 w-4 rounded border-white/20">
                            <label for="dnp" class="text-white text-sm cursor-pointer">Disnea paroxística nocturna</label>
                        </div>
                    </div>
                </div>
                
                <div class="border-t border-white/20"></div>
                
                <!-- Palpitaciones -->
                <div>
                    <label class="text-white font-semibold text-lg mb-3 flex items-center gap-2">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-4 h-4 text-yellow-400">
                            <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>
                        </svg>
                        Palpitaciones
                    </label>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="palpitaciones-regulares" class="h-4 w-4 rounded border-white/20">
                            <label for="palpitaciones-regulares" class="text-white text-sm cursor-pointer">Palpitaciones regulares</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="palpitaciones-irregulares" class="h-4 w-4 rounded border-white/20">
                            <label for="palpitaciones-irregulares" class="text-white text-sm cursor-pointer">Palpitaciones irregulares</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="taquicardia" class="h-4 w-4 rounded border-white/20">
                            <label for="taquicardia" class="text-white text-sm cursor-pointer">Episodios de taquicardia</label>
                        </div>
                        <div class="flex items-center space-x-2 p-2 rounded-lg hover:bg-white/5">
                            <input type="checkbox" id="sincope" class="h-4 w-4 rounded border-white/20">
                            <label for="sincope" class="text-white text-sm cursor-pointer">Síncope o presíncope</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
```

### 2️⃣ Factores de Riesgo Cardiovascular
```html
<!-- Similar estructura para factores de riesgo -->
<!-- CONSERVAR TODA LA INFORMACIÓN MÉDICA ORIGINAL -->
```

### 3️⃣ Exploración Física Cardiovascular
```html
<!-- Similar estructura para exploración física -->
<!-- CONSERVAR TODA LA INFORMACIÓN MÉDICA ORIGINAL -->
```

### 4️⃣ Escalas Cardiológicas
```html
<!-- Similar estructura para escalas cardiológicas -->
<!-- Incluir: CHADS2, HAS-BLED, TIMI, GRACE, Killip -->
<!-- CONSERVAR TODA LA INFORMACIÓN MÉDICA ORIGINAL -->
```

### 5️⃣ Plan de Manejo Cardiológico
```html
<!-- Similar estructura para plan de manejo -->
<!-- CONSERVAR TODA LA INFORMACIÓN MÉDICA ORIGINAL -->
```

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium" id="sintomas-status">Síntomas CV</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium" id="factores-status">F. Riesgo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium" id="exploracion-status">Exploración</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium" id="escalas-status">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium" id="manejo-status">Manejo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'factores', 'exploracion', 'escalas', 'manejo'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkCardiacAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas
    if (document.getElementById('dolor-anginoso')?.checked && 
        document.getElementById('dolor-esfuerzo')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ SOSPECHA ANGINA ESTABLE - Evaluación cardiológica urgente',
            color: 'red'
        });
    }
    
    if (document.getElementById('sincope')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🚨 SÍNCOPE - Descartar arritmias malignas',
            color: 'orange'
        });
    }
    
    // Calcular escalas automáticamente
    // CHADS2, HAS-BLED, etc.
    
    updateAlertsUI();
    updateEscalasUI();
}

checkAlertsAndScales = checkCardiacAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información cardiológica** preservada
- **Escalas CHADS2, HAS-BLED, TIMI, GRACE, Killip** funcionando
- **Alertas dinámicas** para situaciones críticas cardíacas
- **Progreso automático** por secciones
