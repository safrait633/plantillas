# 💧 UROLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/urologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Urología"
[NOMBRE_ESPECIALIDAD] → "Urología"
[COLOR_TEMA] → "blue-600"
```

### 💧 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-droplets h-8 w-8 text-indigo-300">
    <path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"/>
    <path d="M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2.04 4.6 4.14 5.78s3.86 2.41 3.86 4.78a7.3 7.3 0 0 1-7.3 7.3"/>
</svg>
```

## 🏗️ Secciones Médicas Urológicas

### 1️⃣ Síntomas Urológicos
- **Icono**: `lucide-droplets` (blue-600)
- **Contenido**: Disuria, polaquiuria, hematuria, dolor lumbar, incontinencia
- **Alertas**: Hematuria macroscópica, anuria, dolor renal cólico

### 2️⃣ Síntomas Prostáticos (IPSS)
- **Icono**: `lucide-target` (red-500)
- **Contenido**: Chorro débil, goteo, urgencia, nocturia, vaciado incompleto
- **Alertas**: Retención urinaria aguda, PSA muy elevado

### 3️⃣ Exploración Urológica
- **Icono**: `lucide-search` (green-400)
- **Contenido**: Palpación renal, tacto rectal, genitales externos
- **Alertas**: Masa renal palpable, próstata indurada

### 4️⃣ Función Renal y Urinaria
- **Icono**: `lucide-activity` (yellow-400)
- **Contenido**: Creatinina, BUN, clearance, sedimento urinario
- **Alertas**: Insuficiencia renal aguda, proteinuria severa

### 5️⃣ Escalas Urológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: IPSS, PSA, función renal estimada, riesgo prostático
- **Escalas automáticas**: Cálculo automático IPSS y riesgo

### 6️⃣ Plan de Manejo Urológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, ecografía, cistoscopia, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Próstata</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Exploración</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Función</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Manejo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'prostata', 'exploracion', 'funcion', 'escalas', 'manejo'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkUroAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas urológicas
    if (document.getElementById('hematuria-macroscopica')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 HEMATURIA MACROSCÓPICA - Descartar malignidad',
            color: 'red'
        });
    }
    
    if (document.getElementById('retencion-urinaria')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ RETENCIÓN URINARIA - Sondaje vesical urgente',
            color: 'red'
        });
    }
    
    if (document.getElementById('dolor-renal-colico')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '💎 CÓLICO RENAL - Analgesia y descartar litiasis',
            color: 'orange'
        });
    }
    
    const psa = document.getElementById('psa-valor')?.value;
    if (psa && psa > 10) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔴 PSA ELEVADO - Valorar biopsia prostática',
            color: 'orange'
        });
    }
    
    // Calcular escalas urológicas automáticamente
    calculateIPSS();
    calculatePSARisk();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateIPSS() {
    // Calcular IPSS (International Prostate Symptom Score)
    let ipssScore = 0;
    
    // Sumar puntuaciones de síntomas prostáticos
    const sintomas = ['vaciado-incompleto', 'frecuencia', 'intermitencia', 'urgencia', 'chorro-debil', 'esfuerzo', 'nocturia'];
    
    sintomas.forEach(sintoma => {
        const valor = document.getElementById(`ipss-${sintoma}`)?.value;
        if (valor) ipssScore += parseInt(valor);
    });
    
    if (ipssScore > 0) {
        let severidad = '';
        if (ipssScore <= 7) severidad = 'Síntomas leves';
        else if (ipssScore <= 19) severidad = 'Síntomas moderados';
        else severidad = 'Síntomas severos';
        
        escalas.push({
            nombre: 'IPSS',
            valor: ipssScore,
            interpretacion: severidad,
            color: ipssScore <= 7 ? 'green' : ipssScore <= 19 ? 'orange' : 'red'
        });
    }
}

function calculatePSARisk() {
    const psa = document.getElementById('psa-valor')?.value;
    const edad = document.getElementById('edad-paciente')?.value;
    
    if (psa && edad) {
        let riesgo = '';
        let color = 'green';
        
        if (edad < 50 && psa > 2.5) {
            riesgo = 'PSA elevado para la edad';
            color = 'orange';
        } else if (edad >= 50 && edad < 60 && psa > 3) {
            riesgo = 'PSA elevado para la edad';
            color = 'orange';
        } else if (edad >= 60 && edad < 70 && psa > 4) {
            riesgo = 'PSA elevado para la edad';
            color = 'orange';
        } else if (edad >= 70 && psa > 5) {
            riesgo = 'PSA elevado para la edad';
            color = 'orange';
        } else {
            riesgo = 'PSA normal para la edad';
        }
        
        if (psa > 10) {
            riesgo = 'PSA muy elevado - Alto riesgo';
            color = 'red';
        }
        
        escalas.push({
            nombre: 'Riesgo PSA',
            valor: `${psa} ng/ml`,
            interpretacion: riesgo,
            color: color
        });
    }
}

checkAlertsAndScales = checkUroAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información urológica** preservada
- **Escalas IPSS, PSA, función renal** funcionando
- **Alertas dinámicas** para emergencias urológicas
- **Progreso automático** por secciones
