# 🏥 GASTROENTEROLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/gastroenterologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Gastroenterología"
[COLOR_TEMA] → "green-500"
```

## 🏥 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pill h-8 w-8 text-indigo-300">
    <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/>
    <path d="m8.5 8.5 7 7"/>
</svg>
```

## 🏗️ Secciones: 
1. Síntomas Digestivos (dolor abdominal, náuseas, diarrea)
2. Factores de Riesgo GI (alcohol, medicamentos, infecciones)  
3. Exploración Abdominal (inspección, palpación, auscultación)
4. Escalas GI (Child-Pugh, MELD, Rome IV)
5. Plan de Manejo

## ⚙️ Alertas Críticas:
- Dolor abdominal agudo severo
- Hemorragia digestiva
- Ictericia + dolor
- Masa abdominal palpable

---

# 💧 UROLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/urologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Urología"
[COLOR_TEMA] → "blue-600"
```

## 💧 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-droplets h-8 w-8 text-indigo-300">
    <path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"/>
    <path d="M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2.04 4.6 4.14 5.78s3.86 2.41 3.86 4.78a7.3 7.3 0 0 1-7.3 7.3"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Urológicos (disuria, hematuria, dolor lumbar)
2. Síntomas Prostáticos (IPSS)
3. Exploración Urológica
4. Escalas (IPSS, PSA, función renal)
5. Plan de Manejo

## ⚙️ Alertas Críticas:
- Hematuria macroscópica
- Retención urinaria aguda
- Dolor renal cólico
- PSA elevado + síntomas

---

# 👁️ OFTALMOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/oftalmologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Oftalmología"
[COLOR_TEMA] → "purple-500"
```

## 👁️ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye h-8 w-8 text-indigo-300">
    <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/>
    <circle cx="12" cy="12" r="3"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Oculares (visión, dolor, enrojecimiento)
2. Agudeza Visual y Refracción
3. Exploración Ocular (pupilas, fundoscopia)
4. Presión Intraocular
5. Plan Oftalmológico

## ⚙️ Alertas Críticas:
- Pérdida visual súbita
- Dolor ocular severo + náuseas
- Destellos + moscas volantes
- Halos + visión borrosa

---

# 👂 OTORRINOLARINGOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/otorrinolaringologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Otorrinolaringología"
[COLOR_TEMA] → "orange-500"
```

## 👂 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-ear h-8 w-8 text-indigo-300">
    <path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"/>
    <path d="M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas ORL (hipoacusia, acúfenos, vértigo, dolor)
2. Exploración Otológica
3. Exploración Nasal y Faríngea
4. Audiometría y Vestibular
5. Plan ORL

## ⚙️ Alertas Críticas:
- Hipoacusia súbita
- Vértigo severo + náuseas
- Disfagia + odinofagia
- Epistaxis recurrente

---

# 🛡️ DERMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/dermatologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Dermatología"
[COLOR_TEMA] → "pink-500"
```

## 🛡️ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check h-8 w-8 text-indigo-300">
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
    <path d="m9 12 2 2 4-4"/>
</svg>
```

## 🏗️ Secciones:
1. Lesiones Cutáneas (tipo, distribución, características)
2. Exploración Dermatológica Sistemática
3. Dermatoscopia
4. Escalas (ABCDE, PASI, Breslow)
5. Plan Dermatológico

## ⚙️ Alertas Críticas:
- Melanoma sospechoso (ABCDE)
- Lesión ulcerada sangrante
- Exantema + fiebre
- Cambios en nevus

---

# 🔄 INSTRUCCIONES DE USO

## Para cada especialidad:

1. **Tomar PROMPT_GENERAL_ADAPTACION.md** como base
2. **Aplicar especificaciones** de la especialidad correspondiente
3. **Conservar TODA la información médica** del archivo original
4. **Adaptar secciones** usando la estructura de template
5. **Implementar alertas y escalas** específicas
6. **Verificar funcionalidad completa**

## ✅ Resultado: Interfaz 100% idéntica + información médica preservada
