# 🩸 HEMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/hematologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Hematología"
[NOMBRE_ESPECIALIDAD] → "Hematología"
[COLOR_TEMA] → "red-600"
```

### 🩸 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-droplet h-8 w-8 text-indigo-300">
    <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>
</svg>
```

## 🏗️ Secciones Médicas Hematológicas

### 1️⃣ Síntomas Hematológicos
- **Icono**: `lucide-droplet` (red-600)
- **Contenido**: Astenia, palidez, equimosis, petequias, sangrado
- **Alertas**: Pancitopenia, sangrado activo + coagulopatía

### 2️⃣ Adenopatías y Esplenomegalia
- **Icono**: `lucide-circle-dot` (purple-400)
- **Contenido**: Adenopatías localizadas/generalizadas, hepatoesplenomegalia
- **Alertas**: Adenopatías generalizadas, esplenomegalia masiva

### 3️⃣ Hemograma y Coagulación
- **Icono**: `lucide-activity` (blue-400)
- **Contenido**: Hemoglobina, leucocitos, plaquetas, TP, TTPA
- **Alertas**: Blastos en sangre periférica, coagulopatía severa

### 4️⃣ Escalas Hematológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: Wells TEP, HAS-BLED, riesgo trombótico
- **Escalas automáticas**: Cálculo automático Wells

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkHematoAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas hematológicas
    const hemoglobina = document.getElementById('hemoglobina')?.value;
    const leucocitos = document.getElementById('leucocitos')?.value;
    const plaquetas = document.getElementById('plaquetas')?.value;
    
    if (hemoglobina && hemoglobina < 7) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 ANEMIA SEVERA - Considerar transfusión',
            color: 'red'
        });
    }
    
    if (plaquetas && plaquetas < 20000) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🩸 TROMBOCITOPENIA SEVERA - Riesgo sangrado',
            color: 'red'
        });
    }
    
    if (document.getElementById('blastos-sangre')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ BLASTOS EN SANGRE - Descartar leucemia aguda',
            color: 'red'
        });
    }
    
    // Calcular escalas
    calculateWellsTEP();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateWellsTEP() {
    let wellsScore = 0;
    
    if (document.getElementById('cancer-activo')?.checked) wellsScore += 1;
    if (document.getElementById('inmovilizacion')?.checked) wellsScore += 1.5;
    if (document.getElementById('cirugia-reciente')?.checked) wellsScore += 1.5;
    if (document.getElementById('edema-unilateral')?.checked) wellsScore += 1;
    if (document.getElementById('hemoptisis')?.checked) wellsScore += 1;
    if (document.getElementById('taquicardia')?.checked) wellsScore += 1.5;
    
    if (wellsScore > 0) {
        let probabilidad = '';
        if (wellsScore < 2) probabilidad = 'Baja probabilidad';
        else if (wellsScore <= 6) probabilidad = 'Probabilidad intermedia';
        else probabilidad = 'Alta probabilidad';
        
        escalas.push({
            nombre: 'Wells TEP',
            valor: wellsScore,
            interpretacion: probabilidad,
            color: wellsScore < 2 ? 'green' : wellsScore <= 6 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkHematoAlertsAndScales;
```
