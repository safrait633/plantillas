# ⚡ ENDOCRINOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/endocrinologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Endocrinología"
[NOMBRE_ESPECIALIDAD] → "Endocrinología"
[COLOR_TEMA] → "yellow-500"
```

### ⚡ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-activity h-8 w-8 text-indigo-300">
    <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>
</svg>
```

## 🏗️ Secciones Médicas Endocrinológicas

### 1️⃣ Síntomas Endocrinos
- **Icono**: `lucide-activity` (yellow-500)
- **Contenido**: Poliuria, polidipsia, pérdida peso, fatiga, palpitaciones
- **Alertas**: Cetoacidosis diabética, crisis tirotóxica

### 2️⃣ Diabetes y Metabolismo
- **Icono**: `lucide-droplet` (red-400)
- **Contenido**: Glucemia, HbA1c, síntomas diabéticos, complicaciones
- **Alertas**: Hipoglucemia severa, hiperglucemia extrema

### 3️⃣ Tiroides y Paratiroides
- **Icono**: `lucide-circle` (blue-400)
- **Contenido**: TSH, T4, T3, síntomas hiper/hipotiroidismo, bocio
- **Alertas**: TSH suprimida + síntomas, mixedema

### 4️⃣ Glándulas Suprarrenales
- **Icono**: `lucide-triangle` (purple-400)
- **Contenido**: Cortisol, aldosterona, síntomas Cushing/Addison
- **Alertas**: Crisis suprarrenal, hipertensión severa

### 5️⃣ Escalas Endocrinológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: HOMA-IR, riesgo cardiovascular, clasificación diabetes
- **Escalas automáticas**: Cálculo automático HOMA-IR

### 6️⃣ Plan Endocrinológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, pruebas hormonales, tratamiento

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkEndocrinoAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas endocrinológicas
    const glucemia = document.getElementById('glucemia')?.value;
    if (glucemia && glucemia > 400) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 HIPERGLUCEMIA EXTREMA - Descartar cetoacidosis',
            color: 'red'
        });
    }
    
    if (glucemia && glucemia < 50) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ HIPOGLUCEMIA SEVERA - Tratamiento inmediato',
            color: 'red'
        });
    }
    
    const tsh = document.getElementById('tsh')?.value;
    if (tsh && tsh < 0.1 && document.getElementById('síntomas-hipertiroidismo')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🔥 CRISIS TIROTÓXICA - Tratamiento urgente',
            color: 'red'
        });
    }
    
    // Calcular escalas
    calculateHOMAIR();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateHOMAIR() {
    const glucemia = document.getElementById('glucemia-ayunas')?.value;
    const insulina = document.getElementById('insulina-ayunas')?.value;
    
    if (glucemia && insulina) {
        const homa = (glucemia * insulina) / 22.5;
        let interpretacion = '';
        
        if (homa < 2.5) interpretacion = 'Sensibilidad normal';
        else if (homa < 4) interpretacion = 'Resistencia moderada';
        else interpretacion = 'Resistencia severa';
        
        escalas.push({
            nombre: 'HOMA-IR',
            valor: Math.round(homa * 100) / 100,
            interpretacion: interpretacion,
            color: homa < 2.5 ? 'green' : homa < 4 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkEndocrinoAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Información endocrinológica** completa preservada
- **Escalas HOMA-IR, riesgo diabético** funcionando
- **Alertas para emergencias endocrinas**
