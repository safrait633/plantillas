# 🧠 NEUROLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/neurologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Neurología"
[NOMBRE_ESPECIALIDAD] → "Neurología"
[COLOR_TEMA] → "red-500"
```

### 🧠 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brain h-8 w-8 text-indigo-300">
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/>
    <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
    <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
    <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
    <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
    <path d="M6 18a4 4 0 0 1-1.967-.516"/>
    <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
</svg>
```

## 🏗️ Secciones Médicas Neurológicas

### 1️⃣ Síntomas Neurológicos
- **Icono**: `lucide-brain` (red-500)
- **Contenido**: Cefalea, mareos, alteraciones cognitivas, crisis epilépticas
- **Alertas**: Cefalea en trueno, alteración de conciencia aguda

### 2️⃣ Estado Mental y Cognitivo
- **Icono**: `lucide-focus` (yellow-400)
- **Contenido**: Orientación, memoria, atención, funciones ejecutivas
- **Alertas**: Deterioro cognitivo agudo, confusión

### 3️⃣ Pares Craneales
- **Icono**: `lucide-eye` (blue-400)
- **Contenido**: Examen sistemático de pares craneales I-XII
- **Alertas**: Diplopia, ptosis, alteraciones pupilares

### 4️⃣ Sistema Motor
- **Icono**: `lucide-activity` (green-400)
- **Contenido**: Fuerza, tono muscular, reflejos, coordinación
- **Alertas**: Hemiparesia aguda, fasciculaciones

### 5️⃣ Sistema Sensorial
- **Icono**: `lucide-zap` (purple-400)
- **Contenido**: Sensibilidad táctil, dolorosa, vibratoria, posicional
- **Alertas**: Pérdida sensorial aguda

### 6️⃣ Escalas Neurológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: NIHSS, Glasgow, Rankin modificado, Mini-Mental
- **Escalas automáticas**: Cálculo en tiempo real

### 7️⃣ Plan de Manejo Neurológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, pruebas complementarias, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Estado Mental</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Pares Craneales</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Motor</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Sensorial</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'mental', 'craneales', 'motor', 'sensorial', 'escalas', 'manejo'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkNeurologicAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas neurológicas
    if (document.getElementById('cefalea-trueno')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 CEFALEA EN TRUENO - Descartar HSA inmediatamente',
            color: 'red'
        });
    }
    
    if (document.getElementById('hemiparesia-aguda')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ HEMIPARESIA AGUDA - Protocolo ICTUS',
            color: 'red'
        });
    }
    
    if (document.getElementById('confusion-aguda')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔍 CONFUSIÓN AGUDA - Descartar delirium/encefalitis',
            color: 'orange'
        });
    }
    
    // Calcular escalas neurológicas automáticamente
    calculateNIHSS();
    calculateGlasgow();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateNIHSS() {
    // Lógica específica para calcular NIHSS
    let nihssScore = 0;
    // ... cálculo basado en checkboxes seleccionados
    
    if (nihssScore > 0) {
        escalas.push({
            nombre: 'NIHSS',
            valor: nihssScore,
            interpretacion: nihssScore > 15 ? 'Ictus severo' : nihssScore > 5 ? 'Ictus moderado' : 'Ictus leve',
            color: nihssScore > 15 ? 'red' : nihssScore > 5 ? 'orange' : 'green'
        });
    }
}

function calculateGlasgow() {
    // Lógica específica para calcular Glasgow
    let glasgowScore = 15; // Por defecto
    // ... cálculo basado en checkboxes seleccionados
    
    if (glasgowScore < 15) {
        escalas.push({
            nombre: 'Glasgow',
            valor: glasgowScore,
            interpretacion: glasgowScore < 9 ? 'Coma severo' : glasgowScore < 13 ? 'Coma moderado' : 'Leve',
            color: glasgowScore < 9 ? 'red' : glasgowScore < 13 ? 'orange' : 'green'
        });
    }
}

checkAlertsAndScales = checkNeurologicAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información neurológica** preservada
- **Escalas NIHSS, Glasgow, Rankin** funcionando
- **Alertas dinámicas** para emergencias neurológicas
- **Progreso automático** por secciones
