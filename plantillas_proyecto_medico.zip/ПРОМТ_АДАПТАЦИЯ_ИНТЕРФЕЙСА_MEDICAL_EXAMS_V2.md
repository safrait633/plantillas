# 🏥 Prompt para Adaptación Completa de Interfaz medical-exams-v2.mhtml

## 🎯 Objetivo Principal

Adaptar **CADA archivo HTML** en la carpeta `algoritmos_nuevo_diseño` para que la interfaz sea **1000% idéntica** al archivo `medical-exams-v2.mhtml`, PERO conservando completamente toda la información médica, algoritmos de procesamiento y escalas de los archivos originales.

## ⚠️ Requisitos Críticos

### 🎨 1. Identidad absoluta de la interfaz

- ✅ **Copiar e### ⚙️ 6. Elementos dinámicos JavaScript

#### Funcionalidad requerida:
1. **Toggle secciones** - Expandir/contraer con animación
2. **Cálculo automático progreso** - Actualizar barras según completado
3. **Alertas dinámicas** - Mostrar alertas según selecciones
4. **Escalas automáticas** - Calcular scores en tiempo real
5. **Validación completitud** - Verificar secciones obligatorias

### 🎨 7. Colores y gradientes exactos** toda la estructura, estilos y componentes de `medical-exams-v2.mhtml`
- ✅ **Conservar gradientes**: `bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800`
- ✅ **Efectos backdrop-blur exactos**: `backdrop-blur-md`, `backdrop-blur-xl`
- ✅ **Sombras y bordes idénticos**: `shadow-xl`, `border-white/20`, `bg-white/10`
- ✅ **Redondeos**: `rounded-xl`, `rounded-2xl`, `rounded-full`
- ✅ **Espaciado y tamaños exactos**: `p-6`, `gap-6`, `w-80`, `max-w-4xl`

### 🏗️ 2. Estructura de la interfaz

#### 📱 Encabezado (Header)

```html
<!-- Botón "Volver" arriba a la izquierda -->
<button class="absolute top-4 left-4 z-10 inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md px-3 bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-md">
  <svg><!-- Icono flecha izquierda --></svg>
  Volver
</button>

<!-- Fondo gradient principal -->
<div class="min-h-screen bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800">
  
  <!-- Header con backdrop-blur -->
  <div class="backdrop-blur-md bg-black/30 border-b border-white/10 p-6">
    <div class="max-w-7xl mx-auto">
      <div class="flex items-center justify-between">
        
        <!-- Título con icono de especialidad -->
        <div class="flex items-center gap-4">
          <div class="p-3 bg-indigo-500/20 rounded-full border border-indigo-500/30">
            <!-- ICONO ESPECÍFICO PARA CADA ESPECIALIDAD -->
          </div>
          <div>
            <h1 class="text-3xl font-bold text-white">[NOMBRE ESPECIALIDAD] Avanzada</h1>
            <p class="text-white/70">Framework Universal - Principio ZERO-TYPING</p>
          </div>
        </div>
        
        <!-- Badges de progreso y botón informe -->
        <div class="flex items-center gap-3">
          <div class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover:bg-primary/80 bg-indigo-500/20 text-indigo-200 border border-indigo-500/30">
            0% Completado
          </div>
          <button class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 px-4 py-2 bg-white/10 border-white/20 text-white hover:bg-white/20">
            <svg><!-- Icono file-text --></svg>
            Ver Informe
          </button>
        </div>
      </div>
    </div>
  </div>
```

#### 📐 Diseño principal (Flex con 2 columnas)
```html
<!-- Кнопка "Вolver" слева вверху -->
<button class="absolute top-4 left-4 z-10 inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md px-3 bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-md">
  <svg><!-- Icono flecha izquierda --></svg>
  Volver
</button>

<!-- Fondo gradient principal -->
<div class="min-h-screen bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800">
  
  <!-- Header con backdrop-blur -->
  <div class="backdrop-blur-md bg-black/30 border-b border-white/10 p-6">
    <div class="max-w-7xl mx-auto">
      <div class="flex items-center justify-between">
        
        <!-- Título con icono de especialidad -->
        <div class="flex items-center gap-4">
          <div class="p-3 bg-indigo-500/20 rounded-full border border-indigo-500/30">
            <!-- ICONO ESPECÍFICO PARA CADA ESPECIALIDAD -->
          </div>
          <div>
            <h1 class="text-3xl font-bold text-white">[NOMBRE ESPECIALIDAD] Avanzada</h1>
            <p class="text-white/70">Framework Universal - Principio ZERO-TYPING</p>
          </div>
        </div>
        
        <!-- Badges de progreso y botón informe -->
        <div class="flex items-center gap-3">
          <div class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover:bg-primary/80 bg-indigo-500/20 text-indigo-200 border border-indigo-500/30">
            0% Completado
          </div>
          <button class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 px-4 py-2 bg-white/10 border-white/20 text-white hover:bg-white/20">
            <svg><!-- Icono file-text --></svg>
            Ver Informe
          </button>
        </div>
      </div>
    </div>
  </div>
```

#### LAYOUT PRINCIPAL (Flex con 2 columnas)
```html
<div class="flex gap-6 p-6">
  <!-- COLUMNA PRINCIPAL (Izquierda) -->
  <div class="transition-all duration-300 w-full max-w-4xl mx-auto">
    <div class="space-y-4">
      <!-- SECCIONES AQUÍ -->
    </div>
  </div>
  
  <!-- PANEL DERECHO (Fijo 320px) -->
  <div class="w-80 space-y-4">
    <!-- COMPONENTES DASHBOARD -->
  </div>
</div>
```

#### 🔽 Secciones desplegables
```html
<div class="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl overflow-hidden">
  <!-- Header de sección clickeable -->
  <div class="p-4 cursor-pointer hover:bg-white/5 transition-colors">
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-[COLOR]"><!-- Icono específico --></svg>
        <div>
          <h3 class="font-semibold text-white">[TÍTULO SECCIÓN]</h3>
          <p class="text-sm text-white/70">[DESCRIPCIÓN]</p>
        </div>
      </div>
      <div class="flex items-center gap-3">
        <!-- Barra de progreso -->
        <div class="flex items-center gap-2">
          <div class="w-16 h-2 bg-white/20 rounded-full overflow-hidden">
            <div class="h-full bg-gradient-to-r from-indigo-400 to-blue-500 transition-all" style="width: 0%;"></div>
          </div>
          <span class="text-xs text-white/70">0%</span>
        </div>
        <!-- Chevron para expandir/contraer -->
        <svg class="w-5 h-5 text-white/70"><!-- chevron-down o chevron-up --></svg>
      </div>
    </div>
  </div>
  
  <!-- Contenido desplegable -->
  <div style="height: auto; opacity: 1;">
    <div class="p-6 border-t border-white/10 bg-white/5">
      <!-- CONTENIDO MÉDICO AQUÍ -->
    </div>
  </div>
</div>
```

#### 📊 Panel derecho - Componentes dashboard

##### 🔍 1. Barra de búsqueda
```html
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
  <div class="p-4">
    <div class="space-y-3">
      <div class="relative">
        <svg class="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-200 w-4 h-4"><!-- search icon --></svg>
        <input type="text" class="flex h-10 w-full px-3 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl pl-10 pr-4 py-2 text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50" placeholder="Buscar alertas, escalas..." value="">
      </div>
      <div class="flex gap-2">
        <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-blue-500/30 text-blue-200 border border-blue-400/30">Todos</button>
        <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-white/10 text-white/60 border border-white/20 hover:bg-white/20">Críticas</button>
        <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-purple-500/30 text-purple-200 border border-purple-400/30 hover:bg-purple-500/40">
          <svg class="w-3 h-3 mr-1 inline"><!-- grid icon --></svg>
          Especialidades
        </button>
      </div>
    </div>
  </div>
</div>
```

##### ⚠️ 2. Panel Alertas Activas
```html
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
  <div class="flex flex-col space-y-1.5 p-6 pb-3">
    <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
      <svg class="h-4 w-4 text-red-400"><!-- triangle-alert --></svg>
      Alertas Activas
    </div>
  </div>
  <div class="p-6 pt-0 space-y-3">
    <!-- Alertas dinámicas aquí -->
  </div>
</div>
```

##### 🧮 3. Panel Escalas Médicas
```html
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
  <div class="flex flex-col space-y-1.5 p-6 pb-3">
    <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
      <svg class="h-4 w-4 text-purple-400"><!-- calculator --></svg>
      Escalas Médicas
    </div>
  </div>
  <div class="p-6 pt-0 space-y-3">
    <!-- Estado inicial vacío -->
    <div class="text-center py-6">
      <svg class="h-8 w-8 text-blue-400 mx-auto mb-2"><!-- calculator --></svg>
      <p class="text-blue-200 text-xs">Escalas aparecerán aquí conforme completes el examen</p>
    </div>
  </div>
</div>
```

##### 📈 4. Panel Progreso del Examen
```html
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
  <div class="flex flex-col space-y-1.5 p-6 pb-3">
    <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
      <svg class="h-4 w-4 text-blue-400"><!-- trending-up --></svg>
      Progreso del Examen
      <div class="ml-auto">
        <div class="inline-flex items-center rounded-full px-2.5 py-0.5 font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover:bg-primary/80 bg-blue-500/30 text-blue-200 border border-blue-400/30 text-xs">0%</div>
      </div>
    </div>
  </div>
  <div class="p-6 pt-0">
    <!-- Barra de progreso principal -->
    <div class="space-y-4">
      <div class="flex items-center justify-between">
        <span class="text-blue-200 text-xs">Completado</span>
        <span class="text-white text-sm font-bold">0%</span>
      </div>
      <div class="relative w-full overflow-hidden h-3 bg-white/20 rounded-xl">
        <div class="h-full w-full flex-1 bg-primary transition-all" style="transform: translateX(-100%);"></div>
      </div>
      
      <!-- Grid de secciones -->
      <div class="grid grid-cols-2 gap-2 text-xs">
        <!-- Items dinámicos según especialidad -->
      </div>
      
      <!-- Estadísticas -->
      <div class="mt-4 p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
        <div class="grid grid-cols-3 gap-3 text-center">
          <div>
            <div class="text-lg font-bold text-white">0</div>
            <div class="text-xs text-blue-200">Secciones</div>
          </div>
          <div>
            <div class="text-lg font-bold text-white">1</div>
            <div class="text-xs text-blue-200">Alertas</div>
          </div>
          <div>
            <div class="text-lg font-bold text-white">0</div>
            <div class="text-xs text-blue-200">Escalas</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
```

##### ✅ 5. Botón Finalizar
```html
<button class="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary hover:bg-primary/90 h-11 px-8 w-full bg-gradient-to-r from-blue-500/80 to-indigo-600/80 hover:from-blue-600/90 hover:to-indigo-700/90 backdrop-blur-xl border border-white/20 text-white font-bold py-4 shadow-2xl transform transition-all duration-300 hover:scale-105 rounded-2xl">
  <svg class="h-5 w-5 mr-2"><!-- circle-check-big --></svg>
  Finalizar [ESPECIALIDAD]
</button>
```

### 🎨 3. Iconos por especialidad

#### ❤️ Cardiología
```html
<svg class="lucide lucide-heart">
  <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z"/>
</svg>
```

#### 🧠 Neurología
```html
<svg class="lucide lucide-brain">
  <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
  <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
  <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/>
  <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
  <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
  <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
  <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
  <path d="M6 18a4 4 0 0 1-1.967-.516"/>
  <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
</svg>
```

#### 🫁 Neumología
```html
<svg class="lucide lucide-wind">
  <path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/>
  <path d="M9.6 4.6A2 2 0 1 1 11 8H2"/>
  <path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>
</svg>
```

#### 🏥 Gastroenterología
```html
<svg class="lucide lucide-pill">
  <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/>
  <path d="m8.5 8.5 7 7"/>
</svg>
```

#### 💧 Urología
```html
<svg class="lucide lucide-droplets">
  <path d="M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z"/>
  <path d="M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2.04 4.6 4.14 5.78s3.86 2.41 3.86 4.78a7.3 7.3 0 0 1-7.3 7.3"/>
  <path d="M6.8 11.85c-.02-.17-.04-.34-.04-.51 0-1.48.83-2.9 2.12-3.74l-.07-.17C8.49 6.1 8.04 5.03 8.04 3.91 8.04 1.75 9.79 0 11.96 0s3.91 1.75 3.91 3.91c0 1.12-.45 2.19-.87 3.52l-.07.17c1.29.84 2.12 2.26 2.12 3.74 0 .17-.02.34-.04.51"/>
</svg>
```

#### 👁️ Oftalmología
```html
<svg class="lucide lucide-eye">
  <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/>
  <circle cx="12" cy="12" r="3"/>
</svg>
```

#### 👂 Otorrinolaringología
```html
<svg class="lucide lucide-ear">
  <path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"/>
  <path d="M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4"/>
</svg>
```

#### 🛡️ Dermatología
```html
<svg class="lucide lucide-shield-check">
  <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
  <path d="m9 12 2 2 4-4"/>
</svg>
```

#### ⚡ Endocrinología
```html
<svg class="lucide lucide-activity">
  <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>
</svg>
```

#### 🩸 Hematología
```html
<svg class="lucide lucide-droplet">
  <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>
</svg>
```

#### 🦴 Reumatología
```html
<svg class="lucide lucide-bone">
  <path d="M17 10c.7-.7 1.69 0 2.5 0a2.5 2.5 0 1 0 0-5 .5.5 0 0 1-.5-.5 2.5 2.5 0 1 0-5 0c0 .81.7 1.8 0 2.5l-7 7c-.7.7-1.69 0-2.5 0a2.5 2.5 0 0 0 0 5c.28 0 .5.22.5.5a2.5 2.5 0 1 0 5 0c0-.81-.7-1.8 0-2.5Z"/>
</svg>
```

#### 👴 Geriatría
```html
<svg class="lucide lucide-users">
  <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
  <circle cx="9" cy="7" r="4"/>
  <path d="m22 21-2-2"/>
  <path d="m16 16 2 2"/>
  <path d="m22 16-6 6"/>
</svg>
```

#### 🧩 Psiquiatría
```html
<svg class="lucide lucide-brain-circuit">
  <path d="M12 5a3 3 0 1 0-5.997.142 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588 4 4 0 1 0 7.636 2.106 3.2 3.2 0 0 0 .164-.546c.071-.25.108-.503.108-.762"/>
  <path d="M12 5a3 3 0 1 1 5.997.142 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588 4 4 0 1 1-7.636 2.106 3.2 3.2 0 0 1-.164-.546c-.071-.25-.108-.503-.108-.762"/>
  <path d="M15.828 7.172a2.828 2.828 0 0 0-4 4"/>
  <path d="M8 12h.01"/>
  <path d="M16 12h.01"/>
  <path d="M12 16h.01"/>
</svg>
```

#### 🦠 Enfermedades Infecciosas
```html
<svg class="lucide lucide-bug">
  <path d="m8 2 1.88 1.88"/>
  <path d="M14.12 3.88 16 2"/>
  <path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/>
  <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/>
  <path d="M12 20v-9"/>
  <path d="M6.53 9C4.6 8.8 3 7.1 3 5"/>
  <path d="M6 13H2"/>
  <path d="M3 21c0-2.1 1.7-3.9 3.8-4"/>
  <path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/>
  <path d="M22 13h-4"/>
  <path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>
</svg>
```

### 📋 4. Estructura de contenido por especialidad

#### 💡 Ejemplo: Cardiología
```html
<!-- Sección 1: Síntomas Cardiovasculares -->
<div class="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl overflow-hidden">
  <div class="p-4 cursor-pointer hover:bg-white/5 transition-colors">
    <div class="flex items-center justify-between">
      <div class="flex items-center gap-3">
        <svg class="w-5 h-5 text-red-500"><!-- heart icon --></svg>
        <div>
          <h3 class="font-semibold text-white">Síntomas Cardiovasculares</h3>
          <p class="text-sm text-white/70">Dolor torácico, disnea y palpitaciones</p>
        </div>
      </div>
      <!-- Progress bar y chevron -->
    </div>
  </div>
  <div class="p-6 border-t border-white/10 bg-white/5">
    <!-- CHECKBOXES CON SÍNTOMAS CARDÍACOS -->
  </div>
</div>

<!-- Sección 2: Factores de Riesgo Cardiovascular -->
<!-- Sección 3: Exploración Física -->
<!-- Sección 4: Escalas Cardiológicas (CHADS2, HAS-BLED, TIMI, etc.) -->
<!-- Sección 5: Plan de Manejo -->
```

### 🎯 5. Adaptación específica por archivo

#### ❤️ cardiologia.html
- **Título**: "Cardiología Avanzada"
- **Icono**: `lucide-heart`
- **Secciones**: Síntomas cardiovasculares, Factores de riesgo, Exploración física, Escalas cardiológicas, Plan de manejo
- **Escalas**: CHADS2, HAS-BLED, TIMI, GRACE, Killip
- **Color tema**: red-500

#### 🧠 neurologia.html
- **Título**: "Neurología Avanzada"  
- **Icono**: `lucide-brain`
- **Secciones**: Síntomas neurológicos, Factores de riesgo, Estado mental, Pares craneales, Sistema motor, Sistema sensorial, Escalas neurológicas, Plan de manejo
- **Escalas**: NIHSS, Glasgow, Rankin modificado
- **Color tema**: red-500

#### 🫁 neumologia.html
- **Título**: "Neumología Avanzada"
- **Icono**: `lucide-wind`
- **Secciones**: Síntomas respiratorios, Factores de riesgo, Exploración respiratoria, Espirometría, Escalas neumológicas, Plan de manejo
- **Escalas**: GOLD, mMRC, CAT, BODE
- **Color tema**: blue-500

> **[Continuar para cada especialidad...]**

### ⚙️ 6. Elementos dinámicos JavaScript

#### 🔧 Funcionalidad requerida:
1. **Toggle secciones** - Expandir/colapsar con animación
2. **Cálculo automático progreso** - Actualizar barras según completado  
3. **Alertas dinámicas** - Mostrar alertas según selecciones
4. **Escalas automáticas** - Calcular scores en tiempo real
5. **Validación completitud** - Verificar secciones obligatorias

### 🎨 7. Colores y gradientes exactos

```css
/* Fondo principal */
bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800

/* Elementos glassmorphism */
bg-white/10 backdrop-blur-md border border-white/20

/* Paneles dashboard */
bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl

/* Estados hover */
hover:bg-white/5
hover:bg-white/20

/* Gradientes botones */
bg-gradient-to-r from-blue-500/80 to-indigo-600/80
hover:from-blue-600/90 hover:to-indigo-700/90

/* Barras de progreso */
bg-gradient-to-r from-indigo-400 to-blue-500
```

### 📱 8. Responsividad

#### 📏 Breakpoints importantes:
- **Desktop**: Layout de 2 columnas (principal + sidebar)
- **Tablet**: Sidebar abajo o plegable  
- **Mobile**: Single column, componentes apilados

### 🚀 9. Orden de implementación

1. **🥇 Primero**: Adaptar `cardiologia.html` como prototipo
2. **🥈 Segundo**: Validar completitud de funcionalidad
3. **🥉 Tercero**: Aplicar a todas las demás especialidades
4. **4️⃣ Cuarto**: Verificar integridad de datos médicos
5. **5️⃣ Quinto**: Pruebas finales de responsividad

### ✅ 10. Verificación final

#### 📋 Checklist obligatorio:
- [ ] Interfaz 100% idéntico a medical-exams-v2.mhtml
- [ ] Todos los datos médicos preservados  
- [ ] Todas las escalas funcionando
- [ ] Todas las alertas dinámicas
- [ ] Responsividad completa
- [ ] JavaScript funcional
- [ ] Iconos correctos por especialidad
- [ ] Colores exactos
- [ ] Animaciones suaves
- [ ] Progreso dinámico

---

## 🚨 Importante

**Este prompt debe ejecutarse manteniendo ABSOLUTA FIDELIDAD al diseño original mientras PRESERVA COMPLETAMENTE toda la información médica y funcionalidad de cada especialidad.**

---

### 📄 Información del documento
- **Fecha**: Septiembre 2025
- **Versión**: 1.0
- **Autor**: Adaptación de medical-exams-v2.mhtml
- **Objetivo**: 1000% identidad visual + preservación funcional completa
