# 🧠 PSIQUIATRÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/psiquiatria.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Psiquiatría"
[NOMBRE_ESPECIALIDAD] → "Psiquiatría"
[COLOR_TEMA] → "purple-500"
```

### 🧠 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brain h-8 w-8 text-indigo-300">
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4"/>
    <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
    <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
    <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
    <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
    <path d="M6 18a4 4 0 0 1-1.967-.516"/>
    <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
</svg>
```

## 🏗️ Secciones Médicas Psiquiátricas

### 1️⃣ Estado Mental
- **Icono**: `lucide-brain` (purple-500)
- **Contenido**: Conciencia, orientación, memoria, juicio, insight
- **Alertas**: Alteración conciencia, desorientación severa

### 2️⃣ Estado Afectivo
- **Icono**: `lucide-heart` (red-400)
- **Contenido**: Humor, afecto, síntomas depresivos/maniacales
- **Alertas**: Ideación suicida, episodio maníaco agudo

### 3️⃣ Pensamiento y Percepción
- **Icono**: `lucide-eye` (blue-400)
- **Contenido**: Curso pensamiento, contenido, alucinaciones, delirios
- **Alertas**: Psicosis activa, alucinaciones comando

### 4️⃣ Escalas Psiquiátricas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: Hamilton, Beck, PANSS, MMSE
- **Escalas automáticas**: Cálculo automático escalas

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkPsychiatricAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas psiquiátricas
    if (document.getElementById('ideacion-suicida')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 IDEACIÓN SUICIDA - Evaluación urgente riesgo',
            color: 'red'
        });
    }
    
    if (document.getElementById('psicosis-activa')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🧠 PSICOSIS ACTIVA - Manejo especializado urgente',
            color: 'red'
        });
    }
    
    if (document.getElementById('episodio-maniaco')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '⚡ EPISODIO MANÍACO - Valorar hospitalización',
            color: 'orange'
        });
    }
    
    // Calcular escalas
    calculateHamiltonDepression();
    calculateBeckDepression();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateHamiltonDepression() {
    let hamiltonScore = 0;
    const items = [
        'humor-depresivo', 'sentimientos-culpa', 'suicidio', 'insomnio-inicial',
        'insomnio-medio', 'insomnio-tardio', 'trabajo-actividades', 'retardo',
        'agitacion', 'ansiedad-psiquica', 'ansiedad-somatica', 'sintomas-somaticos-gi',
        'sintomas-somaticos-generales', 'sintomas-genitales', 'hipocondria', 'perdida-peso',
        'insight'
    ];
    
    items.forEach(item => {
        const valor = document.getElementById(`hamilton-${item}`)?.value;
        if (valor) hamiltonScore += parseInt(valor);
    });
    
    if (hamiltonScore > 0) {
        let severidad = '';
        if (hamiltonScore <= 7) severidad = 'Sin depresión';
        else if (hamiltonScore <= 17) severidad = 'Depresión leve';
        else if (hamiltonScore <= 23) severidad = 'Depresión moderada';
        else severidad = 'Depresión severa';
        
        escalas.push({
            nombre: 'Hamilton Depresión',
            valor: hamiltonScore,
            interpretacion: severidad,
            color: hamiltonScore <= 17 ? 'green' : hamiltonScore <= 23 ? 'orange' : 'red'
        });
    }
}

function calculateBeckDepression() {
    let beckScore = 0;
    const items = [
        'tristeza', 'pesimismo', 'fracaso', 'satisfaccion', 'culpa',
        'castigo', 'autodisgusto', 'autocritica', 'suicidio', 'llanto',
        'irritabilidad', 'aislamiento', 'indecision', 'imagen-corporal',
        'trabajo', 'sueño', 'fatiga', 'apetito', 'peso', 'preocupacion-salud',
        'libido'
    ];
    
    items.forEach(item => {
        const valor = document.getElementById(`beck-${item}`)?.value;
        if (valor) beckScore += parseInt(valor);
    });
    
    if (beckScore > 0) {
        let nivel = '';
        if (beckScore <= 13) nivel = 'Depresión mínima';
        else if (beckScore <= 19) nivel = 'Depresión leve';
        else if (beckScore <= 28) nivel = 'Depresión moderada';
        else nivel = 'Depresión severa';
        
        escalas.push({
            nombre: 'Beck Depresión',
            valor: beckScore,
            interpretacion: nivel,
            color: beckScore <= 19 ? 'green' : beckScore <= 28 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkPsychiatricAlertsAndScales;
```
