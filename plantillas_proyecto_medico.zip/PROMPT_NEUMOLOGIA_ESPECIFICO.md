# 🫁 NEUMOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/neumologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Neumología"
[NOMBRE_ESPECIALIDAD] → "Neumología"
[COLOR_TEMA] → "blue-500"
```

### 🫁 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-wind h-8 w-8 text-indigo-300">
    <path d="M17.7 7.7a2.5 2.5 0 1 1 1.8 4.3H2"/>
    <path d="M9.6 4.6A2 2 0 1 1 11 8H2"/>
    <path d="M12.6 19.4A2 2 0 1 0 14 16H2"/>
</svg>
```

## 🏗️ Secciones Médicas Neumológicas

### 1️⃣ Síntomas Respiratorios
- **Icono**: `lucide-wind` (blue-500)
- **Contenido**: Disnea, tos, expectoración, dolor torácico pleurítico
- **Alertas**: Disnea severa, hemoptisis, estridor

### 2️⃣ Factores de Riesgo Respiratorio
- **Icono**: `lucide-cigarette` (red-400)
- **Contenido**: Tabaquismo, exposiciones ocupacionales, alergias
- **Alertas**: Exposición asbesto, tabaquismo severo

### 3️⃣ Exploración Respiratoria
- **Icono**: `lucide-stethoscope` (green-400)
- **Contenido**: Inspección, palpación, percusión, auscultación
- **Alertas**: Cianosis, tiraje, sibilancias

### 4️⃣ Espirometría y Función Pulmonar
- **Icono**: `lucide-activity` (purple-400)
- **Contenido**: FEV1, FVC, DLCO, gases arteriales
- **Alertas**: Obstrucción severa, hipoxemia

### 5️⃣ Escalas Neumológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: GOLD, mMRC, CAT, BODE, CURB-65
- **Escalas automáticas**: Cálculo en tiempo real

### 6️⃣ Plan de Manejo Neumológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, pruebas, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">F. Riesgo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Exploración</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Espirometría</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Manejo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'factores', 'exploracion', 'espirometria', 'escalas', 'manejo'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkPulmonaryAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas respiratorias
    if (document.getElementById('hemoptisis')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 HEMOPTISIS - Descartar cáncer pulmonar/TEP',
            color: 'red'
        });
    }
    
    if (document.getElementById('estridor')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ ESTRIDOR - Obstrucción vía aérea superior',
            color: 'red'
        });
    }
    
    if (document.getElementById('cianosis')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔵 CIANOSIS - Hipoxemia severa',
            color: 'blue'
        });
    }
    
    // Calcular escalas neumológicas automáticamente
    calculateGOLD();
    calculateCURB65();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateGOLD() {
    // Lógica específica para clasificación GOLD
    const fev1 = document.getElementById('fev1-percent')?.value;
    if (fev1) {
        let goldStage = '';
        if (fev1 >= 80) goldStage = 'GOLD 1 (Leve)';
        else if (fev1 >= 50) goldStage = 'GOLD 2 (Moderado)';
        else if (fev1 >= 30) goldStage = 'GOLD 3 (Severo)';
        else goldStage = 'GOLD 4 (Muy severo)';
        
        escalas.push({
            nombre: 'GOLD',
            valor: `${fev1}%`,
            interpretacion: goldStage,
            color: fev1 >= 50 ? 'green' : fev1 >= 30 ? 'orange' : 'red'
        });
    }
}

function calculateCURB65() {
    // Lógica específica para CURB-65
    let curb65Score = 0;
    if (document.getElementById('confusion')?.checked) curb65Score++;
    if (document.getElementById('urea-high')?.checked) curb65Score++;
    if (document.getElementById('respiratory-rate-high')?.checked) curb65Score++;
    if (document.getElementById('bp-low')?.checked) curb65Score++;
    if (document.getElementById('age-65')?.checked) curb65Score++;
    
    if (curb65Score > 0) {
        let riesgo = '';
        if (curb65Score <= 1) riesgo = 'Bajo riesgo';
        else if (curb65Score <= 2) riesgo = 'Riesgo intermedio';
        else riesgo = 'Alto riesgo';
        
        escalas.push({
            nombre: 'CURB-65',
            valor: curb65Score,
            interpretacion: riesgo,
            color: curb65Score <= 1 ? 'green' : curb65Score <= 2 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkPulmonaryAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información neumológica** preservada
- **Escalas GOLD, mMRC, CAT, BODE, CURB-65** funcionando
- **Alertas dinámicas** para emergencias respiratorias
- **Progreso automático** por secciones
