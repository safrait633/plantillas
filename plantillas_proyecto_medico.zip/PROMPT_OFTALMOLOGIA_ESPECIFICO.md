# 👁️ OFTALMOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/oftalmologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Oftalmología"
[NOMBRE_ESPECIALIDAD] → "Oftalmología"
[COLOR_TEMA] → "purple-500"
```

### 👁️ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-eye h-8 w-8 text-indigo-300">
    <path d="M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"/>
    <circle cx="12" cy="12" r="3"/>
</svg>
```

## 🏗️ Secciones Médicas Oftalmológicas

### 1️⃣ Síntomas Oculares
- **Icono**: `lucide-eye` (purple-500)
- **Contenido**: Pérdida visual, dolor ocular, enrojecimiento, fotofobia, halos
- **Alertas**: Pérdida visual súbita, dolor ocular severo + náuseas

### 2️⃣ Agudeza Visual y Refracción
- **Icono**: `lucide-glasses` (blue-400)
- **Contenido**: Agudeza visual lejana/cercana, refracción, defectos refractivos
- **Alertas**: Agudeza visual muy disminuida, anisocoria

### 3️⃣ Exploración Ocular Anterior
- **Icono**: `lucide-search` (green-400)
- **Contenido**: Párpados, conjuntiva, córnea, cámara anterior, iris, pupila
- **Alertas**: Córnea opaca, hipopión, midriasis fija

### 4️⃣ Presión Intraocular
- **Icono**: `lucide-gauge` (red-400)
- **Contenido**: Tonometría, excavación papilar, campo visual
- **Alertas**: PIO > 25 mmHg, excavación papilar > 0.6

### 5️⃣ Fondo de Ojo
- **Icono**: `lucide-camera` (yellow-400)
- **Contenido**: Papila, mácula, vasos retinianos, retina periférica
- **Alertas**: Papiledema, hemorragias retinianas, desprendimiento

### 6️⃣ Plan Oftalmológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, pruebas complementarias, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Agudeza</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Anterior</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Presión</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Fondo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Plan</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'agudeza', 'anterior', 'presion', 'fondo', 'plan'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkOftalmologicAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas oftalmológicas
    if (document.getElementById('perdida-visual-subita')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 PÉRDIDA VISUAL SÚBITA - Urgencia oftalmológica',
            color: 'red'
        });
    }
    
    if (document.getElementById('dolor-ocular-severo')?.checked && 
        document.getElementById('nauseas-vomitos')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ SOSPECHA GLAUCOMA AGUDO - PIO urgente',
            color: 'red'
        });
    }
    
    if (document.getElementById('destellos')?.checked && 
        document.getElementById('moscas-volantes')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '👁️ SÍNTOMAS RETINIANOS - Descartar desprendimiento',
            color: 'orange'
        });
    }
    
    if (document.getElementById('halos-vision-borrosa')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🌙 HALOS + VISIÓN BORROSA - Evaluar glaucoma',
            color: 'orange'
        });
    }
    
    // Evaluar presión intraocular
    const pio = document.getElementById('presion-intraocular')?.value;
    if (pio && pio > 21) {
        const severidad = pio > 30 ? 'critical' : 'warning';
        const mensaje = pio > 30 ? 
            '🔴 PIO MUY ELEVADA - Tratamiento inmediato' : 
            '🟡 PIO ELEVADA - Monitoreo y tratamiento';
        
        alertas.push({
            tipo: severidad,
            mensaje: mensaje,
            color: pio > 30 ? 'red' : 'orange'
        });
    }
    
    // Evaluar agudeza visual
    const agudezaOD = document.getElementById('agudeza-od')?.value;
    const agudezaOI = document.getElementById('agudeza-oi')?.value;
    
    if ((agudezaOD && agudezaOD < 0.1) || (agudezaOI && agudezaOI < 0.1)) {
        alertas.push({
            tipo: 'warning',
            mensaje: '📉 AGUDEZA VISUAL MUY DISMINUIDA - Investigar causa',
            color: 'orange'
        });
    }
    
    // Calcular escalas oftalmológicas
    calculateGlaucomaRisk();
    calculateVisualImpairment();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateGlaucomaRisk() {
    let riesgoGlaucoma = 0;
    
    // Factores de riesgo
    if (document.getElementById('edad-mayor-60')?.checked) riesgoGlaucoma += 1;
    if (document.getElementById('antecedentes-familiares-glaucoma')?.checked) riesgoGlaucoma += 2;
    if (document.getElementById('miopía-alta')?.checked) riesgoGlaucoma += 1;
    if (document.getElementById('raza-negra')?.checked) riesgoGlaucoma += 1;
    
    const pio = document.getElementById('presion-intraocular')?.value;
    if (pio > 21) riesgoGlaucoma += 2;
    if (pio > 25) riesgoGlaucoma += 1;
    
    const excavacion = document.getElementById('excavacion-papilar')?.value;
    if (excavacion > 0.5) riesgoGlaucoma += 2;
    if (excavacion > 0.7) riesgoGlaucoma += 1;
    
    if (riesgoGlaucoma > 0) {
        let interpretacion = '';
        if (riesgoGlaucoma <= 2) interpretacion = 'Riesgo bajo';
        else if (riesgoGlaucoma <= 4) interpretacion = 'Riesgo moderado';
        else interpretacion = 'Riesgo alto';
        
        escalas.push({
            nombre: 'Riesgo Glaucoma',
            valor: riesgoGlaucoma,
            interpretacion: interpretacion,
            color: riesgoGlaucoma <= 2 ? 'green' : riesgoGlaucoma <= 4 ? 'orange' : 'red'
        });
    }
}

function calculateVisualImpairment() {
    const agudezaOD = document.getElementById('agudeza-od')?.value;
    const agudezaOI = document.getElementById('agudeza-oi')?.value;
    
    if (agudezaOD && agudezaOI) {
        const mejorOjo = Math.max(agudezaOD, agudezaOI);
        let categoria = '';
        
        if (mejorOjo >= 0.8) categoria = 'Visión normal';
        else if (mejorOjo >= 0.5) categoria = 'Deficiencia visual leve';
        else if (mejorOjo >= 0.1) categoria = 'Deficiencia visual moderada';
        else if (mejorOjo >= 0.05) categoria = 'Deficiencia visual severa';
        else categoria = 'Ceguera';
        
        escalas.push({
            nombre: 'Deterioro Visual',
            valor: `${mejorOjo}`,
            interpretacion: categoria,
            color: mejorOjo >= 0.5 ? 'green' : mejorOjo >= 0.1 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkOftalmologicAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información oftalmológica** preservada
- **Escalas riesgo glaucoma, deterioro visual** funcionando
- **Alertas dinámicas** para emergencias oculares
- **Progreso automático** por secciones
