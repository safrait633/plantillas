# 👂 OTORRINOLARINGOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/otorrinolaringologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Otorrinolaringología"
[NOMBRE_ESPECIALIDAD] → "Otorrinolaringología"
[COLOR_TEMA] → "orange-500"
```

### 👂 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-ear h-8 w-8 text-indigo-300">
    <path d="M6 8.5a6.5 6.5 0 1 1 13 0c0 6-6 6-6 10a3.5 3.5 0 1 1-7 0"/>
    <path d="M15 8.5a2.5 2.5 0 0 0-5 0v1a2 2 0 1 1 0 4"/>
</svg>
```

## 🏗️ Secciones Médicas ORL

### 1️⃣ Síntomas ORL
- **Icono**: `lucide-ear` (orange-500)
- **Contenido**: Hipoacusia, acúfenos, vértigo, dolor ótico, otalgia
- **Alertas**: Hipoacusia súbita, vértigo severo + náuseas

### 2️⃣ Exploración Otológica
- **Icono**: `lucide-search` (blue-400)
- **Contenido**: Otoscopia, membrana timpánica, conducto auditivo externo
- **Alertas**: Membrana timpánica perforada, secreción purulenta

### 3️⃣ Exploración Nasal y Faríngea
- **Icono**: `lucide-wind` (green-400)
- **Contenido**: Rinoscopia, faringe, laringe, palpación cervical
- **Alertas**: Disfagia + odinofagia, epistaxis recurrente

### 4️⃣ Audiometría y Función Vestibular
- **Icono**: `lucide-activity` (purple-400)
- **Contenido**: Audiometría tonal, logoaudiometría, pruebas vestibulares
- **Alertas**: Hipoacusia neurosensorial severa

### 5️⃣ Escalas ORL
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: Grado hipoacusia, índice masa corporal, escalas vértigo
- **Escalas automáticas**: Clasificación automática hipoacusia

### 6️⃣ Plan ORL
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, audiometría, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Oído</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Nariz/Faringe</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Audiometría</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Plan</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'oido', 'nariz-faringe', 'audiometria', 'escalas', 'plan'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkORLAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas ORL
    if (document.getElementById('hipoacusia-subita')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 HIPOACUSIA SÚBITA - Corticoides urgentes',
            color: 'red'
        });
    }
    
    if (document.getElementById('vertigo-severo')?.checked && 
        document.getElementById('nauseas-vomitos')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🌪️ VÉRTIGO SEVERO - Descartar neuritis vestibular',
            color: 'red'
        });
    }
    
    if (document.getElementById('disfagia')?.checked && 
        document.getElementById('odinofagia')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '⚠️ DISFAGIA + ODINOFAGIA - Descartar malignidad',
            color: 'orange'
        });
    }
    
    if (document.getElementById('epistaxis-recurrente')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🩸 EPISTAXIS RECURRENTE - Investigar causa',
            color: 'orange'
        });
    }
    
    if (document.getElementById('timpano-perforado')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔴 MEMBRANA TIMPÁNICA PERFORADA - Evitar agua',
            color: 'orange'
        });
    }
    
    // Calcular escalas ORL automáticamente
    calculateHearingLoss();
    calculateVertigoSeverity();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateHearingLoss() {
    // Calcular grado de hipoacusia basado en audiometría
    const umbrales = [];
    
    // Frecuencias audiométricas (500, 1000, 2000, 4000 Hz)
    const frecuencias = ['500', '1000', '2000', '4000'];
    frecuencias.forEach(freq => {
        const umbralOD = document.getElementById(`umbral-od-${freq}`)?.value;
        const umbralOI = document.getElementById(`umbral-oi-${freq}`)?.value;
        if (umbralOD) umbrales.push(parseInt(umbralOD));
        if (umbralOI) umbrales.push(parseInt(umbralOI));
    });
    
    if (umbrales.length > 0) {
        const promedioUmbral = umbrales.reduce((a, b) => a + b, 0) / umbrales.length;
        
        let gradoHipoacusia = '';
        let color = 'green';
        
        if (promedioUmbral <= 25) {
            gradoHipoacusia = 'Audición normal';
        } else if (promedioUmbral <= 40) {
            gradoHipoacusia = 'Hipoacusia leve';
            color = 'yellow';
        } else if (promedioUmbral <= 55) {
            gradoHipoacusia = 'Hipoacusia moderada';
            color = 'orange';
        } else if (promedioUmbral <= 70) {
            gradoHipoacusia = 'Hipoacusia moderada-severa';
            color = 'orange';
        } else if (promedioUmbral <= 90) {
            gradoHipoacusia = 'Hipoacusia severa';
            color = 'red';
        } else {
            gradoHipoacusia = 'Hipoacusia profunda';
            color = 'red';
        }
        
        escalas.push({
            nombre: 'Grado Hipoacusia',
            valor: `${Math.round(promedioUmbral)} dB`,
            interpretacion: gradoHipoacusia,
            color: color
        });
    }
}

function calculateVertigoSeverity() {
    // Evaluar severidad del vértigo
    let severidadVertigo = 0;
    
    if (document.getElementById('vertigo-rotatorio')?.checked) severidadVertigo += 2;
    if (document.getElementById('nauseas-vomitos')?.checked) severidadVertigo += 2;
    if (document.getElementById('inestabilidad')?.checked) severidadVertigo += 1;
    if (document.getElementById('nistagmo')?.checked) severidadVertigo += 2;
    if (document.getElementById('hipoacusia-asociada')?.checked) severidadVertigo += 1;
    
    if (severidadVertigo > 0) {
        let interpretacion = '';
        if (severidadVertigo <= 2) interpretacion = 'Vértigo leve';
        else if (severidadVertigo <= 4) interpretacion = 'Vértigo moderado';
        else interpretacion = 'Vértigo severo';
        
        escalas.push({
            nombre: 'Severidad Vértigo',
            valor: severidadVertigo,
            interpretacion: interpretacion,
            color: severidadVertigo <= 2 ? 'green' : severidadVertigo <= 4 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkORLAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información ORL** preservada
- **Escalas grado hipoacusia, severidad vértigo** funcionando
- **Alertas dinámicas** para emergencias ORL
- **Progreso automático** por secciones
