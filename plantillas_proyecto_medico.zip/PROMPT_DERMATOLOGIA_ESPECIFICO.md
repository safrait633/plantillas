# 🛡️ DERMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/dermatologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Dermatología"
[NOMBRE_ESPECIALIDAD] → "Dermatología"
[COLOR_TEMA] → "pink-500"
```

### 🛡️ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-shield-check h-8 w-8 text-indigo-300">
    <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/>
    <path d="m9 12 2 2 4-4"/>
</svg>
```

## 🏗️ Secciones Médicas Dermatológicas

### 1️⃣ Lesiones Cutáneas
- **Icono**: `lucide-shield-check` (pink-500)
- **Contenido**: Tipo de lesión, color, tamaño, bordes, superficie, distribución
- **Alertas**: Melanoma sospechoso (ABCDE), lesión ulcerada sangrante

### 2️⃣ Exploración Dermatológica Sistemática
- **Icono**: `lucide-search` (green-400)
- **Contenido**: Cabeza, cuello, tronco, extremidades, mucosas, anexos
- **Alertas**: Lesiones múltiples sospechosas, cambios en nevus

### 3️⃣ Dermatoscopia
- **Icono**: `lucide-zoom-in` (blue-400)
- **Contenido**: Patrón pigmentario, estructuras vasculares, criterios ABCDE
- **Alertas**: Criterios dermatoscópicos malignos

### 4️⃣ Factores de Riesgo Dermatológico
- **Icono**: `lucide-sun` (yellow-400)
- **Contenido**: Exposición solar, fototipo, antecedentes familiares, nevus
- **Alertas**: Fototipo I-II + múltiples nevus, quemaduras solares

### 5️⃣ Escalas Dermatológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: ABCDE melanoma, PASI psoriasis, Breslow, Clark
- **Escalas automáticas**: Evaluación automática ABCDE

### 6️⃣ Plan Dermatológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, biopsia, seguimiento, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Lesiones</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Exploración</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Dermatoscopia</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">F. Riesgo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Plan</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['lesiones', 'exploracion', 'dermatoscopia', 'factores', 'escalas', 'plan'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkDermatologicAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas dermatológicas - Criterios ABCDE
    let criteriosABCDE = 0;
    
    if (document.getElementById('asimetria')?.checked) {
        criteriosABCDE++;
        alertas.push({
            tipo: 'warning',
            mensaje: '🔺 ASIMETRÍA - Criterio A positivo para melanoma',
            color: 'orange'
        });
    }
    
    if (document.getElementById('bordes-irregulares')?.checked) {
        criteriosABCDE++;
        alertas.push({
            tipo: 'warning',
            mensaje: '📐 BORDES IRREGULARES - Criterio B positivo',
            color: 'orange'
        });
    }
    
    if (document.getElementById('color-heterogeneo')?.checked) {
        criteriosABCDE++;
        alertas.push({
            tipo: 'warning',
            mensaje: '🎨 COLOR HETEROGÉNEO - Criterio C positivo',
            color: 'orange'
        });
    }
    
    const diametro = document.getElementById('diametro-lesion')?.value;
    if (diametro && diametro > 6) {
        criteriosABCDE++;
        alertas.push({
            tipo: 'warning',
            mensaje: '📏 DIÁMETRO > 6mm - Criterio D positivo',
            color: 'orange'
        });
    }
    
    if (document.getElementById('evolucion-cambios')?.checked) {
        criteriosABCDE++;
        alertas.push({
            tipo: 'warning',
            mensaje: '📈 EVOLUCIÓN/CAMBIOS - Criterio E positivo',
            color: 'orange'
        });
    }
    
    // Alerta crítica si múltiples criterios ABCDE
    if (criteriosABCDE >= 3) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 ALTO RIESGO MELANOMA - Biopsia urgente',
            color: 'red'
        });
    }
    
    // Otras alertas dermatológicas
    if (document.getElementById('lesion-ulcerada-sangrante')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🩸 LESIÓN ULCERADA SANGRANTE - Evaluar malignidad',
            color: 'red'
        });
    }
    
    if (document.getElementById('exantema-fiebre')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🌡️ EXANTEMA + FIEBRE - Descartar enfermedad sistémica',
            color: 'orange'
        });
    }
    
    if (document.getElementById('nevus-cambios-recientes')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔄 CAMBIOS EN NEVUS - Seguimiento estrecho',
            color: 'orange'
        });
    }
    
    // Calcular escalas dermatológicas automáticamente
    calculateABCDEScore();
    calculatePASI();
    calculateSkinCancerRisk();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateABCDEScore() {
    let abcdeScore = 0;
    
    if (document.getElementById('asimetria')?.checked) abcdeScore += 1;
    if (document.getElementById('bordes-irregulares')?.checked) abcdeScore += 1;
    if (document.getElementById('color-heterogeneo')?.checked) abcdeScore += 1;
    
    const diametro = document.getElementById('diametro-lesion')?.value;
    if (diametro && diametro > 6) abcdeScore += 1;
    
    if (document.getElementById('evolucion-cambios')?.checked) abcdeScore += 1;
    
    if (abcdeScore > 0) {
        let riesgo = '';
        if (abcdeScore <= 1) riesgo = 'Riesgo bajo';
        else if (abcdeScore <= 2) riesgo = 'Riesgo moderado';
        else riesgo = 'Riesgo alto - Biopsia indicada';
        
        escalas.push({
            nombre: 'ABCDE Melanoma',
            valor: `${abcdeScore}/5`,
            interpretacion: riesgo,
            color: abcdeScore <= 1 ? 'green' : abcdeScore <= 2 ? 'orange' : 'red'
        });
    }
}

function calculatePASI() {
    // Calcular PASI para psoriasis (simplificado)
    let pasiScore = 0;
    
    // Eritema, descamación, grosor por región
    const regiones = ['cabeza', 'tronco', 'brazos', 'piernas'];
    
    regiones.forEach(region => {
        const eritema = document.getElementById(`eritema-${region}`)?.value || 0;
        const descamacion = document.getElementById(`descamacion-${region}`)?.value || 0;
        const grosor = document.getElementById(`grosor-${region}`)?.value || 0;
        const area = document.getElementById(`area-${region}`)?.value || 0;
        
        let regionScore = (parseInt(eritema) + parseInt(descamacion) + parseInt(grosor)) * parseInt(area);
        
        // Factores de peso por región
        if (region === 'cabeza') regionScore *= 0.1;
        else if (region === 'tronco') regionScore *= 0.3;
        else if (region === 'brazos') regionScore *= 0.2;
        else if (region === 'piernas') regionScore *= 0.4;
        
        pasiScore += regionScore;
    });
    
    if (pasiScore > 0) {
        let severidad = '';
        if (pasiScore <= 10) severidad = 'Psoriasis leve';
        else if (pasiScore <= 20) severidad = 'Psoriasis moderada';
        else severidad = 'Psoriasis severa';
        
        escalas.push({
            nombre: 'PASI',
            valor: Math.round(pasiScore * 10) / 10,
            interpretacion: severidad,
            color: pasiScore <= 10 ? 'green' : pasiScore <= 20 ? 'orange' : 'red'
        });
    }
}

function calculateSkinCancerRisk() {
    let riesgoScore = 0;
    
    // Factores de riesgo
    if (document.getElementById('fototipo-1-2')?.checked) riesgoScore += 2;
    if (document.getElementById('antecedentes-familiares-melanoma')?.checked) riesgoScore += 2;
    if (document.getElementById('nevus-displasicos')?.checked) riesgoScore += 2;
    if (document.getElementById('quemaduras-solares-infancia')?.checked) riesgoScore += 1;
    if (document.getElementById('exposicion-solar-intensa')?.checked) riesgoScore += 1;
    
    const numeroNevus = document.getElementById('numero-nevus')?.value;
    if (numeroNevus > 50) riesgoScore += 2;
    else if (numeroNevus > 20) riesgoScore += 1;
    
    if (riesgoScore > 0) {
        let riesgo = '';
        if (riesgoScore <= 2) riesgo = 'Riesgo bajo';
        else if (riesgoScore <= 4) riesgo = 'Riesgo moderado';
        else riesgo = 'Riesgo alto';
        
        escalas.push({
            nombre: 'Riesgo Cáncer Piel',
            valor: riesgoScore,
            interpretacion: riesgo,
            color: riesgoScore <= 2 ? 'green' : riesgoScore <= 4 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkDermatologicAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información dermatológica** preservada
- **Escalas ABCDE, PASI, riesgo cáncer piel** funcionando
- **Alertas dinámicas** para lesiones sospechosas
- **Progreso automático** por secciones
