# 🏥 Prompt General - Adaptación de Interfaz medical-exams-v2.mhtml

## 🎯 Objetivo Principal

Adaptar **UN archivo HTML específico** en la carpeta `algoritmos_nuevo_diseño` para que la interfaz sea **1000% idéntica** al archivo `medical-exams-v2.mhtml`, PERO conservando completamente toda la información médica, algoritmos de procesamiento y escalas del archivo original.

## ⚠️ Requisitos Críticos Universales

### 🎨 1. Identidad absoluta de la interfaz

- ✅ **Copiar exactamente** toda la estructura, estilos y componentes de `medical-exams-v2.mhtml`
- ✅ **Conservar gradientes**: `bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800`
- ✅ **Efectos backdrop-blur exactos**: `backdrop-blur-md`, `backdrop-blur-xl`
- ✅ **Sombras y bordes idénticos**: `shadow-xl`, `border-white/20`, `bg-white/10`
- ✅ **Redondeos**: `rounded-xl`, `rounded-2xl`, `rounded-full`
- ✅ **Espaciado y tamaños exactos**: `p-6`, `gap-6`, `w-80`, `max-w-4xl`

### 🏗️ 2. Estructura HTML Base (COPIAR EXACTAMENTE)

```html
<!DOCTYPE html>
<html lang="es" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>[ESPECIALIDAD] Avanzada - Framework Universal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <div id="root">
        <!-- Botón "Volver" arriba a la izquierda -->
        <button class="absolute top-4 left-4 z-10 inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-9 rounded-md px-3 bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-md">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-arrow-left w-4 h-4 mr-2">
                <path d="m12 19-7-7 7-7"></path>
                <path d="M19 12H5"></path>
            </svg>
            Volver
        </button>

        <!-- Fondo gradient principal -->
        <div class="min-h-screen bg-gradient-to-br from-indigo-900 via-slate-900 to-blue-800">
            
            <!-- Header con backdrop-blur -->
            <div class="backdrop-blur-md bg-black/30 border-b border-white/10 p-6">
                <div class="max-w-7xl mx-auto">
                    <div class="flex items-center justify-between">
                        
                        <!-- Título con icono de especialidad -->
                        <div class="flex items-center gap-4">
                            <div class="p-3 bg-indigo-500/20 rounded-full border border-indigo-500/30">
                                <!-- ICONO ESPECÍFICO PARA CADA ESPECIALIDAD -->
                                [ICONO_ESPECIALIDAD]
                            </div>
                            <div>
                                <h1 class="text-3xl font-bold text-white">[NOMBRE_ESPECIALIDAD] Avanzada</h1>
                                <p class="text-white/70">Framework Universal - Principio ZERO-TYPING</p>
                            </div>
                        </div>
                        
                        <!-- Badges de progreso y botón informe -->
                        <div class="flex items-center gap-3">
                            <div class="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover:bg-primary/80 bg-indigo-500/20 text-indigo-200 border border-indigo-500/30">
                                0% Completado
                            </div>
                            <button class="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 border hover:text-accent-foreground h-10 px-4 py-2 bg-white/10 border-white/20 text-white hover:bg-white/20">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-file-text w-4 h-4 mr-2">
                                    <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                                    <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
                                    <path d="M10 9H8"></path>
                                    <path d="M16 13H8"></path>
                                    <path d="M16 17H8"></path>
                                </svg>
                                Ver Informe
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- LAYOUT PRINCIPAL (Flex con 2 columnas) -->
            <div class="flex gap-6 p-6">
                <!-- COLUMNA PRINCIPAL (Izquierda) -->
                <div class="transition-all duration-300 w-full max-w-4xl mx-auto">
                    <div class="space-y-4">
                        <!-- SECCIONES MÉDICAS AQUÍ -->
                        [SECCIONES_MEDICAS]
                    </div>
                </div>
                
                <!-- PANEL DERECHO (Fijo 320px) -->
                <div class="w-80 space-y-4">
                    <!-- COMPONENTES DASHBOARD -->
                    [PANEL_DASHBOARD]
                </div>
            </div>
        </div>
    </div>

    <!-- JAVASCRIPT -->
    [JAVASCRIPT_FUNCIONALIDAD]
</body>
</html>
```

### 📊 3. Panel Dashboard (COPIAR EXACTAMENTE)

```html
<!-- 1. Barra de búsqueda -->
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
    <div class="p-4">
        <div class="space-y-3">
            <div class="relative">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-200 w-4 h-4">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="m21 21-4.35-4.35"></path>
                </svg>
                <input type="text" class="flex h-10 w-full px-3 text-base ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:text-sm bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl pl-10 pr-4 py-2 text-white placeholder-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-blue-400/50" placeholder="Buscar alertas, escalas..." value="">
            </div>
            <div class="flex gap-2">
                <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-blue-500/30 text-blue-200 border border-blue-400/30">Todos</button>
                <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-white/10 text-white/60 border border-white/20 hover:bg-white/20">Críticas</button>
                <button class="px-3 py-1 rounded-lg text-xs transition-colors bg-purple-500/30 text-purple-200 border border-purple-400/30 hover:bg-purple-500/40">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-3 h-3 mr-1 inline">
                        <rect width="7" height="7" x="3" y="3" rx="1"></rect>
                        <rect width="7" height="7" x="14" y="3" rx="1"></rect>
                        <rect width="7" height="7" x="14" y="14" rx="1"></rect>
                        <rect width="7" height="7" x="3" y="14" rx="1"></rect>
                    </svg>
                    Especialidades
                </button>
            </div>
        </div>
    </div>
</div>

<!-- 2. Panel Alertas Activas -->
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
    <div class="flex flex-col space-y-1.5 p-6 pb-3">
        <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4 text-red-400">
                <path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path>
                <path d="M12 9v4"></path>
                <path d="m12 17 .01 0"></path>
            </svg>
            Alertas Activas
        </div>
    </div>
    <div class="p-6 pt-0 space-y-3" id="alertas-container">
        <!-- Alertas dinámicas aquí -->
    </div>
</div>

<!-- 3. Panel Escalas Médicas -->
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
    <div class="flex flex-col space-y-1.5 p-6 pb-3">
        <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4 text-purple-400">
                <rect width="16" height="10" x="2" y="3" rx="2" ry="2"></rect>
                <path d="m7 11 2-2-2-2"></path>
                <path d="M11 13h4"></path>
            </svg>
            Escalas Médicas
        </div>
    </div>
    <div class="p-6 pt-0 space-y-3" id="escalas-container">
        <!-- Estado inicial vacío -->
        <div class="text-center py-6">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-8 w-8 text-blue-400 mx-auto mb-2">
                <rect width="16" height="10" x="2" y="3" rx="2" ry="2"></rect>
                <path d="m7 11 2-2-2-2"></path>
                <path d="M11 13h4"></path>
            </svg>
            <p class="text-blue-200 text-xs">Escalas aparecerán aquí conforme completes el examen</p>
        </div>
    </div>
</div>

<!-- 4. Panel Progreso del Examen -->
<div class="text-card-foreground bg-white/10 backdrop-blur-xl border border-white/20 shadow-2xl rounded-2xl">
    <div class="flex flex-col space-y-1.5 p-6 pb-3">
        <div class="font-semibold tracking-tight text-white text-sm flex items-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-4 w-4 text-blue-400">
                <path d="M3 3v18h18"></path>
                <path d="m19 9-5 5-4-4-3 3"></path>
            </svg>
            Progreso del Examen
            <div class="ml-auto">
                <div class="inline-flex items-center rounded-full px-2.5 py-0.5 font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 hover:bg-primary/80 bg-blue-500/30 text-blue-200 border border-blue-400/30 text-xs" id="progreso-badge">0%</div>
            </div>
        </div>
    </div>
    <div class="p-6 pt-0">
        <!-- Barra de progreso principal -->
        <div class="space-y-4">
            <div class="flex items-center justify-between">
                <span class="text-blue-200 text-xs">Completado</span>
                <span class="text-white text-sm font-bold" id="progreso-text">0%</span>
            </div>
            <div class="relative w-full overflow-hidden h-3 bg-white/20 rounded-xl">
                <div class="h-full w-full flex-1 bg-primary transition-all" id="progreso-bar" style="transform: translateX(-100%);"></div>
            </div>
            
            <!-- Grid de secciones -->
            <div class="grid grid-cols-2 gap-2 text-xs" id="secciones-grid">
                [SECCIONES_PROGRESO]
            </div>
            
            <!-- Estadísticas -->
            <div class="mt-4 p-3 bg-white/10 backdrop-blur-sm rounded-xl border border-white/20">
                <div class="grid grid-cols-3 gap-3 text-center">
                    <div>
                        <div class="text-lg font-bold text-white" id="stat-secciones">0</div>
                        <div class="text-xs text-blue-200">Secciones</div>
                    </div>
                    <div>
                        <div class="text-lg font-bold text-white" id="stat-alertas">0</div>
                        <div class="text-xs text-blue-200">Alertas</div>
                    </div>
                    <div>
                        <div class="text-lg font-bold text-white" id="stat-escalas">0</div>
                        <div class="text-xs text-blue-200">Escalas</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 5. Botón Finalizar -->
<button class="inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 bg-primary hover:bg-primary/90 h-11 px-8 w-full bg-gradient-to-r from-blue-500/80 to-indigo-600/80 hover:from-blue-600/90 hover:to-indigo-700/90 backdrop-blur-xl border border-white/20 text-white font-bold py-4 shadow-2xl transform transition-all duration-300 hover:scale-105 rounded-2xl">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="h-5 w-5 mr-2">
        <circle cx="12" cy="12" r="10"></circle>
        <path d="m9 12 2 2 4-4"></path>
    </svg>
    Finalizar [ESPECIALIDAD]
</button>
```

### 🔽 4. Template Sección Desplegable (COPIAR EXACTAMENTE)

```html
<div class="bg-white/10 backdrop-blur-md rounded-xl border border-white/20 shadow-xl overflow-hidden">
    <!-- Header de sección clickeable -->
    <div class="p-4 cursor-pointer hover:bg-white/5 transition-colors" onclick="toggleSection('SECCION_ID')">
        <div class="flex items-center justify-between">
            <div class="flex items-center gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5 text-[COLOR_ICONO]">
                    [SVG_PATH_ICONO]
                </svg>
                <div>
                    <h3 class="font-semibold text-white">[TITULO_SECCION]</h3>
                    <p class="text-sm text-white/70">[DESCRIPCION_SECCION]</p>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <!-- Barra de progreso -->
                <div class="flex items-center gap-2">
                    <div class="w-16 h-2 bg-white/20 rounded-full overflow-hidden">
                        <div class="h-full bg-gradient-to-r from-indigo-400 to-blue-500 transition-all" id="progress-SECCION_ID" style="width: 0%;"></div>
                    </div>
                    <span class="text-xs text-white/70" id="percent-SECCION_ID">0%</span>
                </div>
                <!-- Chevron para expandir/contraer -->
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="w-5 h-5 text-white/70" id="chevron-SECCION_ID">
                    <path d="m18 15-6-6-6 6"></path>
                </svg>
            </div>
        </div>
    </div>
    
    <!-- Contenido desplegable -->
    <div id="content-SECCION_ID" style="height: auto; opacity: 1;">
        <div class="p-6 border-t border-white/10 bg-white/5">
            <!-- CONTENIDO MÉDICO AQUÍ -->
            [CONTENIDO_MEDICO]
        </div>
    </div>
</div>
```

### ⚙️ 5. JavaScript Base (COPIAR EXACTAMENTE)

```javascript
<script>
// Variables globales
let progressData = {};
let alertas = [];
let escalas = [];

// Función para toggle de secciones
function toggleSection(sectionId) {
    const content = document.getElementById(`content-${sectionId}`);
    const chevron = document.getElementById(`chevron-${sectionId}`);
    
    if (content.style.opacity === '0' || content.style.height === '0px') {
        content.style.height = 'auto';
        content.style.opacity = '1';
        chevron.innerHTML = '<path d="m18 15-6-6-6 6"></path>';
    } else {
        content.style.height = '0px';
        content.style.opacity = '0';
        chevron.innerHTML = '<path d="m6 9 6 6 6-6"></path>';
    }
}

// Función para actualizar progreso
function updateProgress() {
    const totalSections = Object.keys(progressData).length;
    const completedSections = Object.values(progressData).filter(p => p > 0).length;
    const averageProgress = totalSections > 0 ? Math.round(Object.values(progressData).reduce((a, b) => a + b, 0) / totalSections) : 0;
    
    // Actualizar UI
    document.getElementById('progreso-badge').textContent = `${averageProgress}% Completado`;
    document.getElementById('progreso-text').textContent = `${averageProgress}%`;
    document.getElementById('progreso-bar').style.transform = `translateX(-${100 - averageProgress}%)`;
    document.getElementById('stat-secciones').textContent = totalSections;
    document.getElementById('stat-alertas').textContent = alertas.length;
    document.getElementById('stat-escalas').textContent = escalas.length;
}

// Función para calcular progreso de sección
function calculateSectionProgress(sectionId) {
    const checkboxes = document.querySelectorAll(`#content-${sectionId} input[type="checkbox"]`);
    const checked = document.querySelectorAll(`#content-${sectionId} input[type="checkbox"]:checked`);
    const progress = checkboxes.length > 0 ? Math.round((checked.length / checkboxes.length) * 100) : 0;
    
    progressData[sectionId] = progress;
    
    // Actualizar barra de sección
    document.getElementById(`progress-${sectionId}`).style.width = `${progress}%`;
    document.getElementById(`percent-${sectionId}`).textContent = `${progress}%`;
    
    updateProgress();
}

// Event listeners para checkboxes
document.addEventListener('change', function(e) {
    if (e.target.type === 'checkbox') {
        const sectionId = e.target.closest('[id^="content-"]').id.replace('content-', '');
        calculateSectionProgress(sectionId);
        
        // Verificar alertas y escalas
        checkAlertsAndScales();
    }
});

// Función para verificar alertas y escalas (personalizable por especialidad)
function checkAlertsAndScales() {
    // Esta función será específica para cada especialidad
    [ALERTS_AND_SCALES_LOGIC]
}

// Inicialización
document.addEventListener('DOMContentLoaded', function() {
    // Inicializar todas las secciones
    [INIT_SECTIONS]
});
</script>
```

### 📋 6. Instrucciones de Uso

Para adaptar un archivo específico:

1. **Tomar la estructura HTML base** y reemplazar los placeholders:
   - `[ESPECIALIDAD]` → Nombre de la especialidad
   - `[ICONO_ESPECIALIDAD]` → SVG específico de la especialidad
   - `[SECCIONES_MEDICAS]` → Secciones médicas del archivo original
   - `[PANEL_DASHBOARD]` → Panel derecho exacto
   - `[JAVASCRIPT_FUNCIONALIDAD]` → JavaScript con lógica específica

2. **Conservar TODA la información médica** del archivo original

3. **Adaptar las secciones** usando el template de sección desplegable

4. **Implementar la lógica específica** de alertas y escalas

5. **Verificar funcionalidad completa** antes de continuar

---

## 🚨 Importante

**Este prompt base debe aplicarse a CADA archivo individual, usando las especificaciones particulares de cada especialidad que se proporcionarán por separado.**
