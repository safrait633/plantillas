# 🦠 ENFERMEDADES INFECCIOSAS - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/enfermedades_infecciosas.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Enfermedades Infecciosas"
[NOMBRE_ESPECIALIDAD] → "Infectología"
[COLOR_TEMA] → "red-500"
```

### 🦠 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bug h-8 w-8 text-indigo-300">
    <path d="m8 2 1.88 1.88"/>
    <path d="M14.12 3.88 16 2"/>
    <path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/>
    <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/>
    <path d="M12 20v-9"/>
    <path d="M6.53 9C4.6 8.8 3 7.1 3 5"/>
    <path d="M6 13H2"/>
    <path d="M3 21c0-2.1 1.7-3.9 3.8-4"/>
    <path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/>
    <path d="M22 13h-4"/>
    <path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>
</svg>
```

## 🏗️ Secciones Médicas Infectológicas

### 1️⃣ Síndrome Febril
- **Icono**: `lucide-thermometer` (red-500)
- **Contenido**: Fiebre, escalofríos, síntomas sistémicos, foco infeccioso
- **Alertas**: Fiebre alta, sepsis, shock séptico

### 2️⃣ Infecciones por Sistemas
- **Icono**: `lucide-zap` (orange-400)
- **Contenido**: Respiratorias, urinarias, SNC, piel, abdominales
- **Alertas**: Meningitis, neumonía grave, sepsis urinaria

### 3️⃣ Resistencia Antimicrobiana
- **Icono**: `lucide-shield-off` (yellow-400)
- **Contenido**: BLEE, MRSA, carbapenemasas, multirresistencia
- **Alertas**: Microorganismo MDR, fallo terapéutico

### 4️⃣ Escalas Infecciosas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: SOFA, qSOFA, CURB-65, Apache II
- **Escalas automáticas**: Cálculo automático escalas

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkInfectiousAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas infecciosas
    if (document.getElementById('sepsis-severa')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 SEPSIS SEVERA - Manejo intensivo inmediato',
            color: 'red'
        });
    }
    
    if (document.getElementById('shock-septico')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '💀 SHOCK SÉPTICO - UCI y soporte vasopresor',
            color: 'red'
        });
    }
    
    if (document.getElementById('meningitis-sospecha')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🧠 SOSPECHA MENINGITIS - Antibióticos empíricos urgentes',
            color: 'red'
        });
    }
    
    if (document.getElementById('microorganismo-mdr')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🛡️ MICROORGANISMO MDR - Reevaluar esquema antibiótico',
            color: 'orange'
        });
    }
    
    // Calcular escalas
    calculateSOFA();
    calculateqSOFA();
    calculateCURB65();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateSOFA() {
    let sofaScore = 0;
    
    // Sistema respiratorio (PaO2/FiO2)
    const pao2fio2 = document.getElementById('sofa-respiratorio')?.value;
    if (pao2fio2) sofaScore += parseInt(pao2fio2);
    
    // Sistema nervioso (Glasgow)
    const glasgow = document.getElementById('sofa-neurologico')?.value;
    if (glasgow) sofaScore += parseInt(glasgow);
    
    // Sistema cardiovascular
    const cardiovascular = document.getElementById('sofa-cardiovascular')?.value;
    if (cardiovascular) sofaScore += parseInt(cardiovascular);
    
    // Hígado (Bilirrubina)
    const higado = document.getElementById('sofa-hepatico')?.value;
    if (higado) sofaScore += parseInt(higado);
    
    // Coagulación (Plaquetas)
    const plaquetas = document.getElementById('sofa-coagulacion')?.value;
    if (plaquetas) sofaScore += parseInt(plaquetas);
    
    // Renal (Creatinina)
    const renal = document.getElementById('sofa-renal')?.value;
    if (renal) sofaScore += parseInt(renal);
    
    if (sofaScore > 0) {
        let riesgo = '';
        if (sofaScore <= 6) riesgo = 'Bajo riesgo (<10% mortalidad)';
        else if (sofaScore <= 9) riesgo = 'Riesgo intermedio (15-20% mortalidad)';
        else if (sofaScore <= 12) riesgo = 'Alto riesgo (40-50% mortalidad)';
        else riesgo = 'Muy alto riesgo (>80% mortalidad)';
        
        escalas.push({
            nombre: 'SOFA',
            valor: sofaScore,
            interpretacion: riesgo,
            color: sofaScore <= 6 ? 'green' : sofaScore <= 9 ? 'orange' : 'red'
        });
    }
}

function calculateqSOFA() {
    let qsofaScore = 0;
    
    if (document.getElementById('qsofa-alteracion-mental')?.checked) qsofaScore++;
    if (document.getElementById('qsofa-pas-bajo')?.checked) qsofaScore++;
    if (document.getElementById('qsofa-taquipnea')?.checked) qsofaScore++;
    
    if (qsofaScore >= 0) {
        let interpretacion = '';
        if (qsofaScore >= 2) interpretacion = 'Alto riesgo sepsis - Evaluación urgente';
        else interpretacion = 'Bajo riesgo sepsis';
        
        escalas.push({
            nombre: 'qSOFA',
            valor: `${qsofaScore}/3`,
            interpretacion: interpretacion,
            color: qsofaScore >= 2 ? 'red' : 'green'
        });
    }
}

function calculateCURB65() {
    let curbScore = 0;
    
    if (document.getElementById('curb-confusion')?.checked) curbScore++;
    if (document.getElementById('curb-urea')?.checked) curbScore++;
    if (document.getElementById('curb-respiratory')?.checked) curbScore++;
    if (document.getElementById('curb-pressure')?.checked) curbScore++;
    if (document.getElementById('curb-age')?.checked) curbScore++;
    
    if (curbScore >= 0) {
        let riesgo = '';
        if (curbScore <= 1) riesgo = 'Bajo riesgo - Manejo ambulatorio';
        else if (curbScore <= 2) riesgo = 'Riesgo intermedio - Considerar hospitalización';
        else riesgo = 'Alto riesgo - Hospitalización + considerar UCI';
        
        escalas.push({
            nombre: 'CURB-65',
            valor: `${curbScore}/5`,
            interpretacion: riesgo,
            color: curbScore <= 1 ? 'green' : curbScore <= 2 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkInfectiousAlertsAndScales;
```
