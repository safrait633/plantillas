# ⚡ ENDOCRINOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/endocrinologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Endocrinología"
[COLOR_TEMA] → "yellow-500"
```

## ⚡ Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-activity h-8 w-8 text-indigo-300">
    <path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Endocrinos (poliuria, polidipsia, pérdida peso)
2. Diabetes y Metabolismo
3. Tiroides y Paratiroides
4. Glándulas Suprarrenales
5. Escalas (HbA1c, HOMA-IR, riesgo cardiovascular)
6. Plan Endocrinológico

## ⚙️ Alertas Críticas:
- Cetoacidosis diabética
- Crisis tirotóxica
- Hipoglucemia severa
- Crisis suprarrenal

---

# 🩸 HEMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/hematologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Hematología"
[COLOR_TEMA] → "red-600"
```

## 🩸 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-droplet h-8 w-8 text-indigo-300">
    <path d="M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Hematológicos (astenia, palidez, equimosis)
2. Adenopatías y Esplenomegalia
3. Hemograma y Coagulación
4. Médula Ósea y Linfomas
5. Escalas (Wells, CHADS2, HAS-BLED)
6. Plan Hematológico

## ⚙️ Alertas Críticas:
- Pancitopenia
- Blastos en sangre periférica
- Adenopatías generalizadas
- Sangrado activo + coagulopatía

---

# 🦴 REUMATOLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/reumatologia.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Reumatología"
[COLOR_TEMA] → "amber-500"
```

## 🦴 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bone h-8 w-8 text-indigo-300">
    <path d="M17 10c.7-.7 1.69 0 2.5 0a2.5 2.5 0 1 0 0-5 .5.5 0 0 1-.5-.5 2.5 2.5 0 1 0-5 0c0 .81.7 1.8 0 2.5l-7 7c-.7.7-1.69 0-2.5 0a2.5 2.5 0 0 0 0 5c.28 0 .5.22.5.5a2.5 2.5 0 1 0 5 0c0-.81-.7-1.8 0-2.5Z"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Articulares (dolor, rigidez, inflamación)
2. Exploración Articular Sistemática
3. Enfermedades Autoinmunes
4. Escalas (DAS28, HAQ, BASDAI)
5. Plan Reumatológico

## ⚙️ Alertas Críticas:
- Artritis aguda monoarticular
- Síntomas sistémicos + artritis
- Rigidez matutina prolongada
- Deformidades articulares

---

# 👴 GERIATRÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/geriatria.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Geriatría"
[COLOR_TEMA] → "gray-500"
```

## 👴 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users h-8 w-8 text-indigo-300">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="m22 21-2-2"/>
    <path d="m16 16 2 2"/>
    <path d="m22 16-6 6"/>
</svg>
```

## 🏗️ Secciones:
1. Síndromes Geriátricos (caídas, deterioro cognitivo, incontinencia)
2. Valoración Funcional (AVD, AIVD)
3. Estado Cognitivo y Afectivo
4. Escalas Geriátricas (Barthel, Mini-Mental, GDS)
5. Plan Geriátrico Integral

## ⚙️ Alertas Críticas:
- Caídas recurrentes
- Deterioro cognitivo agudo
- Polifarmacia + efectos adversos
- Síndrome de fragilidad

---

# 🧩 PSIQUIATRÍA - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/psiquiatria.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Psiquiatría"
[COLOR_TEMA] → "indigo-500"
```

## 🧩 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-brain-circuit h-8 w-8 text-indigo-300">
    <path d="M12 5a3 3 0 1 0-5.997.142 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588 4 4 0 1 0 7.636 2.106 3.2 3.2 0 0 0 .164-.546c.071-.25.108-.503.108-.762"/>
    <path d="M12 5a3 3 0 1 1 5.997.142 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588 4 4 0 1 1-7.636 2.106 3.2 3.2 0 0 1-.164-.546c-.071-.25-.108-.503-.108-.762"/>
    <path d="M15.828 7.172a2.828 2.828 0 0 0-4 4"/>
    <path d="M8 12h.01"/>
    <path d="M16 12h.01"/>
    <path d="M12 16h.01"/>
</svg>
```

## 🏗️ Secciones:
1. Síntomas Psiquiátricos (ánimo, ansiedad, psicosis)
2. Examen del Estado Mental
3. Escalas Psiquiátricas (PHQ-9, GAD-7, PANSS)
4. Riesgo Suicida y Heteroagresividad
5. Plan Psiquiátrico

## ⚙️ Alertas Críticas:
- Ideación suicida activa
- Síntomas psicóticos agudos
- Crisis de ansiedad severa
- Riesgo de heteroagresividad

---

# 🦠 ENFERMEDADES INFECCIOSAS - Especificaciones de Adaptación

## 🎯 Archivo: `/algoritmos_nuevo_diseño/enfermedades_infecciosas.html`
**Usa**: PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos
```
[ESPECIALIDAD] → "Enfermedades Infecciosas"
[COLOR_TEMA] → "green-600"
```

## 🦠 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-bug h-8 w-8 text-indigo-300">
    <path d="m8 2 1.88 1.88"/>
    <path d="M14.12 3.88 16 2"/>
    <path d="M9 7.13v-1a3.003 3.003 0 1 1 6 0v1"/>
    <path d="M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/>
    <path d="M12 20v-9"/>
    <path d="M6.53 9C4.6 8.8 3 7.1 3 5"/>
    <path d="M6 13H2"/>
    <path d="M3 21c0-2.1 1.7-3.9 3.8-4"/>
    <path d="M20.97 5c0 2.1-1.6 3.8-3.5 4"/>
    <path d="M22 13h-4"/>
    <path d="M17.2 17c2.1.1 3.8 1.9 3.8 4"/>
</svg>
```

## 🏗️ Secciones:
1. Síndrome Febril (fiebre, escalofríos, malestar)
2. Infecciones por Aparatos
3. Factores de Riesgo Infeccioso
4. Escalas (qSOFA, APACHE, CURB-65)
5. Plan Antimicrobiano

## ⚙️ Alertas Críticas:
- Sepsis/shock séptico
- Fiebre + neutropenia
- Meningitis sospechosa
- Infección nosocomial resistente

---

# 📋 RESUMEN ICONOS Y COLORES

| Especialidad | Icono | Color | Archivo |
|-------------|-------|--------|---------|
| Cardiología | `heart` | red-500 | cardiologia.html |
| Neurología | `brain` | red-500 | neurologia.html |
| Neumología | `wind` | blue-500 | neumologia.html |
| Gastroenterología | `pill` | green-500 | gastroenterologia.html |
| Urología | `droplets` | blue-600 | urologia.html |
| Oftalmología | `eye` | purple-500 | oftalmologia.html |
| ORL | `ear` | orange-500 | otorrinolaringologia.html |
| Dermatología | `shield-check` | pink-500 | dermatologia.html |
| Endocrinología | `activity` | yellow-500 | endocrinologia.html |
| Hematología | `droplet` | red-600 | hematologia.html |
| Reumatología | `bone` | amber-500 | reumatologia.html |
| Geriatría | `users` | gray-500 | geriatria.html |
| Psiquiatría | `brain-circuit` | indigo-500 | psiquiatria.html |
| Inf. Infecciosas | `bug` | green-600 | enfermedades_infecciosas.html |

## ✅ TODOS LOS PROMPTS LISTOS PARA USO INDIVIDUAL
