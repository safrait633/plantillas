# 👴 GERIATRÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/geriatria.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Geriatría"
[NOMBRE_ESPECIALIDAD] → "Geriatría"
[COLOR_TEMA] → "gray-500"
```

### 👴 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-users h-8 w-8 text-indigo-300">
    <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="m22 21-2-2"/>
    <path d="m16 16 2 2"/>
    <path d="m22 16-6 6"/>
</svg>
```

## 🏗️ Secciones Médicas Geriátricas

### 1️⃣ Síndromes Geriátricos
- **Icono**: `lucide-users` (gray-500)
- **Contenido**: Caídas, deterioro cognitivo, incontinencia, inmovilismo
- **Alertas**: Caídas recurrentes, deterioro cognitivo agudo

### 2️⃣ Valoración Funcional
- **Icono**: `lucide-activity` (blue-400)
- **Contenido**: Actividades vida diaria, movilidad, equilibrio
- **Alertas**: Dependencia severa, pérdida funcional aguda

### 3️⃣ Estado Cognitivo y Afectivo
- **Icono**: `lucide-brain` (purple-400)
- **Contenido**: Mini-Mental, depresión, ansiedad, estado afectivo
- **Alertas**: Deterioro cognitivo severo, depresión mayor

### 4️⃣ Escalas Geriátricas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: Barthel, Mini-Mental, GDS, Tinetti
- **Escalas automáticas**: Cálculo automático escalas

## ⚙️ JavaScript Específico - Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkGeriatricAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Alertas críticas geriátricas
    if (document.getElementById('caidas-recurrentes')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '⚠️ CAÍDAS RECURRENTES - Evaluar riesgo y prevención',
            color: 'orange'
        });
    }
    
    if (document.getElementById('deterioro-cognitivo-agudo')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🧠 DETERIORO COGNITIVO AGUDO - Descartar delirium',
            color: 'red'
        });
    }
    
    // Calcular escalas
    calculateBarthel();
    calculateMiniMental();
    updateAlertsUI();
    updateEscalasUI();
}

function calculateBarthel() {
    let barthelScore = 0;
    const actividades = [
        'comer', 'bañarse', 'vestirse', 'arreglarse', 'deposicion', 
        'miccion', 'usar-retrete', 'transferencia', 'movilidad', 'escalones'
    ];
    
    actividades.forEach(actividad => {
        const valor = document.getElementById(`barthel-${actividad}`)?.value;
        if (valor) barthelScore += parseInt(valor);
    });
    
    if (barthelScore >= 0) {
        let dependencia = '';
        if (barthelScore >= 90) dependencia = 'Independiente';
        else if (barthelScore >= 60) dependencia = 'Dependencia leve';
        else if (barthelScore >= 40) dependencia = 'Dependencia moderada';
        else if (barthelScore >= 20) dependencia = 'Dependencia severa';
        else dependencia = 'Dependencia total';
        
        escalas.push({
            nombre: 'Índice Barthel',
            valor: barthelScore,
            interpretacion: dependencia,
            color: barthelScore >= 60 ? 'green' : barthelScore >= 40 ? 'orange' : 'red'
        });
    }
}

function calculateMiniMental() {
    let mmseScore = 0;
    const dominios = [
        'orientacion-temporal', 'orientacion-espacial', 'registro',
        'atencion-calculo', 'recuerdo', 'lenguaje', 'construccion'
    ];
    
    dominios.forEach(dominio => {
        const valor = document.getElementById(`mmse-${dominio}`)?.value;
        if (valor) mmseScore += parseInt(valor);
    });
    
    if (mmseScore > 0) {
        let estado = '';
        if (mmseScore >= 24) estado = 'Normal';
        else if (mmseScore >= 18) estado = 'Deterioro cognitivo leve';
        else if (mmseScore >= 10) estado = 'Deterioro cognitivo moderado';
        else estado = 'Deterioro cognitivo severo';
        
        escalas.push({
            nombre: 'Mini-Mental',
            valor: `${mmseScore}/30`,
            interpretacion: estado,
            color: mmseScore >= 24 ? 'green' : mmseScore >= 18 ? 'orange' : 'red'
        });
    }
}

checkAlertsAndScales = checkGeriatricAlertsAndScales;
```
