# 🏥 GASTROENTEROLOGÍA - Especificaciones de Adaptación

## 🎯 Archivo a Adaptar
**Origen**: `/algoritmos_nuevo_diseño/gastroenterologia.html`
**Objetivo**: Adaptar usando PROMPT_GENERAL_ADAPTACION.md

## 📋 Reemplazos Específicos

### 🏷️ Placeholders
```
[ESPECIALIDAD] → "Gastroenterología"
[NOMBRE_ESPECIALIDAD] → "Gastroenterología"
[COLOR_TEMA] → "green-500"
```

### 🏥 Icono Específico
```html
[ICONO_ESPECIALIDAD] →
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pill h-8 w-8 text-indigo-300">
    <path d="m10.5 20.5 10-10a4.95 4.95 0 1 0-7-7l-10 10a4.95 4.95 0 1 0 7 7Z"/>
    <path d="m8.5 8.5 7 7"/>
</svg>
```

## 🏗️ Secciones Médicas Gastroenterológicas

### 1️⃣ Síntomas Digestivos
- **Icono**: `lucide-pill` (green-500)
- **Contenido**: Dolor abdominal, náuseas, vómitos, diarrea, estreñimiento
- **Alertas**: Dolor abdominal agudo severo, hemorragia digestiva

### 2️⃣ Factores de Riesgo Gastrointestinales
- **Icono**: `lucide-wine` (red-400)
- **Contenido**: Alcohol, medicamentos, infecciones, antecedentes familiares
- **Alertas**: Consumo excesivo alcohol, medicamentos hepatotóxicos

### 3️⃣ Exploración Abdominal
- **Icono**: `lucide-stethoscope` (blue-400)
- **Contenido**: Inspección, palpación, percusión, auscultación abdominal
- **Alertas**: Masa abdominal palpable, defensa abdominal

### 4️⃣ Función Hepática y Digestiva
- **Icono**: `lucide-activity` (yellow-400)
- **Contenido**: Enzimas hepáticas, bilirrubina, función pancreática
- **Alertas**: Ictericia + dolor, transaminasas muy elevadas

### 5️⃣ Escalas Gastroenterológicas
- **Icono**: `lucide-calculator` (purple-400)
- **Contenido**: Child-Pugh, MELD, Rome IV, Glasgow-Imrie
- **Escalas automáticas**: Cálculo en tiempo real

### 6️⃣ Plan de Manejo Gastroenterológico
- **Icono**: `lucide-clipboard-check` (green-400)
- **Contenido**: Diagnóstico diferencial, endoscopia, tratamiento

## 📊 Progreso del Examen - Secciones Grid
```html
[SECCIONES_PROGRESO] →
<div class="text-center">
    <div class="text-white text-xs font-medium">Síntomas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">F. Riesgo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Exploración</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Función</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Escalas</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
<div class="text-center">
    <div class="text-white text-xs font-medium">Manejo</div>
    <div class="text-blue-200 text-xs">0%</div>
</div>
```

## ⚙️ JavaScript Específico

### Inicialización de Secciones
```javascript
[INIT_SECTIONS] →
const secciones = ['sintomas', 'factores', 'exploracion', 'funcion', 'escalas', 'manejo'];
secciones.forEach(seccion => {
    progressData[seccion] = 0;
    calculateSectionProgress(seccion);
});
```

### Lógica de Alertas y Escalas
```javascript
[ALERTS_AND_SCALES_LOGIC] →
function checkGastroAlertsAndScales() {
    alertas = [];
    escalas = [];
    
    // Verificar alertas críticas gastroenterológicas
    if (document.getElementById('dolor-abdominal-severo')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '🚨 ABDOMEN AGUDO - Evaluación quirúrgica urgente',
            color: 'red'
        });
    }
    
    if (document.getElementById('hemorragia-digestiva')?.checked) {
        alertas.push({
            tipo: 'critical',
            mensaje: '⚠️ HEMORRAGIA DIGESTIVA - Estabilización hemodinámica',
            color: 'red'
        });
    }
    
    if (document.getElementById('ictericia-dolor')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🟡 ICTERICIA + DOLOR - Descartar colangitis',
            color: 'orange'
        });
    }
    
    if (document.getElementById('masa-abdominal')?.checked) {
        alertas.push({
            tipo: 'warning',
            mensaje: '🔍 MASA ABDOMINAL - Investigar malignidad',
            color: 'orange'
        });
    }
    
    // Calcular escalas gastroenterológicas automáticamente
    calculateChildPugh();
    calculateMELD();
    
    updateAlertsUI();
    updateEscalasUI();
}

function calculateChildPugh() {
    let childScore = 0;
    
    // Bilirrubina
    const bilirrubina = document.getElementById('bilirrubina')?.value;
    if (bilirrubina > 3) childScore += 3;
    else if (bilirrubina > 2) childScore += 2;
    else childScore += 1;
    
    // Albúmina
    const albumina = document.getElementById('albumina')?.value;
    if (albumina < 2.8) childScore += 3;
    else if (albumina < 3.5) childScore += 2;
    else childScore += 1;
    
    // Ascitis, encefalopatía, INR...
    
    if (childScore > 5) {
        let clase = '';
        if (childScore <= 6) clase = 'Child A (Compensado)';
        else if (childScore <= 9) clase = 'Child B (Moderado)';
        else clase = 'Child C (Descompensado)';
        
        escalas.push({
            nombre: 'Child-Pugh',
            valor: childScore,
            interpretacion: clase,
            color: childScore <= 6 ? 'green' : childScore <= 9 ? 'orange' : 'red'
        });
    }
}

function calculateMELD() {
    const creatinina = document.getElementById('creatinina')?.value;
    const bilirrubina = document.getElementById('bilirrubina')?.value;
    const inr = document.getElementById('inr')?.value;
    
    if (creatinina && bilirrubina && inr) {
        const meld = Math.round(3.78 * Math.log(bilirrubina) + 11.2 * Math.log(inr) + 9.57 * Math.log(creatinina) + 6.43);
        
        escalas.push({
            nombre: 'MELD',
            valor: meld,
            interpretacion: meld > 40 ? 'Muy alto riesgo' : meld > 30 ? 'Alto riesgo' : meld > 20 ? 'Riesgo moderado' : 'Bajo riesgo',
            color: meld > 30 ? 'red' : meld > 20 ? 'orange' : 'green'
        });
    }
}

checkAlertsAndScales = checkGastroAlertsAndScales;
```

## 🎯 Resultado Final
- **Interfaz 100% idéntica** a medical-exams-v2.mhtml
- **Toda la información gastroenterológica** preservada
- **Escalas Child-Pugh, MELD, Rome IV** funcionando
- **Alertas dinámicas** para emergencias GI
- **Progreso automático** por secciones
