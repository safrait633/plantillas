# Liquid Glass - Design Tokens и Theming

Комплексная система дизайн-токенов для создания консистентных и масштабируемых Liquid Glass интерфейсов на всех платформах.

## Содержание

1. [Основы Design Tokens](#основы-design-tokens)
2. [Цветовая система](#цветовая-система)
3. [Размытие и прозрачность](#размытие-и-прозрачность)
4. [Типографика](#типографика)
5. [Spacing и Layout](#spacing-и-layout)
6. [Анимация и Timing](#анимация-и-timing)
7. [Темы и вариации](#темы-и-вариации)
8. [Cross-Platform реализация](#cross-platform-реализация)

---

## Основы Design Tokens

### Структура токенов

```json
{
  "liquid-glass": {
    "color": {
      "background": {
        "primary": {
          "value": "rgba(255, 255, 255, 0.8)",
          "type": "color",
          "description": "Основной фон glass элементов"
        },
        "secondary": {
          "value": "rgba(255, 255, 255, 0.6)",
          "type": "color",
          "description": "Вторичный фон glass элементов"
        },
        "elevated": {
          "value": "rgba(255, 255, 255, 0.9)",
          "type": "color",
          "description": "Приподнятые glass элементы"
        }
      },
      "border": {
        "default": {
          "value": "rgba(255, 255, 255, 0.3)",
          "type": "color",
          "description": "Стандартная граница glass элементов"
        },
        "highlight": {
          "value": "rgba(255, 255, 255, 0.5)",
          "type": "color",
          "description": "Подсвеченная граница"
        }
      }
    },
    "blur": {
      "subtle": {
        "value": "4px",
        "type": "blur",
        "description": "Легкое размытие"
      },
      "medium": {
        "value": "12px",
        "type": "blur",
        "description": "Среднее размытие"
      },
      "strong": {
        "value": "24px",
        "type": "blur",
        "description": "Сильное размытие"
      },
      "extreme": {
        "value": "40px",
        "type": "blur",
        "description": "Экстремальное размытие"
      }
    },
    "opacity": {
      "ghost": {
        "value": "0.1",
        "type": "number",
        "description": "Едва заметная прозрачность"
      },
      "subtle": {
        "value": "0.3",
        "type": "number",
        "description": "Легкая прозрачность"
      },
      "medium": {
        "value": "0.6",
        "type": "number",
        "description": "Средняя прозрачность"
      },
      "strong": {
        "value": "0.8",
        "type": "number",
        "description": "Сильная прозрачность"
      },
      "solid": {
        "value": "0.95",
        "type": "number",
        "description": "Почти непрозрачный"
      }
    },
    "shadow": {
      "soft": {
        "value": "0 2px 8px rgba(0, 0, 0, 0.1)",
        "type": "boxShadow",
        "description": "Мягкая тень"
      },
      "medium": {
        "value": "0 4px 16px rgba(0, 0, 0, 0.15)",
        "type": "boxShadow",
        "description": "Средняя тень"
      },
      "strong": {
        "value": "0 8px 32px rgba(0, 0, 0, 0.2)",
        "type": "boxShadow",
        "description": "Сильная тень"
      }
    },
    "border-radius": {
      "small": {
        "value": "8px",
        "type": "borderRadius",
        "description": "Маленькое скругление"
      },
      "medium": {
        "value": "16px",
        "type": "borderRadius",
        "description": "Среднее скругление"
      },
      "large": {
        "value": "24px",
        "type": "borderRadius",
        "description": "Большое скругление"
      },
      "circular": {
        "value": "50%",
        "type": "borderRadius",
        "description": "Круглое скругление"
      }
    }
  }
}
```

### Token Categories

```javascript
// Система категоризации токенов
const TokenCategories = {
  // Global tokens - базовые значения
  global: {
    color: {
      white: '#FFFFFF',
      black: '#000000',
      transparent: 'transparent'
    },
    size: {
      base: '16px',
      scale: 1.25 // modular scale
    }
  },
  
  // Alias tokens - семантические значения
  alias: {
    color: {
      surface: {
        primary: 'var(--lg-color-background-primary)',
        secondary: 'var(--lg-color-background-secondary)'
      },
      text: {
        primary: 'var(--lg-color-text-primary)',
        secondary: 'var(--lg-color-text-secondary)'
      }
    }
  },
  
  // Component tokens - специфичные для компонентов
  component: {
    'glass-card': {
      background: 'var(--lg-alias-color-surface-primary)',
      border: 'var(--lg-color-border-default)',
      blur: 'var(--lg-blur-medium)'
    },
    'glass-button': {
      background: 'var(--lg-alias-color-surface-secondary)',
      'background-hover': 'var(--lg-color-background-elevated)',
      blur: 'var(--lg-blur-subtle)'
    }
  }
};
```

---

## Цветовая система

### Adaptive Color System

```css
/* CSS Custom Properties для цветовой системы */
:root {
  /* Base colors */
  --lg-color-white: #ffffff;
  --lg-color-black: #000000;
  --lg-color-transparent: transparent;
  
  /* Light theme glass colors */
  --lg-color-background-primary: rgba(255, 255, 255, 0.8);
  --lg-color-background-secondary: rgba(255, 255, 255, 0.6);
  --lg-color-background-tertiary: rgba(255, 255, 255, 0.4);
  --lg-color-background-elevated: rgba(255, 255, 255, 0.9);
  
  /* Text colors */
  --lg-color-text-primary: rgba(0, 0, 0, 0.9);
  --lg-color-text-secondary: rgba(0, 0, 0, 0.7);
  --lg-color-text-tertiary: rgba(0, 0, 0, 0.5);
  
  /* Border colors */
  --lg-color-border-default: rgba(255, 255, 255, 0.3);
  --lg-color-border-highlight: rgba(255, 255, 255, 0.5);
  --lg-color-border-strong: rgba(255, 255, 255, 0.7);
  
  /* Accent colors */
  --lg-color-accent-blue: rgba(0, 122, 255, 0.8);
  --lg-color-accent-green: rgba(52, 199, 89, 0.8);
  --lg-color-accent-red: rgba(255, 59, 48, 0.8);
  --lg-color-accent-orange: rgba(255, 149, 0, 0.8);
  
  /* State colors */
  --lg-color-state-hover: rgba(255, 255, 255, 0.2);
  --lg-color-state-active: rgba(255, 255, 255, 0.4);
  --lg-color-state-focus: rgba(0, 122, 255, 0.3);
  --lg-color-state-disabled: rgba(255, 255, 255, 0.1);
}

/* Dark theme */
[data-theme="dark"] {
  --lg-color-background-primary: rgba(0, 0, 0, 0.8);
  --lg-color-background-secondary: rgba(0, 0, 0, 0.6);
  --lg-color-background-tertiary: rgba(0, 0, 0, 0.4);
  --lg-color-background-elevated: rgba(0, 0, 0, 0.9);
  
  --lg-color-text-primary: rgba(255, 255, 255, 0.9);
  --lg-color-text-secondary: rgba(255, 255, 255, 0.7);
  --lg-color-text-tertiary: rgba(255, 255, 255, 0.5);
  
  --lg-color-border-default: rgba(255, 255, 255, 0.2);
  --lg-color-border-highlight: rgba(255, 255, 255, 0.3);
  --lg-color-border-strong: rgba(255, 255, 255, 0.5);
  
  --lg-color-state-hover: rgba(0, 0, 0, 0.2);
  --lg-color-state-active: rgba(0, 0, 0, 0.4);
}

/* High contrast mode */
@media (prefers-contrast: high) {
  :root {
    --lg-color-background-primary: rgba(255, 255, 255, 0.95);
    --lg-color-border-default: rgba(0, 0, 0, 0.5);
    --lg-color-text-primary: rgba(0, 0, 0, 1);
  }
  
  [data-theme="dark"] {
    --lg-color-background-primary: rgba(0, 0, 0, 0.95);
    --lg-color-border-default: rgba(255, 255, 255, 0.5);
    --lg-color-text-primary: rgba(255, 255, 255, 1);
  }
}

/* Reduced transparency mode */
@media (prefers-reduced-transparency: reduce) {
  :root {
    --lg-color-background-primary: rgba(255, 255, 255, 0.95);
    --lg-color-background-secondary: rgba(255, 255, 255, 0.9);
    --lg-color-background-tertiary: rgba(255, 255, 255, 0.85);
  }
}
```

### Color Generation System

```javascript
class LiquidGlassColorSystem {
  constructor() {
    this.baseColors = {
      white: [255, 255, 255],
      black: [0, 0, 0]
    };
    
    this.opacityLevels = {
      ghost: 0.1,
      subtle: 0.3,
      light: 0.4,
      medium: 0.6,
      strong: 0.8,
      solid: 0.95
    };
    
    this.contrastModes = {
      normal: 1,
      high: 1.5,
      maximum: 2
    };
  }
  
  generateGlassColor(baseColor, opacity, theme = 'light') {
    const [r, g, b] = this.parseColor(baseColor);
    const adjustedOpacity = this.adjustOpacityForTheme(opacity, theme);
    
    return `rgba(${r}, ${g}, ${b}, ${adjustedOpacity})`;
  }
  
  generateColorScale(baseColor, steps = 5) {
    const colors = [];
    const opacityKeys = Object.keys(this.opacityLevels);
    
    for (let i = 0; i < Math.min(steps, opacityKeys.length); i++) {
      const opacityKey = opacityKeys[i];
      const opacity = this.opacityLevels[opacityKey];
      
      colors.push({
        name: opacityKey,
        value: this.generateGlassColor(baseColor, opacity),
        opacity: opacity
      });
    }
    
    return colors;
  }
  
  adjustOpacityForTheme(opacity, theme) {
    if (theme === 'dark') {
      // В темной теме уменьшаем прозрачность для лучшей читаемости
      return Math.min(1, opacity * 1.2);
    }
    
    return opacity;
  }
  
  adjustForContrast(color, contrastMode) {
    const multiplier = this.contrastModes[contrastMode] || 1;
    const [r, g, b, a] = this.parseColorWithAlpha(color);
    
    // Увеличиваем альфа-канал для высокого контраста
    const adjustedAlpha = Math.min(1, a * multiplier);
    
    return `rgba(${r}, ${g}, ${b}, ${adjustedAlpha})`;
  }
  
  generateThemeVariant(baseTheme, variant) {
    const themes = {
      vibrant: (color) => this.adjustSaturation(color, 1.3),
      muted: (color) => this.adjustSaturation(color, 0.7),
      warm: (color) => this.adjustTemperature(color, 10),
      cool: (color) => this.adjustTemperature(color, -10)
    };
    
    const transformer = themes[variant];
    if (!transformer) return baseTheme;
    
    const newTheme = {};
    for (const [key, value] of Object.entries(baseTheme)) {
      if (typeof value === 'string' && value.startsWith('rgba(')) {
        newTheme[key] = transformer(value);
      } else {
        newTheme[key] = value;
      }
    }
    
    return newTheme;
  }
  
  parseColor(color) {
    if (typeof color === 'string') {
      if (color.startsWith('#')) {
        return this.hexToRgb(color);
      } else if (color.startsWith('rgb')) {
        return this.parseRgb(color);
      }
    } else if (Array.isArray(color)) {
      return color;
    }
    
    return [255, 255, 255]; // fallback
  }
  
  parseColorWithAlpha(color) {
    const match = color.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/);
    if (match) {
      return [
        parseInt(match[1]),
        parseInt(match[2]),
        parseInt(match[3]),
        parseFloat(match[4] || '1')
      ];
    }
    
    return [255, 255, 255, 1];
  }
  
  hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? [
      parseInt(result[1], 16),
      parseInt(result[2], 16),
      parseInt(result[3], 16)
    ] : [255, 255, 255];
  }
  
  parseRgb(rgb) {
    const match = rgb.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/);
    return match ? [
      parseInt(match[1]),
      parseInt(match[2]),
      parseInt(match[3])
    ] : [255, 255, 255];
  }
  
  generateCSSVariables(theme = 'light') {
    const colors = this.generateCompleteColorSystem(theme);
    let css = `:root {\n`;
    
    for (const [category, values] of Object.entries(colors)) {
      for (const [name, value] of Object.entries(values)) {
        css += `  --lg-color-${category}-${name}: ${value};\n`;
      }
    }
    
    css += `}\n`;
    return css;
  }
  
  generateCompleteColorSystem(theme) {
    const base = theme === 'dark' ? this.baseColors.black : this.baseColors.white;
    
    return {
      background: {
        primary: this.generateGlassColor(base, this.opacityLevels.strong, theme),
        secondary: this.generateGlassColor(base, this.opacityLevels.medium, theme),
        tertiary: this.generateGlassColor(base, this.opacityLevels.light, theme),
        elevated: this.generateGlassColor(base, this.opacityLevels.solid, theme)
      },
      border: {
        default: this.generateGlassColor(base, this.opacityLevels.subtle, theme),
        highlight: this.generateGlassColor(base, this.opacityLevels.medium, theme),
        strong: this.generateGlassColor(base, this.opacityLevels.strong, theme)
      },
      text: {
        primary: theme === 'dark' ? 'rgba(255, 255, 255, 0.9)' : 'rgba(0, 0, 0, 0.9)',
        secondary: theme === 'dark' ? 'rgba(255, 255, 255, 0.7)' : 'rgba(0, 0, 0, 0.7)',
        tertiary: theme === 'dark' ? 'rgba(255, 255, 255, 0.5)' : 'rgba(0, 0, 0, 0.5)'
      }
    };
  }
}

// Глобальная инициализация
const liquidGlassColors = new LiquidGlassColorSystem();

// Генерируем CSS переменные
document.head.appendChild(
  Object.assign(document.createElement('style'), {
    textContent: liquidGlassColors.generateCSSVariables('light')
  })
);
```

---

## Размытие и прозрачность

### Blur Token System

```css
/* Blur tokens */
:root {
  /* Basic blur levels */
  --lg-blur-none: 0px;
  --lg-blur-subtle: 4px;
  --lg-blur-small: 8px;
  --lg-blur-medium: 12px;
  --lg-blur-large: 20px;
  --lg-blur-extra-large: 32px;
  --lg-blur-extreme: 50px;
  
  /* Contextual blur levels */
  --lg-blur-card: var(--lg-blur-medium);
  --lg-blur-modal: var(--lg-blur-large);
  --lg-blur-navigation: var(--lg-blur-small);
  --lg-blur-overlay: var(--lg-blur-extra-large);
  
  /* Performance-based blur levels */
  --lg-blur-performance-low: var(--lg-blur-small);
  --lg-blur-performance-medium: var(--lg-blur-medium);
  --lg-blur-performance-high: var(--lg-blur-large);
}

/* Responsive blur - уменьшаем на мобильных для производительности */
@media (max-width: 768px) {
  :root {
    --lg-blur-card: var(--lg-blur-small);
    --lg-blur-modal: var(--lg-blur-medium);
    --lg-blur-overlay: var(--lg-blur-large);
  }
}

/* Reduce motion preference - отключаем blur */
@media (prefers-reduced-motion: reduce) {
  :root {
    --lg-blur-card: var(--lg-blur-none);
    --lg-blur-modal: var(--lg-blur-none);
    --lg-blur-navigation: var(--lg-blur-none);
    --lg-blur-overlay: var(--lg-blur-none);
  }
}

/* High performance mode */
.lg-performance-mode {
  --lg-blur-card: var(--lg-blur-subtle);
  --lg-blur-modal: var(--lg-blur-small);
  --lg-blur-overlay: var(--lg-blur-medium);
}
```

### Backdrop Filter System

```css
/* Backdrop filter composition */
:root {
  /* Simple backdrop filters */
  --lg-backdrop-none: none;
  --lg-backdrop-blur-subtle: blur(var(--lg-blur-subtle));
  --lg-backdrop-blur-medium: blur(var(--lg-blur-medium));
  --lg-backdrop-blur-strong: blur(var(--lg-blur-large));
  
  /* Complex backdrop filters */
  --lg-backdrop-glass-light: 
    blur(var(--lg-blur-medium)) 
    saturate(1.8) 
    brightness(1.1);
    
  --lg-backdrop-glass-dark: 
    blur(var(--lg-blur-medium)) 
    saturate(1.2) 
    brightness(0.8);
    
  --lg-backdrop-glass-vibrant: 
    blur(var(--lg-blur-medium)) 
    saturate(2.0) 
    contrast(1.2);
    
  --lg-backdrop-glass-muted: 
    blur(var(--lg-blur-medium)) 
    saturate(0.8) 
    brightness(0.95);
    
  /* Specialized effects */
  --lg-backdrop-frosted: 
    blur(var(--lg-blur-large)) 
    saturate(1.8) 
    brightness(1.2);
    
  --lg-backdrop-crystal: 
    blur(var(--lg-blur-small)) 
    saturate(2.5) 
    contrast(1.5);
    
  --lg-backdrop-smoke: 
    blur(var(--lg-blur-extra-large)) 
    saturate(0.5) 
    brightness(0.9);
}

/* Fallbacks для старых браузеров */
@supports not (backdrop-filter: blur(1px)) {
  :root {
    --lg-backdrop-glass-light: none;
    --lg-backdrop-glass-dark: none;
    --lg-backdrop-glass-vibrant: none;
  }
  
  .glass-element {
    background: var(--lg-color-background-primary) !important;
    border: 1px solid var(--lg-color-border-default) !important;
  }
}
```

---

## Типографика

### Typography Scale

```css
/* Typography tokens */
:root {
  /* Font families */
  --lg-font-family-primary: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  --lg-font-family-secondary: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
  --lg-font-family-mono: 'SF Mono', Monaco, 'Cascadia Code', monospace;
  
  /* Font weights */
  --lg-font-weight-light: 300;
  --lg-font-weight-normal: 400;
  --lg-font-weight-medium: 500;
  --lg-font-weight-semibold: 600;
  --lg-font-weight-bold: 700;
  
  /* Font sizes - Modular scale (1.25 ratio) */
  --lg-font-size-xs: 0.75rem;    /* 12px */
  --lg-font-size-sm: 0.875rem;   /* 14px */
  --lg-font-size-base: 1rem;     /* 16px */
  --lg-font-size-lg: 1.125rem;   /* 18px */
  --lg-font-size-xl: 1.25rem;    /* 20px */
  --lg-font-size-2xl: 1.5rem;    /* 24px */
  --lg-font-size-3xl: 1.875rem;  /* 30px */
  --lg-font-size-4xl: 2.25rem;   /* 36px */
  --lg-font-size-5xl: 3rem;      /* 48px */
  
  /* Line heights */
  --lg-line-height-tight: 1.25;
  --lg-line-height-snug: 1.375;
  --lg-line-height-normal: 1.5;
  --lg-line-height-relaxed: 1.625;
  --lg-line-height-loose: 2;
  
  /* Letter spacing */
  --lg-letter-spacing-tight: -0.025em;
  --lg-letter-spacing-normal: 0;
  --lg-letter-spacing-wide: 0.025em;
  --lg-letter-spacing-wider: 0.05em;
  --lg-letter-spacing-widest: 0.1em;
}

/* Typography styles for glass elements */
.lg-text {
  /* Улучшенная читаемость на стеклянном фоне */
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.lg-text-on-glass {
  /* Специальные стили для текста на glass */
  color: var(--lg-color-text-primary);
  text-shadow: 
    0 0 1px rgba(255, 255, 255, 0.8),
    0 1px 2px rgba(0, 0, 0, 0.2);
}

/* Адаптивная типографика */
@media (max-width: 768px) {
  :root {
    --lg-font-size-3xl: 1.5rem;   /* Уменьшаем на мобильных */
    --lg-font-size-4xl: 1.875rem;
    --lg-font-size-5xl: 2.25rem;
  }
}
```

---

## Spacing и Layout

### Spacing System

```css
/* Spacing tokens - 8pt grid system */
:root {
  /* Base spacing unit */
  --lg-spacing-unit: 0.5rem; /* 8px */
  
  /* Spacing scale */
  --lg-spacing-0: 0;
  --lg-spacing-1: calc(var(--lg-spacing-unit) * 0.5); /* 4px */
  --lg-spacing-2: calc(var(--lg-spacing-unit) * 1);   /* 8px */
  --lg-spacing-3: calc(var(--lg-spacing-unit) * 1.5); /* 12px */
  --lg-spacing-4: calc(var(--lg-spacing-unit) * 2);   /* 16px */
  --lg-spacing-5: calc(var(--lg-spacing-unit) * 2.5); /* 20px */
  --lg-spacing-6: calc(var(--lg-spacing-unit) * 3);   /* 24px */
  --lg-spacing-8: calc(var(--lg-spacing-unit) * 4);   /* 32px */
  --lg-spacing-10: calc(var(--lg-spacing-unit) * 5);  /* 40px */
  --lg-spacing-12: calc(var(--lg-spacing-unit) * 6);  /* 48px */
  --lg-spacing-16: calc(var(--lg-spacing-unit) * 8);  /* 64px */
  --lg-spacing-20: calc(var(--lg-spacing-unit) * 10); /* 80px */
  --lg-spacing-24: calc(var(--lg-spacing-unit) * 12); /* 96px */
  --lg-spacing-32: calc(var(--lg-spacing-unit) * 16); /* 128px */
  
  /* Semantic spacing */
  --lg-spacing-xs: var(--lg-spacing-1);
  --lg-spacing-sm: var(--lg-spacing-2);
  --lg-spacing-md: var(--lg-spacing-4);
  --lg-spacing-lg: var(--lg-spacing-6);
  --lg-spacing-xl: var(--lg-spacing-8);
  --lg-spacing-2xl: var(--lg-spacing-12);
  --lg-spacing-3xl: var(--lg-spacing-16);
  
  /* Component specific spacing */
  --lg-spacing-card-padding: var(--lg-spacing-6);
  --lg-spacing-card-gap: var(--lg-spacing-4);
  --lg-spacing-button-padding-x: var(--lg-spacing-4);
  --lg-spacing-button-padding-y: var(--lg-spacing-2);
  --lg-spacing-modal-padding: var(--lg-spacing-8);
  --lg-spacing-section-gap: var(--lg-spacing-16);
}

/* Responsive spacing */
@media (max-width: 768px) {
  :root {
    --lg-spacing-card-padding: var(--lg-spacing-4);
    --lg-spacing-modal-padding: var(--lg-spacing-6);
    --lg-spacing-section-gap: var(--lg-spacing-12);
  }
}

/* Layout tokens */
:root {
  /* Widths */
  --lg-width-xs: 20rem;
  --lg-width-sm: 24rem;
  --lg-width-md: 28rem;
  --lg-width-lg: 32rem;
  --lg-width-xl: 36rem;
  --lg-width-2xl: 42rem;
  --lg-width-3xl: 48rem;
  --lg-width-4xl: 56rem;
  --lg-width-5xl: 64rem;
  --lg-width-6xl: 72rem;
  --lg-width-7xl: 80rem;
  --lg-width-full: 100%;
  
  /* Heights */
  --lg-height-screen: 100vh;
  --lg-height-screen-small: 100svh; /* Small viewport height */
  --lg-height-screen-large: 100lvh; /* Large viewport height */
  --lg-height-screen-dynamic: 100dvh; /* Dynamic viewport height */
  
  /* Z-index scale */
  --lg-z-index-dropdown: 1000;
  --lg-z-index-sticky: 1020;
  --lg-z-index-fixed: 1030;
  --lg-z-index-modal-backdrop: 1040;
  --lg-z-index-modal: 1050;
  --lg-z-index-popover: 1060;
  --lg-z-index-tooltip: 1070;
  --lg-z-index-toast: 1080;
}
```

---

## Анимация и Timing

### Animation Tokens

```css
/* Animation timing tokens */
:root {
  /* Duration tokens */
  --lg-duration-instant: 0ms;
  --lg-duration-fast: 150ms;
  --lg-duration-normal: 250ms;
  --lg-duration-slow: 400ms;
  --lg-duration-slower: 600ms;
  --lg-duration-slowest: 1000ms;
  
  /* Easing functions */
  --lg-ease-linear: linear;
  --lg-ease-in: cubic-bezier(0.4, 0, 1, 1);
  --lg-ease-out: cubic-bezier(0, 0, 0.2, 1);
  --lg-ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
  
  /* Custom glass easing */
  --lg-ease-glass: cubic-bezier(0.25, 0.46, 0.45, 0.94);
  --lg-ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
  --lg-ease-elastic: cubic-bezier(0.175, 0.885, 0.32, 1.275);
  
  /* Component specific timings */
  --lg-transition-button: var(--lg-duration-fast) var(--lg-ease-glass);
  --lg-transition-card: var(--lg-duration-normal) var(--lg-ease-glass);
  --lg-transition-modal: var(--lg-duration-slow) var(--lg-ease-in-out);
  --lg-transition-tooltip: var(--lg-duration-fast) var(--lg-ease-out);
  
  /* Hover and interaction timings */
  --lg-transition-hover: var(--lg-duration-fast) var(--lg-ease-out);
  --lg-transition-focus: var(--lg-duration-fast) var(--lg-ease-out);
  --lg-transition-active: var(--lg-duration-instant) var(--lg-ease-linear);
}

/* Reduce motion preferences */
@media (prefers-reduced-motion: reduce) {
  :root {
    --lg-duration-fast: 0ms;
    --lg-duration-normal: 0ms;
    --lg-duration-slow: 0ms;
    --lg-duration-slower: 0ms;
    --lg-duration-slowest: 0ms;
    
    --lg-ease-glass: linear;
    --lg-ease-bounce: linear;
    --lg-ease-elastic: linear;
  }
}

/* Performance mode - более быстрые анимации */
.lg-performance-mode {
  --lg-duration-normal: var(--lg-duration-fast);
  --lg-duration-slow: var(--lg-duration-normal);
  --lg-duration-slower: var(--lg-duration-slow);
}
```

### Animation Presets

```css
/* Готовые анимации для glass элементов */
@keyframes lg-fade-in {
  from {
    opacity: 0;
    transform: translateY(10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes lg-scale-in {
  from {
    opacity: 0;
    transform: scale(0.9);
  }
  to {
    opacity: 1;
    transform: scale(1);
  }
}

@keyframes lg-slide-up {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

@keyframes lg-glass-shimmer {
  0% {
    background-position: -200% 0;
  }
  100% {
    background-position: 200% 0;
  }
}

/* Utility классы для анимаций */
.lg-animate-fade-in {
  animation: lg-fade-in var(--lg-duration-normal) var(--lg-ease-glass);
}

.lg-animate-scale-in {
  animation: lg-scale-in var(--lg-duration-normal) var(--lg-ease-glass);
}

.lg-animate-slide-up {
  animation: lg-slide-up var(--lg-duration-normal) var(--lg-ease-glass);
}

.lg-animate-shimmer {
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.4),
    transparent
  );
  background-size: 200% 100%;
  animation: lg-glass-shimmer 2s infinite;
}
```

---

## Темы и вариации

### Theme Management System

```javascript
class LiquidGlassThemeManager {
  constructor() {
    this.themes = new Map();
    this.currentTheme = 'light';
    this.userPreferences = this.loadUserPreferences();
    
    this.initializeDefaultThemes();
    this.setupSystemPreferenceListeners();
  }
  
  initializeDefaultThemes() {
    // Light theme
    this.registerTheme('light', {
      name: 'Light Glass',
      colors: {
        background: {
          primary: 'rgba(255, 255, 255, 0.8)',
          secondary: 'rgba(255, 255, 255, 0.6)',
          tertiary: 'rgba(255, 255, 255, 0.4)',
          elevated: 'rgba(255, 255, 255, 0.9)'
        },
        text: {
          primary: 'rgba(0, 0, 0, 0.9)',
          secondary: 'rgba(0, 0, 0, 0.7)',
          tertiary: 'rgba(0, 0, 0, 0.5)'
        },
        border: {
          default: 'rgba(255, 255, 255, 0.3)',
          highlight: 'rgba(255, 255, 255, 0.5)',
          strong: 'rgba(255, 255, 255, 0.7)'
        }
      },
      effects: {
        backdrop: 'blur(12px) saturate(1.8) brightness(1.1)',
        shadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
      }
    });
    
    // Dark theme
    this.registerTheme('dark', {
      name: 'Dark Glass',
      colors: {
        background: {
          primary: 'rgba(0, 0, 0, 0.8)',
          secondary: 'rgba(0, 0, 0, 0.6)',
          tertiary: 'rgba(0, 0, 0, 0.4)',
          elevated: 'rgba(0, 0, 0, 0.9)'
        },
        text: {
          primary: 'rgba(255, 255, 255, 0.9)',
          secondary: 'rgba(255, 255, 255, 0.7)',
          tertiary: 'rgba(255, 255, 255, 0.5)'
        },
        border: {
          default: 'rgba(255, 255, 255, 0.2)',
          highlight: 'rgba(255, 255, 255, 0.3)',
          strong: 'rgba(255, 255, 255, 0.5)'
        }
      },
      effects: {
        backdrop: 'blur(12px) saturate(1.2) brightness(0.8)',
        shadow: '0 8px 32px rgba(0, 0, 0, 0.3)'
      }
    });
    
    // Auto theme (system preference)
    this.registerTheme('auto', {
      name: 'Auto (System)',
      dynamic: true,
      resolver: () => {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        return prefersDark ? this.themes.get('dark') : this.themes.get('light');
      }
    });
    
    // Custom themes
    this.initializeCustomThemes();
  }
  
  initializeCustomThemes() {
    // Vibrant theme
    this.registerTheme('vibrant', {
      name: 'Vibrant Glass',
      extends: 'light',
      colors: {
        background: {
          primary: 'rgba(255, 255, 255, 0.7)',
          secondary: 'rgba(255, 255, 255, 0.5)',
          tertiary: 'rgba(255, 255, 255, 0.3)'
        }
      },
      effects: {
        backdrop: 'blur(12px) saturate(2.5) brightness(1.2) contrast(1.1)',
        shadow: '0 8px 32px rgba(0, 0, 0, 0.15)'
      }
    });
    
    // Muted theme
    this.registerTheme('muted', {
      name: 'Muted Glass',
      extends: 'light',
      colors: {
        background: {
          primary: 'rgba(255, 255, 255, 0.9)',
          secondary: 'rgba(255, 255, 255, 0.8)',
          tertiary: 'rgba(255, 255, 255, 0.7)'
        }
      },
      effects: {
        backdrop: 'blur(8px) saturate(0.8) brightness(0.95)',
        shadow: '0 4px 16px rgba(0, 0, 0, 0.08)'
      }
    });
    
    // High contrast theme
    this.registerTheme('high-contrast', {
      name: 'High Contrast',
      colors: {
        background: {
          primary: 'rgba(255, 255, 255, 0.98)',
          secondary: 'rgba(255, 255, 255, 0.95)',
          tertiary: 'rgba(255, 255, 255, 0.92)',
          elevated: 'rgba(255, 255, 255, 1)'
        },
        text: {
          primary: 'rgba(0, 0, 0, 1)',
          secondary: 'rgba(0, 0, 0, 0.9)',
          tertiary: 'rgba(0, 0, 0, 0.8)'
        },
        border: {
          default: 'rgba(0, 0, 0, 0.5)',
          highlight: 'rgba(0, 0, 0, 0.7)',
          strong: 'rgba(0, 0, 0, 0.9)'
        }
      },
      effects: {
        backdrop: 'none',
        shadow: '0 2px 8px rgba(0, 0, 0, 0.3)'
      }
    });
  }
  
  registerTheme(id, theme) {
    this.themes.set(id, {
      id,
      ...theme,
      createdAt: new Date(),
      version: '1.0.0'
    });
  }
  
  setTheme(themeId) {
    const theme = this.themes.get(themeId);
    if (!theme) {
      console.warn(`Theme "${themeId}" not found`);
      return false;
    }
    
    const resolvedTheme = theme.dynamic ? theme.resolver() : theme;
    this.applyTheme(resolvedTheme);
    this.currentTheme = themeId;
    this.saveUserPreference('theme', themeId);
    
    // Dispatch theme change event
    this.dispatchThemeChangeEvent(resolvedTheme);
    
    return true;
  }
  
  applyTheme(theme) {
    const root = document.documentElement;
    
    // Remove existing theme classes
    root.classList.remove(...Array.from(root.classList).filter(c => c.startsWith('lg-theme-')));
    
    // Add new theme class
    root.classList.add(`lg-theme-${theme.id}`);
    
    // Apply CSS custom properties
    this.applyCSSProperties(theme);
    
    // Apply special theme attributes
    root.setAttribute('data-theme', theme.id);
    root.setAttribute('data-theme-name', theme.name);
  }
  
  applyCSSProperties(theme) {
    const root = document.documentElement;
    
    // Apply colors
    if (theme.colors) {
      this.applyColorProperties(theme.colors, '--lg-color');
    }
    
    // Apply effects
    if (theme.effects) {
      Object.entries(theme.effects).forEach(([key, value]) => {
        root.style.setProperty(`--lg-effect-${key}`, value);
      });
    }
    
    // Apply custom properties
    if (theme.customProperties) {
      Object.entries(theme.customProperties).forEach(([key, value]) => {
        root.style.setProperty(key, value);
      });
    }
  }
  
  applyColorProperties(colors, prefix, parent = '') {
    const root = document.documentElement;
    
    Object.entries(colors).forEach(([key, value]) => {
      const propertyName = parent ? `${prefix}-${parent}-${key}` : `${prefix}-${key}`;
      
      if (typeof value === 'object' && !Array.isArray(value)) {
        // Nested color object
        this.applyColorProperties(value, prefix, parent ? `${parent}-${key}` : key);
      } else {
        // Color value
        root.style.setProperty(propertyName, value);
      }
    });
  }
  
  createCustomTheme(baseThemeId, customizations) {
    const baseTheme = this.themes.get(baseThemeId);
    if (!baseTheme) {
      throw new Error(`Base theme "${baseThemeId}" not found`);
    }
    
    const customTheme = this.deepMerge(baseTheme, customizations);
    const themeId = `custom-${Date.now()}`;
    
    this.registerTheme(themeId, {
      ...customTheme,
      name: customizations.name || `Custom ${baseTheme.name}`,
      custom: true,
      baseTheme: baseThemeId
    });
    
    return themeId;
  }
  
  setupSystemPreferenceListeners() {
    // Listen for color scheme changes
    const colorSchemeQuery = window.matchMedia('(prefers-color-scheme: dark)');
    colorSchemeQuery.addEventListener('change', () => {
      if (this.currentTheme === 'auto') {
        this.setTheme('auto'); // Re-apply auto theme
      }
    });
    
    // Listen for contrast preference changes
    const contrastQuery = window.matchMedia('(prefers-contrast: high)');
    contrastQuery.addEventListener('change', (e) => {
      if (e.matches && this.userPreferences.autoHighContrast) {
        this.setTheme('high-contrast');
      } else if (!e.matches && this.currentTheme === 'high-contrast') {
        this.setTheme(this.userPreferences.fallbackTheme || 'light');
      }
    });
    
    // Listen for reduced motion preference changes
    const motionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    motionQuery.addEventListener('change', () => {
      this.updateMotionPreferences();
    });
  }
  
  updateMotionPreferences() {
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    document.documentElement.classList.toggle('lg-reduce-motion', prefersReducedMotion);
  }
  
  getAvailableThemes() {
    return Array.from(this.themes.entries()).map(([id, theme]) => ({
      id,
      name: theme.name,
      custom: theme.custom || false,
      dynamic: theme.dynamic || false
    }));
  }
  
  getCurrentTheme() {
    return this.themes.get(this.currentTheme);
  }
  
  exportTheme(themeId) {
    const theme = this.themes.get(themeId);
    if (!theme) return null;
    
    return {
      ...theme,
      exported: new Date().toISOString(),
      version: theme.version || '1.0.0'
    };
  }
  
  importTheme(themeData) {
    const themeId = themeData.id || `imported-${Date.now()}`;
    this.registerTheme(themeId, {
      ...themeData,
      imported: true,
      importedAt: new Date()
    });
    return themeId;
  }
  
  deepMerge(target, source) {
    const result = { ...target };
    
    Object.keys(source).forEach(key => {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key])) {
        result[key] = this.deepMerge(target[key] || {}, source[key]);
      } else {
        result[key] = source[key];
      }
    });
    
    return result;
  }
  
  dispatchThemeChangeEvent(theme) {
    const event = new CustomEvent('lg-theme-changed', {
      detail: {
        theme,
        themeId: this.currentTheme,
        timestamp: new Date()
      }
    });
    
    window.dispatchEvent(event);
  }
  
  loadUserPreferences() {
    try {
      const saved = localStorage.getItem('lg-user-preferences');
      return saved ? JSON.parse(saved) : {
        theme: 'auto',
        autoHighContrast: true,
        fallbackTheme: 'light'
      };
    } catch {
      return {
        theme: 'auto',
        autoHighContrast: true,
        fallbackTheme: 'light'
      };
    }
  }
  
  saveUserPreference(key, value) {
    this.userPreferences[key] = value;
    localStorage.setItem('lg-user-preferences', JSON.stringify(this.userPreferences));
  }
  
  initialize() {
    // Set initial theme based on user preference
    const preferredTheme = this.userPreferences.theme || 'auto';
    this.setTheme(preferredTheme);
    
    // Update motion preferences
    this.updateMotionPreferences();
    
    console.log('Liquid Glass Theme Manager initialized');
  }
}

// Global theme manager instance
const liquidGlassThemes = new LiquidGlassThemeManager();

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => liquidGlassThemes.initialize());
} else {
  liquidGlassThemes.initialize();
}

// Global API
window.liquidGlass = window.liquidGlass || {};
window.liquidGlass.themes = {
  setTheme: (id) => liquidGlassThemes.setTheme(id),
  getThemes: () => liquidGlassThemes.getAvailableThemes(),
  createCustomTheme: (base, custom) => liquidGlassThemes.createCustomTheme(base, custom),
  getCurrentTheme: () => liquidGlassThemes.getCurrentTheme(),
  exportTheme: (id) => liquidGlassThemes.exportTheme(id),
  importTheme: (data) => liquidGlassThemes.importTheme(data)
};
```

### Theme UI Component

```html
<!-- Theme Selector Component -->
<div class="lg-theme-selector" id="themeSelector">
  <label for="theme-select" class="lg-theme-label">
    Тема интерфейса:
  </label>
  
  <select id="theme-select" class="lg-theme-select">
    <option value="auto">🌗 Автоматически</option>
    <option value="light">☀️ Светлая</option>
    <option value="dark">🌙 Темная</option>
    <option value="vibrant">✨ Яркая</option>
    <option value="muted">🔇 Приглушенная</option>
    <option value="high-contrast">🔲 Высокий контраст</option>
  </select>
  
  <div class="lg-theme-preview" id="themePreview">
    <div class="lg-preview-card glass-element">
      <h3>Предпросмотр</h3>
      <p>Текст на стеклянном фоне</p>
      <button class="lg-preview-button glass-button">Кнопка</button>
    </div>
  </div>
  
  <div class="lg-theme-advanced" id="themeAdvanced">
    <h4>Дополнительные настройки</h4>
    
    <label class="lg-checkbox-label">
      <input type="checkbox" id="autoHighContrast" checked>
      Автоматически включать высокий контраст
    </label>
    
    <label class="lg-checkbox-label">
      <input type="checkbox" id="reduceMotion">
      Уменьшить анимации
    </label>
    
    <label class="lg-checkbox-label">
      <input type="checkbox" id="reduceTransparency">
      Уменьшить прозрачность
    </label>
  </div>
  
  <div class="lg-theme-actions">
    <button class="lg-button-secondary" id="exportTheme">
      Экспортировать тему
    </button>
    <button class="lg-button-secondary" id="importTheme">
      Импортировать тему
    </button>
    <button class="lg-button-primary" id="createCustomTheme">
      Создать свою тему
    </button>
  </div>
</div>

<style>
.lg-theme-selector {
  padding: var(--lg-spacing-6);
  background: var(--lg-color-background-secondary);
  backdrop-filter: var(--lg-backdrop-glass-light);
  border-radius: var(--lg-border-radius-large);
  border: 1px solid var(--lg-color-border-default);
  max-width: 400px;
}

.lg-theme-label {
  display: block;
  margin-bottom: var(--lg-spacing-2);
  color: var(--lg-color-text-primary);
  font-weight: var(--lg-font-weight-medium);
}

.lg-theme-select {
  width: 100%;
  padding: var(--lg-spacing-3);
  background: var(--lg-color-background-elevated);
  border: 1px solid var(--lg-color-border-default);
  border-radius: var(--lg-border-radius-medium);
  color: var(--lg-color-text-primary);
  margin-bottom: var(--lg-spacing-6);
}

.lg-preview-card {
  padding: var(--lg-spacing-4);
  margin: var(--lg-spacing-4) 0;
  text-align: center;
}

.lg-preview-button {
  padding: var(--lg-spacing-2) var(--lg-spacing-4);
  background: var(--lg-color-background-elevated);
  border: 1px solid var(--lg-color-border-highlight);
  border-radius: var(--lg-border-radius-small);
  color: var(--lg-color-text-primary);
  cursor: pointer;
  transition: var(--lg-transition-button);
}

.lg-checkbox-label {
  display: block;
  margin-bottom: var(--lg-spacing-3);
  color: var(--lg-color-text-secondary);
  cursor: pointer;
}

.lg-theme-actions {
  display: flex;
  gap: var(--lg-spacing-2);
  margin-top: var(--lg-spacing-6);
  flex-wrap: wrap;
}

.lg-button-primary,
.lg-button-secondary {
  padding: var(--lg-spacing-2) var(--lg-spacing-4);
  border-radius: var(--lg-border-radius-small);
  border: 1px solid var(--lg-color-border-default);
  cursor: pointer;
  transition: var(--lg-transition-button);
  font-size: var(--lg-font-size-sm);
}

.lg-button-primary {
  background: var(--lg-color-accent-blue);
  color: white;
}

.lg-button-secondary {
  background: var(--lg-color-background-elevated);
  color: var(--lg-color-text-primary);
}
</style>

<script>
// Theme selector functionality
document.addEventListener('DOMContentLoaded', function() {
  const themeSelect = document.getElementById('theme-select');
  const autoHighContrastCheckbox = document.getElementById('autoHighContrast');
  const reduceMotionCheckbox = document.getElementById('reduceMotion');
  const reduceTransparencyCheckbox = document.getElementById('reduceTransparency');
  
  // Set initial values
  const currentTheme = liquidGlassThemes.currentTheme;
  const userPrefs = liquidGlassThemes.userPreferences;
  
  themeSelect.value = currentTheme;
  autoHighContrastCheckbox.checked = userPrefs.autoHighContrast;
  reduceMotionCheckbox.checked = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  reduceTransparencyCheckbox.checked = userPrefs.reduceTransparency || false;
  
  // Theme change handler
  themeSelect.addEventListener('change', function() {
    liquidGlassThemes.setTheme(this.value);
  });
  
  // Preference change handlers
  autoHighContrastCheckbox.addEventListener('change', function() {
    liquidGlassThemes.saveUserPreference('autoHighContrast', this.checked);
  });
  
  reduceMotionCheckbox.addEventListener('change', function() {
    document.documentElement.classList.toggle('lg-reduce-motion', this.checked);
  });
  
  reduceTransparencyCheckbox.addEventListener('change', function() {
    liquidGlassThemes.saveUserPreference('reduceTransparency', this.checked);
    document.documentElement.classList.toggle('lg-reduce-transparency', this.checked);
  });
  
  // Export theme functionality
  document.getElementById('exportTheme').addEventListener('click', function() {
    const themeData = liquidGlassThemes.exportTheme(liquidGlassThemes.currentTheme);
    if (themeData) {
      const blob = new Blob([JSON.stringify(themeData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${themeData.name.replace(/\s+/g, '-').toLowerCase()}.json`;
      a.click();
      URL.revokeObjectURL(url);
    }
  });
  
  // Import theme functionality
  document.getElementById('importTheme').addEventListener('click', function() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.addEventListener('change', function(e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
          try {
            const themeData = JSON.parse(e.target.result);
            const themeId = liquidGlassThemes.importTheme(themeData);
            
            // Add to select options
            const option = document.createElement('option');
            option.value = themeId;
            option.textContent = `📥 ${themeData.name}`;
            themeSelect.appendChild(option);
            
            // Switch to imported theme
            themeSelect.value = themeId;
            liquidGlassThemes.setTheme(themeId);
            
            alert('Тема успешно импортирована!');
          } catch (error) {
            alert('Ошибка при импорте темы: ' + error.message);
          }
        };
        reader.readAsText(file);
      }
    });
    input.click();
  });
});
</script>
```

---

## Cross-Platform реализация

### iOS/Swift Implementation

```swift
// iOS Design Tokens
struct LiquidGlassTokens {
    // Color tokens
    struct Colors {
        // Background colors
        static let backgroundPrimary = UIColor(red: 1, green: 1, blue: 1, alpha: 0.8)
        static let backgroundSecondary = UIColor(red: 1, green: 1, blue: 1, alpha: 0.6)
        static let backgroundTertiary = UIColor(red: 1, green: 1, blue: 1, alpha: 0.4)
        static let backgroundElevated = UIColor(red: 1, green: 1, blue: 1, alpha: 0.9)
        
        // Text colors
        static let textPrimary = UIColor(red: 0, green: 0, blue: 0, alpha: 0.9)
        static let textSecondary = UIColor(red: 0, green: 0, blue: 0, alpha: 0.7)
        static let textTertiary = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        
        // Border colors
        static let borderDefault = UIColor(red: 1, green: 1, blue: 1, alpha: 0.3)
        static let borderHighlight = UIColor(red: 1, green: 1, blue: 1, alpha: 0.5)
        static let borderStrong = UIColor(red: 1, green: 1, blue: 1, alpha: 0.7)
        
        // Accent colors
        static let accentBlue = UIColor(red: 0, green: 0.478, blue: 1, alpha: 0.8)
        static let accentGreen = UIColor(red: 0.204, green: 0.78, blue: 0.349, alpha: 0.8)
        static let accentRed = UIColor(red: 1, green: 0.231, blue: 0.188, alpha: 0.8)
    }
    
    // Blur tokens
    struct Blur {
        static let subtle: CGFloat = 4
        static let small: CGFloat = 8
        static let medium: CGFloat = 12
        static let large: CGFloat = 20
        static let extraLarge: CGFloat = 32
        static let extreme: CGFloat = 50
    }
    
    // Spacing tokens
    struct Spacing {
        static let unit: CGFloat = 8
        static let xs: CGFloat = unit * 0.5    // 4pt
        static let sm: CGFloat = unit * 1      // 8pt
        static let md: CGFloat = unit * 2      // 16pt
        static let lg: CGFloat = unit * 3      // 24pt
        static let xl: CGFloat = unit * 4      // 32pt
        static let xxl: CGFloat = unit * 6     // 48pt
    }
    
    // Border radius tokens
    struct BorderRadius {
        static let small: CGFloat = 8
        static let medium: CGFloat = 16
        static let large: CGFloat = 24
        static let extraLarge: CGFloat = 32
    }
    
    // Animation tokens
    struct Animation {
        static let durationFast: TimeInterval = 0.15
        static let durationNormal: TimeInterval = 0.25
        static let durationSlow: TimeInterval = 0.4
        
        static let easeOut = CAMediaTimingFunction(controlPoints: 0, 0, 0.2, 1)
        static let easeInOut = CAMediaTimingFunction(controlPoints: 0.4, 0, 0.2, 1)
        static let easeGlass = CAMediaTimingFunction(controlPoints: 0.25, 0.46, 0.45, 0.94)
    }
    
    // Shadow tokens
    struct Shadow {
        static let soft = NSShadow().apply {
            $0.shadowOffset = CGSize(width: 0, height: 2)
            $0.shadowBlurRadius = 8
            $0.shadowColor = UIColor.black.withAlphaComponent(0.1)
        }
        
        static let medium = NSShadow().apply {
            $0.shadowOffset = CGSize(width: 0, height: 4)
            $0.shadowBlurRadius = 16
            $0.shadowColor = UIColor.black.withAlphaComponent(0.15)
        }
        
        static let strong = NSShadow().apply {
            $0.shadowOffset = CGSize(width: 0, height: 8)
            $0.shadowBlurRadius = 32
            $0.shadowColor = UIColor.black.withAlphaComponent(0.2)
        }
    }
}

// Theme manager для iOS
class LiquidGlassThemeManager: ObservableObject {
    @Published var currentTheme: LiquidGlassTheme = .light
    
    enum LiquidGlassTheme: CaseIterable {
        case light, dark, vibrant, muted, highContrast
        
        var displayName: String {
            switch self {
            case .light: return "Светлая"
            case .dark: return "Темная"
            case .vibrant: return "Яркая"
            case .muted: return "Приглушенная"
            case .highContrast: return "Высокий контраст"
            }
        }
    }
    
    func applyTheme(_ theme: LiquidGlassTheme) {
        currentTheme = theme
        updateAppearance()
    }
    
    private func updateAppearance() {
        // Update app-wide appearance based on current theme
        NotificationCenter.default.post(
            name: .liquidGlassThemeDidChange,
            object: currentTheme
        )
    }
}

// SwiftUI Environment
struct LiquidGlassEnvironment: EnvironmentKey {
    static let defaultValue = LiquidGlassThemeManager()
}

extension EnvironmentValues {
    var liquidGlassTheme: LiquidGlassThemeManager {
        get { self[LiquidGlassEnvironment.self] }
        set { self[LiquidGlassEnvironment.self] = newValue }
    }
}

// SwiftUI модификаторы
extension View {
    func liquidGlassStyle(
        blur: CGFloat = LiquidGlassTokens.Blur.medium,
        background: Color = Color(LiquidGlassTokens.Colors.backgroundPrimary),
        cornerRadius: CGFloat = LiquidGlassTokens.BorderRadius.medium
    ) -> some View {
        self
            .background(
                RoundedRectangle(cornerRadius: cornerRadius)
                    .fill(background)
                    .background(
                        .ultraThinMaterial,
                        in: RoundedRectangle(cornerRadius: cornerRadius)
                    )
            )
    }
    
    func liquidGlassCard() -> some View {
        self
            .padding(LiquidGlassTokens.Spacing.md)
            .liquidGlassStyle()
            .shadow(
                color: Color.black.opacity(0.1),
                radius: 8,
                x: 0,
                y: 4
            )
    }
}

// Utility extension
extension NSShadow {
    func apply(_ block: (NSShadow) -> Void) -> NSShadow {
        block(self)
        return self
    }
}

extension Notification.Name {
    static let liquidGlassThemeDidChange = Notification.Name("liquidGlassThemeDidChange")
}
```

### Android/Kotlin Implementation

```kotlin
// Android Design Tokens
object LiquidGlassTokens {
    // Color tokens
    object Colors {
        val backgroundPrimary = Color.parseColor("#CCFFFFFF") // rgba(255,255,255,0.8)
        val backgroundSecondary = Color.parseColor("#99FFFFFF") // rgba(255,255,255,0.6)
        val backgroundTertiary = Color.parseColor("#66FFFFFF") // rgba(255,255,255,0.4)
        val backgroundElevated = Color.parseColor("#E6FFFFFF") // rgba(255,255,255,0.9)
        
        val textPrimary = Color.parseColor("#E6000000") // rgba(0,0,0,0.9)
        val textSecondary = Color.parseColor("#B3000000") // rgba(0,0,0,0.7)
        val textTertiary = Color.parseColor("#80000000") // rgba(0,0,0,0.5)
        
        val borderDefault = Color.parseColor("#4DFFFFFF") // rgba(255,255,255,0.3)
        val borderHighlight = Color.parseColor("#80FFFFFF") // rgba(255,255,255,0.5)
        val borderStrong = Color.parseColor("#B3FFFFFF") // rgba(255,255,255,0.7)
        
        val accentBlue = Color.parseColor("#CC007AFF")
        val accentGreen = Color.parseColor("#CC34C759")
        val accentRed = Color.parseColor("#CCFF3B30")
    }
    
    // Dimensions
    object Dimensions {
        // Spacing
        const val spacingUnit = 8
        const val spacingXs = spacingUnit / 2    // 4dp
        const val spacingSm = spacingUnit * 1    // 8dp
        const val spacingMd = spacingUnit * 2    // 16dp
        const val spacingLg = spacingUnit * 3    // 24dp
        const val spacingXl = spacingUnit * 4    // 32dp
        const val spacingXxl = spacingUnit * 6   // 48dp
        
        // Border radius
        const val borderRadiusSmall = 8
        const val borderRadiusMedium = 16
        const val borderRadiusLarge = 24
        const val borderRadiusExtraLarge = 32
        
        // Blur radius
        const val blurSubtle = 4f
        const val blurSmall = 8f
        const val blurMedium = 12f
        const val blurLarge = 20f
        const val blurExtraLarge = 32f
        const val blurExtreme = 50f
    }
    
    // Animation durations
    object Animation {
        const val durationFast = 150L
        const val durationNormal = 250L
        const val durationSlow = 400L
        
        val interpolatorEaseOut = PathInterpolator(0f, 0f, 0.2f, 1f)
        val interpolatorEaseInOut = PathInterpolator(0.4f, 0f, 0.2f, 1f)
        val interpolatorGlass = PathInterpolator(0.25f, 0.46f, 0.45f, 0.94f)
    }
}

// Theme manager для Android
class LiquidGlassThemeManager(private val context: Context) {
    
    enum class Theme(val displayName: String) {
        LIGHT("Светлая"),
        DARK("Темная"),
        VIBRANT("Яркая"),
        MUTED("Приглушенная"),
        HIGH_CONTRAST("Высокий контраст"),
        AUTO("Автоматически")
    }
    
    private val _currentTheme = MutableLiveData<Theme>()
    val currentTheme: LiveData<Theme> = _currentTheme
    
    private val sharedPrefs = context.getSharedPreferences("liquid_glass_theme", Context.MODE_PRIVATE)
    
    init {
        loadSavedTheme()
        setupSystemThemeListener()
    }
    
    fun setTheme(theme: Theme) {
        _currentTheme.value = theme
        saveTheme(theme)
        applyTheme(theme)
    }
    
    private fun applyTheme(theme: Theme) {
        val resolvedTheme = when (theme) {
            Theme.AUTO -> getSystemTheme()
            else -> theme
        }
        
        // Update app theme
        updateActivityTheme(resolvedTheme)
        
        // Broadcast theme change
        val intent = Intent("com.liquidglass.THEME_CHANGED").apply {
            putExtra("theme", resolvedTheme.name)
        }
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent)
    }
    
    private fun getSystemTheme(): Theme {
        val isSystemDark = (context.resources.configuration.uiMode and 
                           Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return if (isSystemDark) Theme.DARK else Theme.LIGHT
    }
    
    private fun loadSavedTheme() {
        val savedTheme = sharedPrefs.getString("theme", Theme.AUTO.name)
        val theme = Theme.values().find { it.name == savedTheme } ?: Theme.AUTO
        _currentTheme.value = theme
    }
    
    private fun saveTheme(theme: Theme) {
        sharedPrefs.edit().putString("theme", theme.name).apply()
    }
    
    private fun setupSystemThemeListener() {
        // Listen for system theme changes
        context.registerReceiver(object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (_currentTheme.value == Theme.AUTO) {
                    applyTheme(Theme.AUTO)
                }
            }
        }, IntentFilter(Intent.ACTION_CONFIGURATION_CHANGED))
    }
    
    private fun updateActivityTheme(theme: Theme) {
        if (context is Activity) {
            val themeRes = when (theme) {
                Theme.LIGHT -> R.style.LiquidGlass_Light
                Theme.DARK -> R.style.LiquidGlass_Dark
                Theme.VIBRANT -> R.style.LiquidGlass_Vibrant
                Theme.MUTED -> R.style.LiquidGlass_Muted
                Theme.HIGH_CONTRAST -> R.style.LiquidGlass_HighContrast
                else -> R.style.LiquidGlass_Light
            }
            
            context.setTheme(themeRes)
            context.recreate()
        }
    }
}

// Jetpack Compose integration
@Composable
fun LiquidGlassTheme(
    theme: LiquidGlassThemeManager.Theme = LiquidGlassThemeManager.Theme.LIGHT,
    content: @Composable () -> Unit
) {
    val colors = when (theme) {
        LiquidGlassThemeManager.Theme.LIGHT -> lightColors()
        LiquidGlassThemeManager.Theme.DARK -> darkColors()
        LiquidGlassThemeManager.Theme.VIBRANT -> vibrantColors()
        LiquidGlassThemeManager.Theme.MUTED -> mutedColors()
        LiquidGlassThemeManager.Theme.HIGH_CONTRAST -> highContrastColors()
        else -> lightColors()
    }
    
    MaterialTheme(
        colors = colors,
        typography = liquidGlassTypography,
        shapes = liquidGlassShapes,
        content = content
    )
}

// Glass Card компонент для Compose
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    blur: Float = LiquidGlassTokens.Dimensions.blurMedium,
    backgroundColor: Color = Color.White.copy(alpha = 0.8f),
    borderColor: Color = Color.White.copy(alpha = 0.3f),
    cornerRadius: Dp = LiquidGlassTokens.Dimensions.borderRadiusMedium.dp,
    elevation: Dp = 8.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier,
        elevation = elevation,
        shape = RoundedCornerShape(cornerRadius),
        backgroundColor = backgroundColor,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(LiquidGlassTokens.Dimensions.spacingMd.dp),
            content = content
        )
    }
}

// Utility функции
private fun lightColors() = lightColors(
    primary = Color(LiquidGlassTokens.Colors.accentBlue),
    background = Color(LiquidGlassTokens.Colors.backgroundPrimary),
    surface = Color(LiquidGlassTokens.Colors.backgroundSecondary),
    onPrimary = Color.White,
    onBackground = Color(LiquidGlassTokens.Colors.textPrimary),
    onSurface = Color(LiquidGlassTokens.Colors.textPrimary)
)

private fun darkColors() = darkColors(
    primary = Color(LiquidGlassTokens.Colors.accentBlue),
    background = Color.Black.copy(alpha = 0.8f),
    surface = Color.Black.copy(alpha = 0.6f),
    onPrimary = Color.White,
    onBackground = Color.White.copy(alpha = 0.9f),
    onSurface = Color.White.copy(alpha = 0.9f)
)
```

---

## Build Tools Integration

### Style Dictionary Configuration

```javascript
// style-dictionary.config.js
const StyleDictionary = require('style-dictionary');
const { fileHeader, formattedVariables } = StyleDictionary.formatHelpers;

// Расширяем Style Dictionary для Liquid Glass
StyleDictionary.registerFormat({
  name: 'css/liquid-glass',
  formatter: function({ dictionary, file }) {
    return `${fileHeader({ file })}:root {\n${
      formattedVariables({
        format: 'css',
        dictionary,
        outputReferences: true
      })
    }\n}\n\n/* Liquid Glass Theme Variants */\n${generateThemeVariants(dictionary)}`;
  }
});

StyleDictionary.registerFormat({
  name: 'ios/swift-liquid-glass',
  formatter: function({ dictionary }) {
    return `// Liquid Glass Design Tokens
// Generated automatically, do not edit

import UIKit

public struct LiquidGlassTokens {
${dictionary.allTokens.map(token => {
  return `    /// ${token.comment || token.path.join(' ')}
    public static let ${token.name}: ${getSwiftType(token)} = ${getSwiftValue(token)}`;
}).join('\n')}
}`;
  }
});

StyleDictionary.registerFormat({
  name: 'android/kotlin-liquid-glass',
  formatter: function({ dictionary }) {
    return `// Liquid Glass Design Tokens
// Generated automatically, do not edit

package com.liquidglass.tokens

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object LiquidGlassTokens {
${dictionary.allTokens.map(token => {
  return `    /** ${token.comment || token.path.join(' ')} */
    val ${token.name} = ${getKotlinValue(token)}`;
}).join('\n')}
}`;
  }
});

// Основная конфигурация
module.exports = {
  source: ['tokens/**/*.json'],
  platforms: {
    // Web CSS
    css: {
      transformGroup: 'css',
      buildPath: 'dist/css/',
      files: [{
        destination: 'liquid-glass-tokens.css',
        format: 'css/liquid-glass'
      }]
    },
    
    // Sass variables
    scss: {
      transformGroup: 'scss',
      buildPath: 'dist/scss/',
      files: [{
        destination: 'liquid-glass-tokens.scss',
        format: 'scss/variables'
      }]
    },
    
    // iOS Swift
    ios: {
      transformGroup: 'ios',
      buildPath: 'dist/ios/',
      files: [{
        destination: 'LiquidGlassTokens.swift',
        format: 'ios/swift-liquid-glass',
        className: 'LiquidGlassTokens'
      }]
    },
    
    // Android Kotlin
    android: {
      transformGroup: 'android',
      buildPath: 'dist/android/',
      files: [{
        destination: 'LiquidGlassTokens.kt',
        format: 'android/kotlin-liquid-glass'
      }]
    },
    
    // React Native
    'react-native': {
      transformGroup: 'js',
      buildPath: 'dist/react-native/',
      files: [{
        destination: 'liquid-glass-tokens.js',
        format: 'javascript/es6'
      }]
    },
    
    // Flutter Dart
    flutter: {
      transformGroup: 'flutter',
      buildPath: 'dist/flutter/',
      files: [{
        destination: 'liquid_glass_tokens.dart',
        format: 'flutter/class.dart',
        className: 'LiquidGlassTokens'
      }]
    }
  }
};

// Вспомогательные функции
function generateThemeVariants(dictionary) {
  const themes = ['light', 'dark', 'vibrant', 'muted', 'high-contrast'];
  
  return themes.map(theme => {
    return `[data-theme="${theme}"] {\n${
      dictionary.allTokens
        .filter(token => token.attributes?.theme)
        .map(token => `  --${token.name}: ${token.value};`)
        .join('\n')
    }\n}`;
  }).join('\n\n');
}

function getSwiftType(token) {
  if (token.type === 'color') return 'UIColor';
  if (token.type === 'dimension') return 'CGFloat';
  if (token.type === 'duration') return 'TimeInterval';
  return 'String';
}

function getSwiftValue(token) {
  if (token.type === 'color') {
    const { r, g, b, a } = token.value;
    return `UIColor(red: ${r}, green: ${g}, blue: ${b}, alpha: ${a})`;
  }
  if (token.type === 'dimension') {
    return token.value.replace('px', '');
  }
  return `"${token.value}"`;
}

function getKotlinValue(token) {
  if (token.type === 'color') {
    return `Color(0x${token.value.replace('#', '')})`;
  }
  if (token.type === 'dimension') {
    return `${token.value.replace('px', '')}.dp`;
  }
  if (token.type === 'fontSize') {
    return `${token.value.replace('px', '')}.sp`;
  }
  return `"${token.value}"`;
}
```

### PostCSS Plugin

```javascript
// postcss-liquid-glass-tokens.js
const postcss = require('postcss');
const fs = require('fs');
const path = require('path');

module.exports = postcss.plugin('postcss-liquid-glass-tokens', (options = {}) => {
  const tokensPath = options.tokensPath || './tokens/liquid-glass-tokens.json';
  const prefix = options.prefix || 'lg';
  
  return (root, result) => {
    // Загружаем токены
    let tokens;
    try {
      tokens = JSON.parse(fs.readFileSync(tokensPath, 'utf8'));
    } catch (error) {
      throw new Error(`Failed to load tokens from ${tokensPath}: ${error.message}`);
    }
    
    // Обрабатываем CSS
    root.walkDecls((decl) => {
      // Заменяем токены вида lg.color.background.primary
      if (decl.value.includes(`${prefix}.`)) {
        decl.value = decl.value.replace(
          new RegExp(`${prefix}\\.(\\S+)`, 'g'),
          (match, tokenPath) => {
            const tokenValue = getTokenValue(tokens, tokenPath);
            return tokenValue || match;
          }
        );
      }
      
      // Заменяем CSS custom properties
      if (decl.value.includes(`--${prefix}-`)) {
        decl.value = decl.value.replace(
          new RegExp(`var\\(--${prefix}-([^)]+)\\)`, 'g'),
          (match, tokenPath) => {
            const tokenValue = getTokenValue(tokens, tokenPath.replace(/-/g, '.'));
            return tokenValue || match;
          }
        );
      }
    });
    
    // Добавляем CSS custom properties в корень
    if (options.addCustomProperties !== false) {
      addCustomProperties(root, tokens, prefix);
    }
  };
});

function getTokenValue(tokens, path) {
  return path.split('.').reduce((obj, key) => {
    return obj && obj[key] ? obj[key] : null;
  }, tokens);
}

function addCustomProperties(root, tokens, prefix) {
  const customProps = generateCustomProperties(tokens, prefix);
  
  // Ищем существующий :root или создаем новый
  let rootRule = null;
  root.walkRules(':root', (rule) => {
    rootRule = rule;
  });
  
  if (!rootRule) {
    rootRule = postcss.rule({ selector: ':root' });
    root.prepend(rootRule);
  }
  
  // Добавляем custom properties
  Object.entries(customProps).forEach(([prop, value]) => {
    rootRule.append(postcss.decl({
      prop: `--${prop}`,
      value: value
    }));
  });
}

function generateCustomProperties(tokens, prefix, path = []) {
  const props = {};
  
  Object.entries(tokens).forEach(([key, value]) => {
    const currentPath = [...path, key];
    const propName = `${prefix}-${currentPath.join('-')}`;
    
    if (typeof value === 'object' && value !== null && !Array.isArray(value)) {
      if (value.value !== undefined) {
        // Это токен со значением
        props[propName] = value.value;
      } else {
        // Это группа токенов
        Object.assign(props, generateCustomProperties(value, prefix, currentPath));
      }
    } else {
      // Прямое значение
      props[propName] = value;
    }
  });
  
  return props;
}
```

---

## Заключение

Создал comprehensive систему Design Tokens для Liquid Glass! 

### 📋 **Что включено:**
- ✅ **Базовая структура токенов** - полная иерархия дизайн-токенов
- ✅ **Цветовая система** - адаптивные цвета с темами и accessibility
- ✅ **Размытие и прозрачность** - backdrop-filter система с fallbacks
- ✅ **Типографика** - modular scale и читаемость на стекле
- ✅ **Spacing и Layout** - 8pt grid система
- ✅ **Анимация и Timing** - smooth transitions с reduce motion
- ✅ **Темы и вариации** - полный theme manager с кастомизацией
- ✅ **Cross-Platform реализация** - iOS Swift, Android Kotlin
- ✅ **Build Tools Integration** - Style Dictionary, PostCSS

### 🎯 **Ключевые особенности:**
- **Консистентность** - единые токены на всех платформах
- **Адаптивность** - поддержка системных предпочтений
- **Accessibility** - high contrast, reduce motion, screen readers
- **Производительность** - адаптивное размытие для разных устройств
- **Расширяемость** - простое добавление новых тем и токенов

### 🔗 **Связанные документы:**
- [Liquid-Glass-Platform-Specific.md] - Platform implementations ✅
- [Liquid-Glass-Performance-Optimization.md] - Performance considerations ✅
- [Liquid-Glass-Accessibility.md] - Accessibility guidelines ✅

Design Tokens - это сердце дизайн-системы, обеспечивающее единообразие и масштабируемость Liquid Glass интерфейсов на всех платформах! 🎨⚡️🚀