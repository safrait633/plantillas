# Каталог элементов интерфейса

## 1. Основы (Foundations)

**Типографика** - Система шрифтов, размеров текста и стилей оформления
*Liquid Glass характеристики:* Текст на стеклянных поверхностях с повышенным контрастом и тенями для читаемости
```css
.glass-text {
  text-shadow: 0 1px 3px rgba(0,0,0,0.3);
  font-weight: 500;
  color: rgba(255,255,255,0.9);
}
```

**Цвета** - Палитра цветов, цветовые схемы и правила их использования
*Liquid Glass характеристики:* Полупрозрачные цвета с эффектом подтекания и дисперсии
```css
:root {
  --glass-primary: rgba(74,144,226,0.3);
  --glass-secondary: rgba(156,39,176,0.25);
  --glass-surface: rgba(255,255,255,0.1);
}
```

**Иконки** - Набор графических символов для визуального представления действий и объектов
*Liquid Glass характеристики:* Иконки с эффектом преломления и мягкими бликами
```css
.glass-icon {
  filter: drop-shadow(0 2px 4px rgba(0,0,0,0.1));
  opacity: 0.8;
  transition: all 0.3s ease;
}
.glass-icon:hover {
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.2));
  opacity: 1;
}
```

**Сетки и отступы** - Система выравнивания элементов и пространственных отношений
*Liquid Glass характеристики:* Адаптивные сетки с жидкими переходами между состояниями
```css
.glass-grid {
  display: grid;
  gap: 16px;
  transition: gap 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
```

**Эффекты материалов** - Тени, размытие, прозрачность и другие визуальные эффекты
*Liquid Glass характеристики:* Многослойные эффекты с backdrop-filter и displacement maps
```css
.glass-material {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.25);
  box-shadow: 
    inset 1px 1px 0 rgba(255,255,255,0.3),
    0 8px 32px rgba(0,0,0,0.1);
}
```

## 2. Навигационные элементы

**Верхняя панель** - Основная панель навигации в верхней части экрана
*Liquid Glass характеристики:* Полупрозрачная панель с размытием фона и легкими искажениями
```css
.glass-navbar {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.1);
  border-bottom: 1px solid rgba(255,255,255,0.2);
  position: sticky;
  top: 0;
}
```

**Нижняя панель** - Навигационная панель в нижней части для мобильных устройств
*Liquid Glass характеристики:* Плавающая стеклянная панель с эффектом левитации
```css
.glass-bottom-nav {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.15);
  border-radius: 24px 24px 0 0;
  box-shadow: 0 -4px 20px rgba(0,0,0,0.1);
}
```

**Боковая панель** - Выдвижное или фиксированное меню сбоку экрана
*Liquid Glass характеристики:* Анимированное появление с эффектом жидкого стекла
```css
.glass-sidebar {
  backdrop-filter: blur(24px);
  background: linear-gradient(135deg, rgba(255,255,255,0.2), rgba(255,255,255,0.05));
  transform: translateX(-100%);
  transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-sidebar.open {
  transform: translateX(0);
}
```

**Вкладки** - Горизонтальные переключатели между разделами контента
*Liquid Glass характеристики:* Активная вкладка с усиленным стеклянным эффектом
```css
.glass-tab {
  background: transparent;
  transition: all 0.3s ease;
}
.glass-tab.active {
  background: rgba(255,255,255,0.3);
  backdrop-filter: blur(8px);
  box-shadow: inset 0 1px 0 rgba(255,255,255,0.4);
}
```

**Хлебные крошки** - Показывают текущее местоположение пользователя в структуре сайта
*Liquid Glass характеристики:* Полупрозрачные элементы с жидкими переходами
```css
.glass-breadcrumb {
  background: rgba(255,255,255,0.1);
  backdrop-filter: blur(4px);
  padding: 8px 16px;
  border-radius: 20px;
  margin: 0 4px;
}
```

**Пагинация** - Навигация по страницам большого объема данных
*Liquid Glass характеристики:* Стеклянные кнопки с эффектом нажатия
```css
.glass-pagination-item {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.2);
  transition: all 0.2s ease;
}
.glass-pagination-item:active {
  transform: scale(0.95);
  background: rgba(255,255,255,0.25);
}
```

**Шаги процесса** - Индикатор прогресса выполнения многоэтапного процесса
*Liquid Glass характеристики:* Стеклянные индикаторы с заливкой прогресса
```css
.glass-step {
  background: rgba(255,255,255,0.1);
  backdrop-filter: blur(8px);
  border: 2px solid rgba(255,255,255,0.3);
}
.glass-step.completed {
  background: rgba(76,175,80,0.3);
  border-color: rgba(76,175,80,0.5);
}
```

**Меню** - Выпадающие и контекстные списки опций и действий
*Liquid Glass характеристики:* Анимированное появление с размытием и искажениями
```css
.glass-menu {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 12px;
  opacity: 0;
  transform: scale(0.95) translateY(-10px);
  transition: all 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-menu.open {
  opacity: 1;
  transform: scale(1) translateY(0);
}
```

**Палитра команд** - Быстрый поиск и выполнение команд через текстовый интерфейс
*Liquid Glass характеристики:* Центральная стеклянная панель с эффектом фокуса
```css
.glass-command-palette {
  backdrop-filter: blur(24px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  box-shadow: 0 20px 40px rgba(0,0,0,0.15);
}
```

## 3. Элементы ввода

**Кнопки** - Интерактивные элементы для выполнения действий
*Liquid Glass характеристики:* Динамические искажения при hover и активации
```css
.glass-button {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
}
.glass-button:hover {
  background: rgba(255,255,255,0.3);
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0,0,0,0.15);
}
```

**Поля ввода** - Текстовые поля для ввода информации пользователем
*Liquid Glass характеристики:* Стеклянная рамка с эффектом фокуса
```css
.glass-input {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border: 2px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  transition: all 0.3s ease;
}
.glass-input:focus {
  border-color: rgba(74,144,226,0.5);
  background: rgba(255,255,255,0.15);
  box-shadow: 0 0 20px rgba(74,144,226,0.2);
}
```

**Выпадающие списки** - Компактный способ выбора из множества опций
*Liquid Glass характеристики:* Анимированное раскрытие с жидким эффектом
```css
.glass-select {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.25);
}
.glass-select-options {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.2);
  border-radius: 8px;
  animation: glassDropdown 0.3s ease-out;
}
@keyframes glassDropdown {
  from { opacity: 0; transform: scaleY(0.8); }
  to { opacity: 1; transform: scaleY(1); }
}
```

**Чекбоксы** - Элементы для множественного выбора опций
*Liquid Glass характеристики:* Стеклянные переключатели с анимированным заполнением
```css
.glass-checkbox {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.1);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 4px;
  transition: all 0.2s ease;
}
.glass-checkbox:checked {
  background: rgba(76,175,80,0.3);
  border-color: rgba(76,175,80,0.6);
}
```

**Радиокнопки** - Элементы для выбора одной опции из группы
*Liquid Glass характеристики:* Круглые стеклянные элементы с внутренним свечением
```css
.glass-radio {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.1);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%;
}
.glass-radio:checked::after {
  background: radial-gradient(circle, rgba(74,144,226,0.8), rgba(74,144,226,0.3));
  backdrop-filter: blur(2px);
}
```

**Переключатели** - Бинарные элементы управления типа вкл/выкл
*Liquid Glass характеристики:* Жидкие переходы состояний с эффектом движения
```css
.glass-switch {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.15);
  border-radius: 25px;
  transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-switch-thumb {
  background: rgba(255,255,255,0.8);
  backdrop-filter: blur(4px);
  transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

**Слайдеры** - Элементы для выбора значения из диапазона путем перетаскивания
*Liquid Glass характеристики:* Стеклянная дорожка с жидким перемещением ползунка
```css
.glass-slider-track {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.2);
  border-radius: 10px;
}
.glass-slider-thumb {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.4);
  border: 2px solid rgba(255,255,255,0.6);
  border-radius: 50%;
  transition: all 0.2s ease;
}
.glass-slider-thumb:active {
  transform: scale(1.2);
  box-shadow: 0 0 20px rgba(74,144,226,0.3);
}
```

**Выбор даты** - Специализированные элементы для ввода календарных дат
*Liquid Glass характеристики:* Стеклянный календарь с эффектом глубины
```css
.glass-datepicker {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  box-shadow: 0 20px 40px rgba(0,0,0,0.1);
}
```

**Выбор времени** - Элементы для указания времени
*Liquid Glass характеристики:* Круговой интерфейс с стеклянными стрелками
```css
.glass-timepicker {
  backdrop-filter: blur(16px);
  background: radial-gradient(circle, rgba(255,255,255,0.2), rgba(255,255,255,0.05));
  border-radius: 50%;
}
```

**Выбор цвета** - Инструменты для выбора цветов из палитры
*Liquid Glass характеристики:* Стеклянная палитра с преломлением цветов
```css
.glass-colorpicker {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.1);
  border-radius: 12px;
  overflow: hidden;
}
.glass-color-swatch {
  backdrop-filter: blur(2px);
  border: 1px solid rgba(255,255,255,0.3);
}
```

**Загрузка файлов** - Элементы для выбора и загрузки файлов с устройства
*Liquid Glass характеристики:* Область drag&drop с жидкими анимациями
```css
.glass-file-upload {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.1);
  border: 2px dashed rgba(255,255,255,0.3);
  border-radius: 12px;
  transition: all 0.3s ease;
}
.glass-file-upload.dragover {
  background: rgba(74,144,226,0.1);
  border-color: rgba(74,144,226,0.5);
  transform: scale(1.02);
}
```

**Редактор текста** - Расширенные поля для форматирования и редактирования текста
*Liquid Glass характеристики:* Стеклянная панель инструментов с размытием
```css
.glass-editor-toolbar {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.15);
  border-bottom: 1px solid rgba(255,255,255,0.2);
}
.glass-editor-content {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.05);
}
```

## 4. Отображение данных

**Списки** - Вертикальное представление элементов данных
*Liquid Glass характеристики:* Стеклянные элементы списка с эффектом парения
```css
.glass-list-item {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  transition: all 0.2s ease;
}
.glass-list-item:hover {
  background: rgba(255,255,255,0.15);
  transform: translateX(4px);
}
```

**Карточки** - Контейнеры для группировки связанной информации
*Liquid Glass характеристики:* Многослойные стеклянные поверхности с глубиной
```css
.glass-card {
  backdrop-filter: blur(16px);
  background: linear-gradient(135deg, rgba(255,255,255,0.2), rgba(255,255,255,0.1));
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
  transition: all 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 16px 48px rgba(0,0,0,0.15);
}
```

**Таблицы** - Структурированное представление данных в строках и столбцах
*Liquid Glass характеристики:* Прозрачные ячейки с жидкими границами
```css
.glass-table {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.05);
  border-radius: 12px;
  overflow: hidden;
}
.glass-table-header {
  background: rgba(255,255,255,0.15);
  backdrop-filter: blur(8px);
}
.glass-table-row:hover {
  background: rgba(255,255,255,0.1);
}
```

**Сетки элементов** - Равномерное размещение элементов в виде сетки
*Liquid Glass характеристики:* Адаптивная сетка с жидкими переходами
```css
.glass-grid {
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
}
.glass-grid-item {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.12);
  border-radius: 12px;
  transition: all 0.3s ease;
}
```

**Аккордеоны** - Сворачиваемые секции для организации контента
*Liquid Glass характеристики:* Анимированное расширение с эффектом течения
```css
.glass-accordion-header {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.15);
  border-radius: 8px;
}
.glass-accordion-content {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.08);
  max-height: 0;
  overflow: hidden;
  transition: max-height 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

**Карусель** - Горизонтальная прокрутка элементов с ограниченным видимым пространством
*Liquid Glass характеристики:* Стеклянные слайды с эффектом перетекания
```css
.glass-carousel {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.1);
  border-radius: 16px;
  overflow: hidden;
}
.glass-carousel-slide {
  backdrop-filter: blur(4px);
  transition: transform 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

**Аватары** - Круглые или квадратные изображения пользователей
*Liquid Glass характеристики:* Стеклянная рамка с внутренним свечением
```css
.glass-avatar {
  backdrop-filter: blur(4px);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  box-shadow: 
    inset 0 0 20px rgba(255,255,255,0.1),
    0 4px 12px rgba(0,0,0,0.1);
}
```

**Теги** - Небольшие ярлыки для категоризации и фильтрации
*Liquid Glass характеристики:* Мини стеклянные капсулы с цветовыми акцентами
```css
.glass-tag {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.2);
  border: 1px solid rgba(74,144,226,0.3);
  border-radius: 16px;
  padding: 4px 12px;
  font-size: 12px;
}
```

**Индикаторы прогресса** - Визуальное отображение выполнения процесса
*Liquid Glass характеристики:* Стеклянная полоса с жидким заполнением
```css
.glass-progress {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.1);
  border-radius: 10px;
  overflow: hidden;
}
.glass-progress-fill {
  background: linear-gradient(90deg, rgba(76,175,80,0.6), rgba(76,175,80,0.3));
  backdrop-filter: blur(2px);
  transition: width 0.3s ease;
}
```

**Бейджи** - Небольшие уведомления с числовыми значениями
*Liquid Glass характеристики:* Круглые стеклянные индикаторы с внутренним свечением
```css
.glass-badge {
  backdrop-filter: blur(6px);
  background: rgba(244,67,54,0.3);
  border: 1px solid rgba(244,67,54,0.5);
  border-radius: 50%;
  box-shadow: 0 0 10px rgba(244,67,54,0.2);
}
```

**Этикетки** - Текстовые метки для описания статуса или категории
*Liquid Glass характеристики:* Стеклянные планки с цветовой индикацией
```css
.glass-label {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.15);
  border-left: 3px solid rgba(74,144,226,0.6);
  padding: 6px 12px;
  border-radius: 0 6px 6px 0;
}
```

## 5. Обратная связь

**Уведомления** - Информирование пользователя о событиях в системе
*Liquid Glass характеристики:* Плавающие стеклянные панели с анимированным появлением
```css
.glass-notification {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  box-shadow: 0 12px 24px rgba(0,0,0,0.1);
  transform: translateY(-20px);
  opacity: 0;
  animation: glassSlideIn 0.3s ease-out forwards;
}
@keyframes glassSlideIn {
  to { transform: translateY(0); opacity: 1; }
}
```

**Модальные окна** - Всплывающие окна, требующие взаимодействия пользователя
*Liquid Glass характеристики:* Центральная стеклянная панель с размытым фоном
```css
.glass-modal-backdrop {
  backdrop-filter: blur(8px);
  background: rgba(0,0,0,0.3);
}
.glass-modal {
  backdrop-filter: blur(24px);
  background: linear-gradient(135deg, rgba(255,255,255,0.25), rgba(255,255,255,0.1));
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 20px;
  box-shadow: 0 24px 48px rgba(0,0,0,0.2);
}
```

**Подсказки** - Краткие пояснения, появляющиеся при наведении курсора
*Liquid Glass характеристики:* Мини стеклянные всплывашки с стрелочкой
```css
.glass-tooltip {
  backdrop-filter: blur(12px);
  background: rgba(0,0,0,0.8);
  color: white;
  border-radius: 6px;
  padding: 8px 12px;
  font-size: 12px;
  opacity: 0;
  transition: opacity 0.2s ease;
}
.glass-tooltip::after {
  border-top: 5px solid rgba(0,0,0,0.8);
}
```

**Индикаторы загрузки** - Анимации, показывающие процесс загрузки данных
*Liquid Glass характеристики:* Вращающиеся стеклянные спиннеры с преломлением
```css
.glass-spinner {
  backdrop-filter: blur(4px);
  border: 3px solid rgba(255,255,255,0.1);
  border-top: 3px solid rgba(74,144,226,0.6);
  border-radius: 50%;
  animation: glassRotate 1s linear infinite;
}
@keyframes glassRotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
```

**Скелетная загрузка** - Имитация структуры контента во время загрузки
*Liquid Glass характеристики:* Пульсирующие стеклянные блоки-заглушки
```css
.glass-skeleton {
  backdrop-filter: blur(2px);
  background: linear-gradient(90deg, 
    rgba(255,255,255,0.1), 
    rgba(255,255,255,0.2), 
    rgba(255,255,255,0.1)
  );
  background-size: 200% 100%;
  animation: glassSkeleton 1.5s ease-in-out infinite;
  border-radius: 4px;
}
@keyframes glassSkeleton {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
```

**Алерты** - Важные сообщения, требующие внимания пользователя
*Liquid Glass характеристики:* Стеклянные панели с цветовой индикацией важности
```css
.glass-alert {
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 8px;
  padding: 16px;
}
.glass-alert.error {
  background: rgba(244,67,54,0.15);
  border-left: 4px solid rgba(244,67,54,0.6);
}
.glass-alert.success {
  background: rgba(76,175,80,0.15);
  border-left: 4px solid rgba(76,175,80,0.6);
}
```

**Тосты** - Временные уведомления, появляющиеся и исчезающие автоматически
*Liquid Glass характеристики:* Летящие стеклянные уведомления с автоисчезновением
```css
.glass-toast {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 8px;
  transform: translateX(100%);
  transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-toast.show {
  transform: translateX(0);
}
```

**Снэкбары** - Краткие сообщения в нижней части экрана
*Liquid Glass характеристики:* Выдвижные стеклянные полосы снизу
```css
.glass-snackbar {
  backdrop-filter: blur(20px);
  background: rgba(0,0,0,0.8);
  color: white;
  border-radius: 4px;
  transform: translateY(100%);
  transition: transform 0.3s ease;
}
.glass-snackbar.show {
  transform: translateY(0);
}
```

## 6. Интерактивные элементы

**Drag & Drop** - Возможность перетаскивания элементов для их перемещения или копирования
*Liquid Glass характеристики:* Элементы становятся более прозрачными при перетаскивании с жидким следом
```css
.glass-draggable {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.15);
  transition: all 0.2s ease;
}
.glass-draggable:hover {
  cursor: grab;
  transform: translateY(-2px);
  box-shadow: 0 8px 20px rgba(0,0,0,0.15);
}
.glass-draggable.dragging {
  opacity: 0.7;
  transform: rotate(2deg) scale(1.05);
  filter: drop-shadow(0 8px 16px rgba(0,0,0,0.2));
}
```

**Swipe контролы** - Жесты смахивания для навигации или действий
*Liquid Glass характеристики:* Открываемые стеклянные панели с действиями сбоку
```css
.glass-swipe-actions {
  backdrop-filter: blur(12px);
  background: linear-gradient(90deg, rgba(244,67,54,0.2), rgba(244,67,54,0.1));
  transform: translateX(-100%);
  transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-swipe-actions.revealed {
  transform: translateX(0);
}
```

**Hover эффекты** - Визуальные изменения при наведении курсора мыши
*Liquid Glass характеристики:* Усиление стеклянного эффекта и добавление свечения
```css
.glass-hover {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  transition: all 0.3s ease;
}
.glass-hover:hover {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.2);
  box-shadow: 
    0 8px 32px rgba(0,0,0,0.1),
    inset 0 1px 0 rgba(255,255,255,0.4);
}
```

**Анимации переходов** - Плавные переходы между состояниями или страницами
*Liquid Glass характеристики:* Жидкие морфинг-переходы с размытием
```css
.glass-transition {
  backdrop-filter: blur(16px);
  transition: all 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-transition.morphing {
  backdrop-filter: blur(24px);
  transform: scale(1.1);
  opacity: 0.8;
}
```

**Микро-анимации** - Мелкие анимационные детали для улучшения взаимодействия
*Liquid Glass характеристики:* Тонкие пульсации и мерцания стеклянных поверхностей
```css
.glass-micro-pulse {
  backdrop-filter: blur(6px);
  animation: glassPulse 2s ease-in-out infinite;
}
@keyframes glassPulse {
  0%, 100% { background: rgba(255,255,255,0.1); }
  50% { background: rgba(255,255,255,0.15); }
}
```

**Параллакс эффекты** - Создание иллюзии глубины через разную скорость прокрутки элементов
*Liquid Glass характеристики:* Многослойные стеклянные панели с разной скоростью движения
```css
.glass-parallax-layer {
  backdrop-filter: blur(var(--blur-amount, 8px));
  background: rgba(255,255,255, var(--opacity, 0.1));
  transform: translateY(calc(var(--scroll) * var(--speed, 0.5) * 1px));
}
```

## 7. Визуализация данных

**Линейные графики** - Отображение изменения данных во времени
*Liquid Glass характеристики:* Стеклянная область графика с размытыми линиями тренда
```css
.glass-chart-container {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
}
.glass-chart-line {
  filter: drop-shadow(0 2px 4px rgba(74,144,226,0.3));
  stroke-width: 2px;
}
```

**Круговые диаграммы** - Представление частей от целого в виде секторов круга
*Liquid Glass характеристики:* Стеклянные сегменты с внутренним свечением
```css
.glass-pie-segment {
  filter: drop-shadow(0 4px 8px rgba(0,0,0,0.1));
  transition: all 0.3s ease;
}
.glass-pie-segment:hover {
  transform: scale(1.05);
  filter: drop-shadow(0 6px 12px rgba(0,0,0,0.2));
}
```

**Столбчатые графики** - Сравнение значений с помощью вертикальных или горизонтальных столбцов
*Liquid Glass характеристики:* Прозрачные столбцы с градиентным заполнением
```css
.glass-bar {
  backdrop-filter: blur(4px);
  background: linear-gradient(180deg, rgba(74,144,226,0.6), rgba(74,144,226,0.2));
  border-radius: 4px 4px 0 0;
  transition: all 0.3s ease;
}
.glass-bar:hover {
  background: linear-gradient(180deg, rgba(74,144,226,0.8), rgba(74,144,226,0.4));
}
```

**Диаграммы области** - Линейные графики с заполненной областью под линией
*Liquid Glass характеристики:* Плавные стеклянные области с градиентным заполнением
```css
.glass-area-fill {
  fill: url(#glassGradient);
  filter: drop-shadow(0 2px 8px rgba(0,0,0,0.1));
}
```

**Диаграммы Ганта** - Планирование и отслеживание проектов во времени
*Liquid Glass характеристики:* Стеклянные временные блоки с состояниями выполнения
```css
.glass-gantt-bar {
  backdrop-filter: blur(6px);
  background: rgba(76,175,80,0.3);
  border: 1px solid rgba(76,175,80,0.5);
  border-radius: 4px;
}
```

**Сетевые диаграммы** - Визуализация связей между узлами и элементами
*Liquid Glass характеристики:* Стеклянные узлы соединенные размытыми линиями
```css
.glass-node {
  backdrop-filter: blur(8px);
  background: radial-gradient(circle, rgba(255,255,255,0.3), rgba(255,255,255,0.1));
  border: 2px solid rgba(255,255,255,0.4);
  border-radius: 50%;
}
.glass-edge {
  stroke: rgba(255,255,255,0.3);
  filter: blur(0.5px);
}
```

**Тепловые карты** - Представление данных через интенсивность цвета
*Liquid Glass характеристики:* Стеклянные ячейки с цветовой интенсивностью
```css
.glass-heatmap-cell {
  backdrop-filter: blur(2px);
  border: 1px solid rgba(255,255,255,0.1);
  transition: all 0.2s ease;
}
.glass-heatmap-cell:hover {
  border-color: rgba(255,255,255,0.3);
  transform: scale(1.1);
}
```

**Дерево данных** - Иерархическое представление информации
*Liquid Glass характеристики:* Ветвящиеся стеклянные структуры с узлами
```css
.glass-tree-node {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 8px;
}
.glass-tree-branch {
  stroke: rgba(255,255,255,0.3);
  stroke-width: 2px;
}
```

**Временные шкалы** - Хронологическое отображение событий
*Liquid Glass характеристики:* Стеклянная временная линия с событийными маркерами
```css
.glass-timeline {
  backdrop-filter: blur(4px);
  background: linear-gradient(180deg, rgba(255,255,255,0.2), rgba(255,255,255,0.1));
  border-radius: 2px;
}
.glass-timeline-event {
  backdrop-filter: blur(8px);
  background: rgba(74,144,226,0.3);
  border: 2px solid rgba(74,144,226,0.5);
  border-radius: 50%;
}
```

**Гистограммы** - Распределение частоты значений по интервалам
*Liquid Glass характеристики:* Стеклянные столбцы частотности с размытыми краями
```css
.glass-histogram-bar {
  backdrop-filter: blur(3px);
  background: rgba(156,39,176,0.4);
  border-radius: 2px 2px 0 0;
  transition: all 0.3s ease;
}
```

## 8. Медиа элементы

**Изображения** - Статичные графические элементы с поддержкой разных форматов
*Liquid Glass характеристики:* Стеклянные рамки с эффектом преломления краев
```css
.glass-image {
  border-radius: 12px;
  overflow: hidden;
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
  border: 1px solid rgba(255,255,255,0.2);
}
```

**Видеоплеер** - Интерфейс для воспроизведения видеоконтента
*Liquid Glass характеристики:* Стеклянные контролы поверх видео с автоскрытием
```css
.glass-video-controls {
  backdrop-filter: blur(20px);
  background: rgba(0,0,0,0.3);
  border-radius: 8px;
  opacity: 0;
  transition: opacity 0.3s ease;
}
.glass-video:hover .glass-video-controls { opacity: 1; }
```

**Аудиоплеер** - Элементы управления воспроизведением звуковых файлов
*Liquid Glass характеристики:* Стеклянная панель с волновой визуализацией
```css
.glass-audio-player {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.15);
  border-radius: 20px;
  padding: 16px;
}
```

**Галерея изображений** - Организованное представление множества изображений
*Liquid Glass характеристики:* Сетка стеклянных превью с эффектом увеличения
```css
.glass-gallery-item {
  backdrop-filter: blur(4px);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 8px;
  transition: transform 0.3s ease;
}
.glass-gallery-item:hover { transform: scale(1.05); }
```

**Лайтбокс** - Полноэкранный просмотр изображений поверх основного контента
*Liquid Glass характеристики:* Стеклянный оверлей с размытым фоном
```css
.glass-lightbox {
  backdrop-filter: blur(12px);
  background: rgba(0,0,0,0.8);
}
.glass-lightbox-content {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 16px;
}
```

**Иконки** - Векторные символы для обозначения действий и объектов  
**Эмодзи** - Графические символы для выражения эмоций и идей
*Liquid Glass характеристики:* Прозрачные контейнеры с мягким свечением
```css
.glass-icon-container {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 8px;
}
```

## 9. Формы и валидация

**Формы** - Структурированные наборы полей для сбора пользовательских данных
*Liquid Glass характеристики:* Стеклянные контейнеры форм с группировкой полей
```css
.glass-form {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  padding: 24px;
}
```

**Поля с валидацией** - Проверка корректности введенных данных в реальном времени
*Liquid Glass характеристики:* Цветовая индикация состояния через стеклянные границы
```css
.glass-input.valid {
  border-color: rgba(76,175,80,0.5);
  box-shadow: 0 0 12px rgba(76,175,80,0.2);
}
.glass-input.invalid {
  border-color: rgba(244,67,54,0.5);
  box-shadow: 0 0 12px rgba(244,67,54,0.2);
}
```

**Сообщения об ошибках** - Информирование пользователя о проблемах в заполнении формы
*Liquid Glass характеристики:* Стеклянные всплывающие подсказки с ошибками
```css
.glass-error-message {
  backdrop-filter: blur(8px);
  background: rgba(244,67,54,0.1);
  border: 1px solid rgba(244,67,54,0.3);
  border-radius: 6px;
  color: #d32f2f;
}
```

**Индикаторы обязательных полей** - Визуальное выделение полей, требующих заполнения
*Liquid Glass характеристики:* Тонкое стеклянное свечение обязательных полей
```css
.glass-input.required {
  box-shadow: inset 0 0 0 1px rgba(244,67,54,0.3);
}
```

**Автозаполнение** - Предложение вариантов на основе ранее введенных данных
*Liquid Glass характеристики:* Выпадающий стеклянный список предложений
```css
.glass-autocomplete-dropdown {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 8px;
  max-height: 200px;
  overflow-y: auto;
}
```

**Маски ввода** - Форматирование данных в процессе ввода (номера телефонов, даты)
*Liquid Glass характеристики:* Визуальные подсказки формата внутри стеклянных полей
```css
.glass-input-mask::placeholder {
  color: rgba(255,255,255,0.5);
  font-family: monospace;
}
```

## 10. Компоненты поиска

**Поисковая строка** - Основное поле для ввода поисковых запросов
*Liquid Glass характеристики:* Расширяющееся стеклянное поле с иконкой поиска
```css
.glass-search {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.2);
  border-radius: 25px;
  transition: all 0.3s ease;
}
.glass-search:focus { width: 300px; border-color: rgba(74,144,226,0.5); }
```

**Фильтры** - Инструменты для уточнения и ограничения результатов поиска
*Liquid Glass характеристики:* Стеклянные чипы фильтров с возможностью удаления
```css
.glass-filter-chip {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.2);
  border: 1px solid rgba(74,144,226,0.4);
  border-radius: 16px;
  padding: 6px 12px;
}
```

**Сортировка** - Упорядочивание результатов по различным критериям
*Liquid Glass характеристики:* Стеклянный выпадающий список с опциями сортировки
```css
.glass-sort-dropdown {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 8px;
}
```

**Автокомплит** - Предложение вариантов завершения поискового запроса
*Liquid Glass характеристики:* Стеклянные предложения под поисковой строкой
```css
.glass-autocomplete-suggestion {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  padding: 12px 16px;
  transition: background 0.2s ease;
}
.glass-autocomplete-suggestion:hover {
  background: rgba(255,255,255,0.2);
}
```

**Результаты поиска** - Структурированное представление найденной информации
*Liquid Glass характеристики:* Стеклянные карточки результатов с подсветкой совпадений
```css
.glass-search-result {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  margin-bottom: 12px;
}
```

**Теги фильтров** - Визуальное отображение активных фильтров поиска
*Liquid Glass характеристики:* Мини стеклянные индикаторы активных фильтров
```css
.glass-active-filter {
  backdrop-filter: blur(4px);
  background: rgba(76,175,80,0.2);
  border: 1px solid rgba(76,175,80,0.4);
  border-radius: 12px;
  font-size: 12px;
}
```

## 11. Контентные блоки

**Заголовки** - Иерархическая система заголовков разных уровней
*Liquid Glass характеристики:* Текст с тенью и легким размытием фона
```css
.glass-heading {
  text-shadow: 0 2px 4px rgba(0,0,0,0.3);
  backdrop-filter: blur(2px);
  background: rgba(255,255,255,0.05);
  border-radius: 4px;
  padding: 8px 0;
}
```

**Параграфы** - Основные блоки текстового контента
*Liquid Glass характеристики:* Контейнеры с легким стеклянным фоном для группировки текста
```css
.glass-paragraph {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.03);
  padding: 16px;
  border-radius: 8px;
  line-height: 1.6;
}
```

**Цитаты** - Выделенные фрагменты текста из других источников
*Liquid Glass характеристики:* Стеклянные блоки с вертикальной цветной полосой
```css
.glass-quote {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-left: 4px solid rgba(74,144,226,0.6);
  border-radius: 0 8px 8px 0;
  padding: 16px 20px;
  font-style: italic;
}
```

**Списки** - Нумерованные и маркированные перечисления элементов
*Liquid Glass характеристики:* Элементы списка с тонким стеклянным разделением
```css
.glass-list-item {
  backdrop-filter: blur(3px);
  background: rgba(255,255,255,0.05);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding: 8px 0;
}
```

**Ссылки** - Интерактивные элементы для навигации между страницами
*Liquid Glass характеристики:* Подчеркивание с эффектом свечения при hover
```css
.glass-link {
  color: rgba(74,144,226,0.9);
  text-decoration: none;
  border-bottom: 1px solid rgba(74,144,226,0.3);
  transition: all 0.2s ease;
}
.glass-link:hover {
  color: rgba(74,144,226,1);
  text-shadow: 0 0 8px rgba(74,144,226,0.4);
}
```

**Выделенный текст** - Акцентирование важных фрагментов контента
*Liquid Glass характеристики:* Стеклянная подсветка с цветовым маркером
```css
.glass-highlight {
  backdrop-filter: blur(2px);
  background: rgba(255,235,59,0.3);
  border-radius: 4px;
  padding: 2px 4px;
}
```

**Код** - Специальное форматирование для отображения программного кода
*Liquid Glass характеристики:* Стеклянные блоки кода с моноширинным шрифтом
```css
.glass-code {
  backdrop-filter: blur(6px);
  background: rgba(0,0,0,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 6px;
  font-family: 'Fira Code', monospace;
  padding: 12px;
}
```

**Таблицы контента** - Структурированное представление табличных данных
*Liquid Glass характеристики:* Прозрачные ячейки с тонкими стеклянными границами
```css
.glass-table-content {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
  border-collapse: separate;
  border-spacing: 0;
  border-radius: 8px;
}
```

## 12. Состояния и индикаторы

**Пустые состояния** - Показывают что делать, когда нет данных для отображения
*Liquid Glass характеристики:* Центральные стеклянные панели с иконками и текстом
```css
.glass-empty-state {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.1);
  border: 2px dashed rgba(255,255,255,0.3);
  border-radius: 16px;
  text-align: center;
  padding: 48px 24px;
}
```

**Состояния ошибок** - Информируют об ошибках и предлагают способы их решения
*Liquid Glass характеристики:* Красноватые стеклянные панели с индикацией проблем
```css
.glass-error-state {
  backdrop-filter: blur(16px);
  background: rgba(244,67,54,0.1);
  border: 1px solid rgba(244,67,54,0.3);
  border-radius: 12px;
  padding: 24px;
}
```

**Офлайн индикаторы** - Показывают статус подключения к интернету
*Liquid Glass характеристики:* Плавающие стеклянные уведомления в углу
```css
.glass-offline-indicator {
  backdrop-filter: blur(20px);
  background: rgba(255,152,0,0.2);
  border: 1px solid rgba(255,152,0,0.4);
  border-radius: 8px;
  position: fixed;
  top: 16px;
  right: 16px;
}
```

**Статус-индикаторы** - Цветные точки или иконки для обозначения состояния
*Liquid Glass характеристики:* Круглые стеклянные индикаторы с внутренним свечением
```css
.glass-status-indicator {
  backdrop-filter: blur(4px);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  width: 12px;
  height: 12px;
  box-shadow: 0 0 8px rgba(76,175,80,0.5);
}
.glass-status-indicator.online { background: rgba(76,175,80,0.8); }
.glass-status-indicator.offline { background: rgba(158,158,158,0.8); }
```

**Онлайн/офлайн статус** - Показывает доступность пользователей
*Liquid Glass характеристики:* Небольшие стеклянные точки рядом с аватарами
```css
.glass-presence-indicator {
  backdrop-filter: blur(2px);
  border: 1px solid rgba(255,255,255,0.6);
  border-radius: 50%;
  width: 8px;
  height: 8px;
  position: absolute;
  bottom: 0;
  right: 0;
}
```

**Индикаторы активности** - Показывают текущую активность пользователя
*Liquid Glass характеристики:* Пульсирующие стеклянные точки с анимацией
```css
.glass-activity-indicator {
  backdrop-filter: blur(3px);
  background: rgba(76,175,80,0.6);
  border-radius: 50%;
  animation: glassPulse 2s infinite;
}
```

## 13. Мобильные компоненты

**Плавающая кнопка действия** - Круглая кнопка для основного действия на экране
*Liquid Glass характеристики:* Парящая стеклянная кнопка с тенью и эффектом нажатия
```css
.glass-fab {
  backdrop-filter: blur(20px);
  background: rgba(74,144,226,0.3);
  border: 1px solid rgba(74,144,226,0.5);
  border-radius: 50%;
  box-shadow: 0 8px 20px rgba(0,0,0,0.15);
  position: fixed;
  bottom: 16px;
  right: 16px;
}
.glass-fab:active { transform: scale(0.95); }
```

**Потянуть для обновления** - Жест для обновления содержимого страницы
*Liquid Glass характеристики:* Стеклянный индикатор загрузки при потягивании
```css
.glass-pull-refresh {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.2);
  border-radius: 20px;
  transform: translateY(-100%);
  transition: transform 0.3s ease;
}
```

**Нижние листы** - Выдвижные панели снизу экрана
*Liquid Glass характеристики:* Стеклянные панели с закругленными верхними углами
```css
.glass-bottom-sheet {
  backdrop-filter: blur(24px);
  background: rgba(255,255,255,0.2);
  border-radius: 20px 20px 0 0;
  border-top: 1px solid rgba(255,255,255,0.3);
  transform: translateY(100%);
  transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
```

**Swipe для действий** - Горизонтальные жесты для быстрых действий
*Liquid Glass характеристики:* Скрытые стеклянные панели действий сбоку
```css
.glass-swipe-action {
  backdrop-filter: blur(16px);
  background: rgba(244,67,54,0.2);
  border: 1px solid rgba(244,67,54,0.4);
  transform: translateX(-100%);
  transition: transform 0.2s ease;
}
```

**Мобильные вкладки** - Адаптированная навигация по вкладкам для сенсорных устройств
*Liquid Glass характеристики:* Стеклянная табба с большими областями касания
```css
.glass-mobile-tab {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  min-height: 48px;
  border-radius: 8px;
  transition: all 0.2s ease;
}
.glass-mobile-tab.active {
  background: rgba(74,144,226,0.3);
}
```

**Полноэкранные оверлеи** - Модальные окна на весь экран для мобильных устройств
*Liquid Glass характеристики:* Стеклянные оверлеи с анимацией появления снизу
```css
.glass-mobile-overlay {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.15);
  transform: translateY(100%);
  transition: transform 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}
.glass-mobile-overlay.open { transform: translateY(0); }
```

## 14. Специализированные элементы ввода

**PIN-код ввод** - Поля для ввода цифрового кода или пароля
*Liquid Glass характеристики:* Отдельные стеклянные ячейки для каждой цифры
```css
.glass-pin-input {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 8px;
  width: 48px;
  height: 48px;
  text-align: center;
}
```

**Рейтинг звездочками** - Интерактивная оценка с помощью звезд
*Liquid Glass характеристики:* Стеклянные звезды с эффектом заполнения
```css
.glass-star {
  filter: drop-shadow(0 2px 4px rgba(255,193,7,0.3));
  transition: all 0.2s ease;
}
.glass-star:hover { transform: scale(1.1); }
```

**Ввод подписи** - Область для рисования электронной подписи
*Liquid Glass характеристики:* Стеклянная панель рисования с границами
```css
.glass-signature-pad {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.1);
  border: 2px dashed rgba(255,255,255,0.3);
  border-radius: 8px;
}
```

**Голосовой ввод** - Кнопка и интерфейс для записи голосовых сообщений
*Liquid Glass характеристики:* Пульсирующая стеклянная кнопка микрофона
```css
.glass-voice-input {
  backdrop-filter: blur(12px);
  background: rgba(244,67,54,0.2);
  border-radius: 50%;
  animation: glassPulse 1s infinite;
}
```

**Сканер QR-кодов** - Интерфейс для сканирования QR и штрих-кодов
*Liquid Glass характеристики:* Стеклянная рамка сканирования с угловыми маркерами
```css
.glass-qr-scanner {
  backdrop-filter: blur(8px);
  border: 2px solid rgba(76,175,80,0.6);
  border-radius: 8px;
  position: relative;
}
.glass-qr-scanner::before {
  content: '';
  border: 3px solid rgba(76,175,80,0.8);
  border-radius: 4px;
}
```

**Геолокация** - Элементы для работы с местоположением пользователя
*Liquid Glass характеристики:* Стеклянные маркеры и карты с размытыми границами
```css
.glass-location-marker {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.3);
  border: 2px solid rgba(74,144,226,0.6);
  border-radius: 50% 50% 50% 0;
  transform: rotate(-45deg);
}
```

## 15. Компоненты макета

**Разделители** - Линии или пространство для визуального разделения контента
*Liquid Glass характеристики:* Тонкие стеклянные линии с градиентной прозрачностью
```css
.glass-divider {
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  backdrop-filter: blur(1px);
}
```

**Контейнеры** - Обертки для группировки и выравнивания элементов
*Liquid Glass характеристики:* Стеклянные контейнеры с мягкими границами
```css
.glass-container {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.15);
  border-radius: 12px;
  padding: 20px;
}
```

**Сетки макета** - Системы для создания адаптивных макетов
*Liquid Glass характеристики:* Адаптивные сетки с жидкими переходами между размерами
```css
.glass-grid-layout {
  display: grid;
  gap: 16px;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  transition: gap 0.3s ease;
}
```

**Отступы** - Элементы для создания пустого пространства между компонентами
*Liquid Glass характеристики:* Невидимые спейсеры с адаптивными размерами
```css
.glass-spacer {
  backdrop-filter: blur(0);
  background: transparent;
  height: var(--spacing, 16px);
  transition: height 0.3s ease;
}
```

**Панели** - Прямоугольные области для группировки связанного контента
*Liquid Glass характеристики:* Стеклянные панели с тенями и группировкой контента
```css
.glass-panel {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
}
```

**Секции** - Логические блоки для организации контента на странице
*Liquid Glass характеристики:* Крупные стеклянные блоки с четким разделением
```css
.glass-section {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.06);
  border-radius: 20px;
  padding: 32px;
  margin: 24px 0;
}
```

## 16. Социальные и коммуникационные элементы

**Комментарии** - Система для обсуждений и обратной связи
*Liquid Glass характеристики:* Стеклянные блоки комментариев с вложенностью
```css
.glass-comment {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  padding: 16px;
  margin-left: calc(var(--level, 0) * 24px);
}
```

**Реакции** - Быстрые эмоциональные отклики (лайки, эмодзи)
*Liquid Glass характеристики:* Небольшие стеклянные кнопки реакций с анимацией
```css
.glass-reaction {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.15);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 20px;
  padding: 6px 12px;
  transition: all 0.2s ease;
}
.glass-reaction:hover { transform: scale(1.1); }
```

**Поделиться** - Кнопки для расшаривания контента в социальных сетях
*Liquid Glass характеристики:* Стеклянные кнопки соцсетей с брендовыми цветами
```css
.glass-share-button {
  backdrop-filter: blur(8px);
  background: rgba(59,89,152,0.2);
  border: 1px solid rgba(59,89,152,0.4);
  border-radius: 8px;
  transition: all 0.2s ease;
}
```

**Профили пользователей** - Карточки с информацией о пользователях
*Liquid Glass характеристики:* Стеклянные карточки профилей с аватарами
```css
.glass-profile-card {
  backdrop-filter: blur(16px);
  background: linear-gradient(135deg, rgba(255,255,255,0.2), rgba(255,255,255,0.1));
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 16px;
  padding: 24px;
}
```

**Чат-интерфейс** - Элементы для мгновенного обмена сообщениями
*Liquid Glass характеристики:* Стеклянные пузыри сообщений с разной прозрачностью
```css
.glass-message-bubble {
  backdrop-filter: blur(12px);
  border-radius: 18px 18px 4px 18px;
  padding: 12px 16px;
  max-width: 70%;
}
.glass-message-bubble.own {
  background: rgba(74,144,226,0.3);
  margin-left: auto;
}
.glass-message-bubble.other {
  background: rgba(255,255,255,0.2);
}
```

**Уведомления в реальном времени** - Живые обновления о новых событиях
*Liquid Glass характеристики:* Плавающие стеклянные уведомления с анимацией
```css
.glass-live-notification {
  backdrop-filter: blur(20px);
  background: rgba(76,175,80,0.2);
  border: 1px solid rgba(76,175,80,0.4);
  border-radius: 8px;
  animation: glassSlideIn 0.3s ease-out;
}
```

## 17. Продвинутые интерактивные элементы

**Бесконечная прокрутка** - Автоматическая подгрузка контента при прокрутке
*Liquid Glass характеристики:* Стеклянный индикатор загрузки в конце списка
```css
.glass-infinite-loader {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  text-align: center;
  padding: 20px;
}
```

**Виртуальная прокрутка** - Оптимизированное отображение больших списков
*Liquid Glass характеристики:* Стеклянные элементы с динамической подгрузкой
```css
.glass-virtual-item {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.08);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  transition: opacity 0.2s ease;
}
```

**Масштабирование** - Возможность увеличения и уменьшения изображений
*Liquid Glass характеристики:* Стеклянные контролы зума с плавными переходами
```css
.glass-zoom-controls {
  backdrop-filter: blur(16px);
  background: rgba(0,0,0,0.5);
  border-radius: 20px;
  padding: 8px;
}
```

**Многоуровневые меню** - Вложенные структуры навигации
*Liquid Glass характеристики:* Каскадные стеклянные панели меню
```css
.glass-submenu {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 8px;
  transform: translateX(-8px);
}
```

**Contextual меню** - Контекстные действия при правом клике или долгом нажатии
*Liquid Glass характеристики:* Всплывающие стеклянные меню с действиями
```css
.glass-context-menu {
  backdrop-filter: blur(24px);
  background: rgba(255,255,255,0.25);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 8px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.15);
}
```

**Быстрые действия** - Shortcuts для часто используемых функций
*Liquid Glass характеристики:* Стеклянные кнопки быстрого доступа
```css
.glass-quick-action {
  backdrop-filter: blur(10px);
  background: rgba(74,144,226,0.2);
  border: 1px solid rgba(74,144,226,0.4);
  border-radius: 12px;
  width: 48px;
  height: 48px;
}
```

## 18. Элементы доступности

**Высококонтрастные элементы** - Компоненты с усиленным контрастом для слабовидящих
*Liquid Glass характеристики:* Увеличенная прозрачность фона и яркие границы
```css
.glass-high-contrast {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.4);
  border: 2px solid rgba(0,0,0,0.8);
  color: #000;
}
```

**Навигация с клавиатуры** - Поддержка управления без мыши
*Liquid Glass характеристики:* Видимые стеклянные рамки фокуса
```css
.glass-element:focus {
  outline: none;
  box-shadow: 0 0 0 3px rgba(74,144,226,0.5);
  backdrop-filter: blur(16px);
}
```

**Экранные читалки** - Семантические элементы для программ чтения с экрана
*Liquid Glass характеристики:* Скрытые стеклянные подсказки для читалок
```css
.glass-sr-only {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  clip: rect(0,0,0,0);
  position: absolute;
}
```

**Озвучивание действий** - Голосовая обратная связь для слепых пользователей
**Увеличенные области нажатия** - Большие кнопки для людей с нарушениями моторики
*Liquid Glass характеристики:* Расширенные стеклянные области касания
```css
.glass-large-target {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.15);
  min-width: 48px;
  min-height: 48px;
  border-radius: 12px;
}
```

**Упрощенный интерфейс** - Минималистичные версии для когнитивных нарушений
*Liquid Glass характеристики:* Простые стеклянные элементы без сложных эффектов
```css
.glass-simplified {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.2);
  border: 1px solid rgba(255,255,255,0.4);
  border-radius: 8px;
}
```

## 19. Календарные и временные компоненты

**Календарь** - Интерактивный календарь для выбора дат
*Liquid Glass характеристики:* Стеклянная сетка календаря с выделением дат
```css
.glass-calendar {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
}
.glass-calendar-day {
  backdrop-filter: blur(4px);
  border-radius: 8px;
  transition: all 0.2s ease;
}
.glass-calendar-day.selected {
  background: rgba(74,144,226,0.3);
  border: 1px solid rgba(74,144,226,0.5);
}
```

**Планировщик событий** - Интерфейс для создания и управления событиями
*Liquid Glass характеристики:* Стеклянные блоки событий с цветовой кодировкой
```css
.glass-event-block {
  backdrop-filter: blur(8px);
  background: rgba(156,39,176,0.2);
  border: 1px solid rgba(156,39,176,0.4);
  border-radius: 6px;
  padding: 4px 8px;
}
```

**Временная шкала** - Отображение событий в хронологическом порядке
*Liquid Glass характеристики:* Стеклянная временная линия с маркерами событий
```css
.glass-timeline-line {
  backdrop-filter: blur(2px);
  background: linear-gradient(180deg, rgba(255,255,255,0.3), rgba(255,255,255,0.1));
  width: 2px;
}
.glass-timeline-marker {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.4);
  border: 2px solid rgba(74,144,226,0.6);
  border-radius: 50%;
}
```

**Расписание** - Сетка времени для планирования встреч
*Liquid Glass характеристики:* Стеклянная временная сетка с блоками встреч
```css
.glass-schedule-grid {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(255,255,255,0.1);
}
.glass-schedule-slot {
  backdrop-filter: blur(4px);
  border: 1px solid rgba(255,255,255,0.1);
  transition: background 0.2s ease;
}
.glass-schedule-slot:hover {
  background: rgba(255,255,255,0.1);
}
```

**Таймер** - Обратный отсчет времени
*Liquid Glass характеристики:* Круглый стеклянный индикатор с прогрессом
```css
.glass-timer {
  backdrop-filter: blur(16px);
  background: radial-gradient(circle, rgba(255,255,255,0.2), rgba(255,255,255,0.05));
  border: 3px solid rgba(255,255,255,0.3);
  border-radius: 50%;
  width: 120px;
  height: 120px;
}
```

**Секундомер** - Измерение прошедшего времени
*Liquid Glass характеристики:* Стеклянный дисплей с крупными цифрами
```css
.glass-stopwatch {
  backdrop-filter: blur(20px);
  background: rgba(0,0,0,0.3);
  color: #00ff00;
  font-family: 'Digital-7', monospace;
  font-size: 2rem;
  text-align: center;
  border-radius: 12px;
  padding: 16px;
}
```

**Часовые пояса** - Компоненты для работы с разными временными зонами
*Liquid Glass характеристики:* Стеклянные карточки часовых поясов
```css
.glass-timezone-card {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  padding: 16px;
  text-align: center;
}
```

## 20. Элементы безопасности

**Двухфакторная аутентификация** - Интерфейс для ввода кодов подтверждения
*Liquid Glass характеристики:* Стеклянные поля ввода кодов с защищенным видом
```css
.glass-2fa-input {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(76,175,80,0.4);
  border-radius: 8px;
  text-align: center;
  font-family: monospace;
}
```

**Биометрическая аутентификация** - Элементы для отпечатков пальцев, Face ID
*Liquid Glass характеристики:* Стеклянные индикаторы сканирования с анимацией
```css
.glass-biometric-scanner {
  backdrop-filter: blur(20px);
  background: radial-gradient(circle, rgba(74,144,226,0.3), rgba(74,144,226,0.1));
  border: 3px solid rgba(74,144,226,0.5);
  border-radius: 50%;
  animation: glassPulse 2s infinite;
}
```

**Индикаторы силы пароля** - Визуальная оценка надежности пароля
*Liquid Glass характеристики:* Стеклянная шкала силы с цветовой индикацией
```css
.glass-password-strength {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.1);
  border-radius: 10px;
  height: 6px;
  overflow: hidden;
}
.glass-password-strength-fill {
  backdrop-filter: blur(2px);
  height: 100%;
  transition: all 0.3s ease;
}
.glass-password-strength-fill.weak { background: rgba(244,67,54,0.6); }
.glass-password-strength-fill.strong { background: rgba(76,175,80,0.6); }
```

**CAPTCHA** - Системы защиты от ботов
*Liquid Glass характеристики:* Стеклянные панели верификации
```css
.glass-captcha {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 12px;
  padding: 20px;
}
```

**Предупреждения безопасности** - Алерты о подозрительной активности
*Liquid Glass характеристики:* Красные стеклянные панели предупреждений
```css
.glass-security-alert {
  backdrop-filter: blur(20px);
  background: rgba(244,67,54,0.2);
  border: 2px solid rgba(244,67,54,0.5);
  border-radius: 12px;
  padding: 16px;
  animation: glassAlertPulse 1s infinite;
}
```

**Маскирование данных** - Скрытие чувствительной информации
*Liquid Glass характеристики:* Размытые стеклянные блоки для скрытия данных
```css
.glass-masked-data {
  backdrop-filter: blur(8px);
  background: rgba(158,158,158,0.3);
  color: transparent;
  border-radius: 4px;
  user-select: none;
}
.glass-masked-data::before {
  content: '••••••••';
  color: rgba(255,255,255,0.6);
}
```

## 21. Административные и аналитические компоненты

**Дашборды** - Панели с ключевыми показателями и метриками
*Liquid Glass характеристики:* Многослойные стеклянные панели с виджетами
```css
.glass-admin-dashboard {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 16px;
  padding: 20px;
  display: grid;
  gap: 16px;
}
.glass-admin-widget {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.15);
  border-radius: 12px;
  padding: 16px;
  transition: all 0.3s ease;
}
```

**Виджеты KPI** - Компоненты для отображения ключевых показателей
*Liquid Glass характеристики:* Стеклянные карточки с численными метриками
```css
.glass-kpi-widget {
  backdrop-filter: blur(14px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(74,144,226,0.3);
  border-radius: 12px;
  padding: 20px;
  text-align: center;
}
.glass-kpi-value {
  font-size: 2.5em;
  font-weight: bold;
  color: rgba(74,144,226,0.9);
  text-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
```

**Системные логи** - Интерфейс для просмотра системных событий
*Liquid Glass характеристики:* Прозрачные консольные панели с монопространственным шрифтом
```css
.glass-system-logs {
  backdrop-filter: blur(12px);
  background: rgba(0,0,0,0.7);
  color: rgba(0,255,0,0.9);
  font-family: 'Courier New', monospace;
  border: 1px solid rgba(0,255,0,0.3);
  border-radius: 8px;
  padding: 16px;
  max-height: 400px;
  overflow-y: auto;
}
.glass-log-entry {
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding: 4px 0;
}
```

**Управление пользователями** - Таблицы и формы для администрирования
*Liquid Glass характеристики:* Стеклянные таблицы с интерактивными строками
```css
.glass-user-management {
  backdrop-filter: blur(14px);
  background: rgba(255,255,255,0.12);
  border: 2px solid rgba(255,255,255,0.25);
  border-radius: 12px;
  overflow: hidden;
}
.glass-user-row {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.08);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding: 12px;
  transition: background 0.3s ease;
}
.glass-user-row:hover {
  background: rgba(255,255,255,0.15);
}
```

**Настройки системы** - Конфигурационные панели
*Liquid Glass характеристики:* Стеклянные блоки настроек с переключателями
```css
.glass-system-settings {
  backdrop-filter: blur(18px);
  background: rgba(255,255,255,0.13);
  border: 1px solid rgba(255,255,255,0.3);
  border-radius: 16px;
  padding: 24px;
}
.glass-setting-item {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 12px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
```

**Отчеты** - Генерация и просмотр аналитических отчетов
*Liquid Glass характеристики:* Стеклянные панели отчетов с экспортом
```css
.glass-report-panel {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.11);
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 12px;
  padding: 20px;
}
.glass-report-chart {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.05);
  border-radius: 8px;
  padding: 16px;
}
```

**Экспорт данных** - Инструменты для выгрузки информации
*Liquid Glass характеристики:* Стеклянные кнопки экспорта с индикаторами прогресса
```css
.glass-export-button {
  backdrop-filter: blur(10px);
  background: rgba(76,175,80,0.2);
  border: 2px solid rgba(76,175,80,0.4);
  border-radius: 8px;
  padding: 12px 24px;
  transition: all 0.3s ease;
}
.glass-export-progress {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 20px;
  height: 6px;
  overflow: hidden;
}
```

## 22. Файловые компоненты

**Файловый менеджер** - Интерфейс для работы с файловой системой
*Liquid Glass характеристики:* Стеклянные панели с древовидной структурой файлов
```css
.glass-file-manager {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 12px;
  overflow: hidden;
}
.glass-file-item {
  backdrop-filter: blur(4px);
  background: rgba(255,255,255,0.08);
  border-bottom: 1px solid rgba(255,255,255,0.1);
  padding: 8px 16px;
  transition: all 0.3s ease;
}
.glass-file-item:hover {
  background: rgba(255,255,255,0.15);
}
```

**Предварительный просмотр** - Превью файлов разных типов
*Liquid Glass характеристики:* Стеклянные окна предпросмотра с размытыми краями
```css
.glass-file-preview {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(255,255,255,0.3);
  border-radius: 16px;
  padding: 20px;
  max-width: 600px;
  max-height: 400px;
  overflow: auto;
}
.glass-preview-content {
  backdrop-filter: blur(2px);
  background: rgba(255,255,255,0.05);
  border-radius: 8px;
  padding: 16px;
}
```

**Редактор кода** - Интерфейс для редактирования программного кода
*Liquid Glass характеристики:* Темные стеклянные панели с подсветкой синтаксиса
```css
.glass-code-editor {
  backdrop-filter: blur(14px);
  background: rgba(0,0,0,0.8);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 8px;
  font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
  padding: 16px;
  color: rgba(255,255,255,0.9);
}
.glass-code-line-numbers {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.05);
  border-right: 1px solid rgba(255,255,255,0.1);
  color: rgba(255,255,255,0.4);
  padding: 0 8px;
}
```

**PDF-просмотрщик** - Компонент для отображения PDF документов
*Liquid Glass характеристики:* Стеклянные страницы документа с навигацией
```css
.glass-pdf-viewer {
  backdrop-filter: blur(18px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 12px;
  padding: 20px;
}
.glass-pdf-page {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.9);
  border: 1px solid rgba(0,0,0,0.1);
  border-radius: 8px;
  margin: 10px 0;
  box-shadow: 0 4px 16px rgba(0,0,0,0.1);
}
```

**Версионность файлов** - Отслеживание изменений в документах
*Liquid Glass характеристики:* Стеклянная временная шкала с точками версий
```css
.glass-version-timeline {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 16px;
}
.glass-version-point {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.3);
  border: 3px solid rgba(74,144,226,0.6);
  border-radius: 50%;
  width: 12px;
  height: 12px;
}
.glass-version-line {
  stroke: rgba(74,144,226,0.4);
  stroke-width: 2px;
}
```

**Корзина** - Управление удаленными файлами
*Liquid Glass характеристики:* Полупрозрачные стеклянные элементы удаленных файлов
```css
.glass-trash-container {
  backdrop-filter: blur(14px);
  background: rgba(244,67,54,0.1);
  border: 1px solid rgba(244,67,54,0.3);
  border-radius: 12px;
  padding: 16px;
}
.glass-deleted-file {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.05);
  border: 1px solid rgba(244,67,54,0.2);
  border-radius: 6px;
  padding: 8px;
  opacity: 0.6;
  transition: opacity 0.3s ease;
}
```

**Синхронизация** - Индикаторы состояния синхронизации облачных файлов
*Liquid Glass характеристики:* Стеклянные индикаторы с анимацией синхронизации
```css
.glass-sync-indicator {
  backdrop-filter: blur(10px);
  background: rgba(76,175,80,0.2);
  border: 2px solid rgba(76,175,80,0.4);
  border-radius: 50%;
  width: 24px;
  height: 24px;
  animation: glassSyncSpin 2s linear infinite;
}
.glass-sync-progress {
  backdrop-filter: blur(6px);
  background: rgba(255,255,255,0.1);
  border-radius: 10px;
  height: 4px;
  overflow: hidden;
}
```

## 23. Современные технологии

**AI-чат интерфейс** - Интерфейс для общения с искусственным интеллектом
*Liquid Glass характеристики:* Стеклянные пузыри сообщений с анимацией набора
```css
.glass-ai-chat {
  backdrop-filter: blur(18px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(255,255,255,0.25);
  border-radius: 16px;
  padding: 20px;
  height: 400px;
  overflow-y: auto;
}
.glass-ai-message {
  backdrop-filter: blur(8px);
  background: rgba(74,144,226,0.2);
  border: 1px solid rgba(74,144,226,0.3);
  border-radius: 18px 18px 4px 18px;
  padding: 12px 16px;
  margin: 8px 0;
  max-width: 80%;
}
.glass-typing-indicator {
  backdrop-filter: blur(6px);
  background: rgba(158,158,158,0.2);
  border-radius: 18px;
  padding: 12px 16px;
  animation: glassTypingPulse 1.5s infinite;
}
```

**Генератор контента** - Элементы для AI-создания текста и изображений
*Liquid Glass характеристики:* Стеклянные панели генерации с прогресс-индикаторами
```css
.glass-content-generator {
  backdrop-filter: blur(16px);
  background: rgba(255,255,255,0.11);
  border: 1px solid rgba(156,39,176,0.3);
  border-radius: 12px;
  padding: 20px;
}
.glass-generation-progress {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 20px;
  height: 8px;
  overflow: hidden;
}
.glass-generation-progress-bar {
  background: linear-gradient(90deg, rgba(156,39,176,0.6), rgba(233,30,99,0.8));
  height: 100%;
  animation: glassGenerating 2s linear infinite;
}
```

**Голосовые команды** - Интерфейс для голосового управления
*Liquid Glass характеристики:* Стеклянные индикаторы распознавания речи с волнами
```css
.glass-voice-interface {
  backdrop-filter: blur(20px);
  background: rgba(255,255,255,0.15);
  border: 2px solid rgba(244,67,54,0.4);
  border-radius: 50%;
  width: 80px;
  height: 80px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.glass-voice-wave {
  backdrop-filter: blur(4px);
  background: rgba(244,67,54,0.3);
  border-radius: 50%;
  animation: glassVoiceWave 1s ease-in-out infinite;
}
.glass-voice-active {
  animation: glassVoicePulse 0.5s ease-in-out infinite alternate;
}
```

**AR-компоненты** - Элементы дополненной реальности
*Liquid Glass характеристики:* Полупрозрачные стеклянные оверлеи с 3D-эффектами
```css
.glass-ar-overlay {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.2);
  border-radius: 8px;
  padding: 16px;
  transform: perspective(1000px) rotateX(5deg);
  box-shadow: 0 8px 32px rgba(0,0,0,0.1);
}
.glass-ar-marker {
  backdrop-filter: blur(6px);
  background: rgba(255,193,7,0.3);
  border: 2px solid rgba(255,193,7,0.6);
  border-radius: 50%;
  animation: glassARPulse 2s infinite;
}
```

**IoT-панели** - Управление подключенными устройствами
*Liquid Glass характеристики:* Стеклянные панели устройств с индикаторами состояния
```css
.glass-iot-panel {
  backdrop-filter: blur(14px);
  background: rgba(255,255,255,0.12);
  border: 1px solid rgba(76,175,80,0.3);
  border-radius: 12px;
  padding: 16px;
  display: grid;
  gap: 12px;
}
.glass-iot-device {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 12px;
  position: relative;
}
.glass-iot-status {
  backdrop-filter: blur(4px);
  border-radius: 50%;
  width: 10px;
  height: 10px;
  position: absolute;
  top: 8px;
  right: 8px;
}
.glass-iot-status.online { background: rgba(76,175,80,0.8); }
.glass-iot-status.offline { background: rgba(158,158,158,0.6); }
```

**Блокчейн-интерфейсы** - Компоненты для работы с криптовалютами и NFT
*Liquid Glass характеристики:* Стеклянные панели кошельков с криптографическими эффектами
```css
.glass-blockchain-wallet {
  backdrop-filter: blur(16px);
  background: linear-gradient(135deg, rgba(255,193,7,0.2), rgba(255,152,0,0.1));
  border: 2px solid rgba(255,193,7,0.4);
  border-radius: 16px;
  padding: 20px;
}
.glass-crypto-balance {
  backdrop-filter: blur(10px);
  background: rgba(255,255,255,0.1);
  border-radius: 8px;
  padding: 16px;
  text-align: center;
  font-family: 'Monaco', monospace;
}
.glass-nft-card {
  backdrop-filter: blur(12px);
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(156,39,176,0.3);
  border-radius: 12px;
  overflow: hidden;
  transition: transform 0.3s ease;
}
```

**Машинное обучение визуализация** - Отображение процесса обучения моделей
*Liquid Glass характеристики:* Стеклянные графики нейронных сетей с анимированными связями
```css
.glass-ml-visualization {
  backdrop-filter: blur(18px);
  background: rgba(255,255,255,0.1);
  border: 1px solid rgba(74,144,226,0.3);
  border-radius: 12px;
  padding: 20px;
  min-height: 300px;
}
.glass-neural-node {
  backdrop-filter: blur(6px);
  background: rgba(74,144,226,0.3);
  border: 2px solid rgba(74,144,226,0.5);
  border-radius: 50%;
  animation: glassNeuralPulse 3s ease-in-out infinite;
}
.glass-neural-connection {
  stroke: rgba(74,144,226,0.4);
  stroke-width: 2px;
  animation: glassNeuralFlow 2s linear infinite;
}
.glass-training-progress {
  backdrop-filter: blur(8px);
  background: rgba(255,255,255,0.1);
  border-radius: 20px;
  height: 6px;
  overflow: hidden;
}
```