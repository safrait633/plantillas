# 🧠 Основные концепции Liquid Glass

Понимание принципов создания эффекта жидкого стекла и философии дизайна.

## 🎯 Что такое Liquid Glass?

**Liquid Glass** — это дизайн-система, основанная на эффекте полупрозрачного стекла с размытием фона (backdrop-filter), создающая ощущение глубины и современности.

### 🌊 Философия дизайна

> "Интерфейс должен быть как чистое стекло — прозрачным для контента, но добавляющим магию взаимодействия"

#### Ключевые принципы:
- **Прозрачность** - элементы не блокируют фон полностью
- **Глубина** - многослойная композиция создает объем
- **Плавность** - все переходы естественны и отзывчивы
- **Минимализм** - эффекты подчеркивают, а не отвлекают

## 🔬 Анатомия Glass эффекта

### Базовая формула
```css
.liquid-glass {
  /* 1. Полупрозрачный фон */
  background: rgba(255, 255, 255, 0.1);
  
  /* 2. Размытие заднего фона */
  backdrop-filter: blur(10px);
  
  /* 3. Тонкая граница */
  border: 1px solid rgba(255, 255, 255, 0.2);
  
  /* 4. Скругленные углы */
  border-radius: 16px;
  
  /* 5. Плавные переходы */
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
```

### 🎛️ Уровни интенсивности

#### Light Glass
```css
.glass-light {
  background: rgba(255, 255, 255, 0.05);
  backdrop-filter: blur(8px);
  border: 1px solid rgba(255, 255, 255, 0.1);
}
```
*Использование*: Второстепенные элементы, фоновые карточки

#### Medium Glass  
```css
.glass-medium {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}
```
*Использование*: Основные карточки, формы, модальные окна

#### Heavy Glass
```css
.glass-heavy {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(16px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}
```
*Использование*: Навигация, панели управления, важные элементы

## 🌈 Цветовая система

### Принципы работы с цветом

#### 1. Градиентные фоны
Glass эффекты лучше всего работают на градиентных фонах:

```css
/* Спокойный голубой */
.bg-calm-blue {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

/* Энергичный зеленый */
.bg-energy-green {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}

/* Теплый закат */
.bg-warm-sunset {
  background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
}

/* Космический */
.bg-cosmic {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
```

#### 2. Адаптивные glass цвета
```css
/* Для светлых фонов */
.glass-on-light {
  background: rgba(0, 0, 0, 0.05);
  border: 1px solid rgba(0, 0, 0, 0.1);
  color: #333;
}

/* Для темных фонов */
.glass-on-dark {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

/* Автоматическая адаптация */
.glass-adaptive {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

@media (prefers-color-scheme: light) {
  .glass-adaptive {
    background: rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.1);
    color: #333;
  }
}
```

### 🎨 Семантические цвета

```css
/* Успех */
.glass-success {
  background: rgba(34, 197, 94, 0.1);
  border: 1px solid rgba(34, 197, 94, 0.3);
}

/* Предупреждение */
.glass-warning {
  background: rgba(251, 191, 36, 0.1);
  border: 1px solid rgba(251, 191, 36, 0.3);
}

/* Ошибка */
.glass-error {
  background: rgba(239, 68, 68, 0.1);
  border: 1px solid rgba(239, 68, 68, 0.3);
}

/* Информация */
.glass-info {
  background: rgba(59, 130, 246, 0.1);
  border: 1px solid rgba(59, 130, 246, 0.3);
}
```

## ✨ Микровзаимодействия

### Hover эффекты
```css
.glass-interactive {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.glass-interactive:hover {
  /* Усиление glass эффекта */
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(15px);
  
  /* Подъем элемента */
  transform: translateY(-4px);
  
  /* Тень */
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}
```

### Active состояния
```css
.glass-interactive:active {
  transform: translateY(-2px) scale(0.98);
  transition: all 0.1s ease;
}
```

### Focus состояния
```css
.glass-interactive:focus {
  outline: none;
  border-color: rgba(59, 130, 246, 0.5);
  box-shadow: 
    0 0 0 3px rgba(59, 130, 246, 0.1),
    0 20px 40px rgba(0, 0, 0, 0.15);
}
```

## 📏 Пространство и типографика

### Сетка и отступы
```css
/* Базовая единица = 4px */
.spacing-xs { padding: 8px; }   /* 2 units */
.spacing-sm { padding: 12px; }  /* 3 units */
.spacing-md { padding: 16px; }  /* 4 units */
.spacing-lg { padding: 24px; }  /* 6 units */
.spacing-xl { padding: 32px; }  /* 8 units */
.spacing-2xl { padding: 48px; } /* 12 units */
```

### Радиусы скругления
```css
.radius-sm { border-radius: 8px; }   /* Мелкие элементы */
.radius-md { border-radius: 12px; }  /* Кнопки, инпуты */
.radius-lg { border-radius: 16px; }  /* Карточки */
.radius-xl { border-radius: 24px; }  /* Панели */
.radius-2xl { border-radius: 32px; } /* Контейнеры */
```

### Типографика на glass элементах
```css
.glass-text {
  color: rgba(255, 255, 255, 0.9);
  font-weight: 500;
  line-height: 1.5;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

.glass-text-secondary {
  color: rgba(255, 255, 255, 0.7);
  font-weight: 400;
}

.glass-text-muted {
  color: rgba(255, 255, 255, 0.5);
  font-size: 0.875rem;
}
```

## 📱 Адаптивность

### Responsive glass
```css
.glass-responsive {
  /* Мобильные устройства */
  @media (max-width: 768px) {
    backdrop-filter: blur(8px); /* Меньше размытия для производительности */
    border-radius: 12px;        /* Меньший радиус */
    padding: 16px;              /* Компактные отступы */
  }
  
  /* Планшеты */
  @media (min-width: 769px) and (max-width: 1024px) {
    backdrop-filter: blur(12px);
    border-radius: 16px;
    padding: 20px;
  }
  
  /* Десктоп */
  @media (min-width: 1025px) {
    backdrop-filter: blur(16px);
    border-radius: 20px;
    padding: 24px;
  }
}
```

### Производительность на мобильных
```css
/* Облегченная версия для слабых устройств */
@media (max-width: 480px), (pointer: coarse) {
  .glass-performance {
    backdrop-filter: none; /* Отключаем размытие */
    background: rgba(255, 255, 255, 0.2); /* Увеличиваем непрозрачность */
    border: 2px solid rgba(255, 255, 255, 0.3); /* Более заметная граница */
  }
}
```

## ♿ Доступность

### Контрастность
```css
.glass-accessible {
  /* Минимальный контраст 4.5:1 для текста */
  color: white;
  background: rgba(0, 0, 0, 0.6); /* Более темный фон при необходимости */
}

/* Высокий контраст для важных элементов */
@media (prefers-contrast: high) {
  .glass-accessible {
    background: rgba(0, 0, 0, 0.8);
    border: 2px solid white;
  }
}
```

### Reduced motion
```css
@media (prefers-reduced-motion: reduce) {
  .glass-animated {
    transition: none;
    animation: none;
    transform: none;
  }
}
```

## 🎪 Практические примеры

### Навигационная панель
```css
.glass-navbar {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 50px;
  padding: 8px 24px;
  z-index: 100;
}
```

### Карточка продукта
```css
.glass-product-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 24px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  overflow: hidden;
}

.glass-product-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.1), transparent);
  transition: left 0.5s ease;
}

.glass-product-card:hover::before {
  left: 100%;
}
```

### Модальное окно
```css
.glass-modal {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 24px;
  padding: 32px;
  max-width: 90vw;
  max-height: 90vh;
  overflow-y: auto;
}

.glass-modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.3);
  backdrop-filter: blur(2px);
}
```

## 🔧 Инструменты разработчика

### CSS переменные
```css
:root {
  /* Glass интенсивность */
  --glass-bg-light: rgba(255, 255, 255, 0.05);
  --glass-bg-medium: rgba(255, 255, 255, 0.1);
  --glass-bg-heavy: rgba(255, 255, 255, 0.15);
  
  /* Границы */
  --glass-border-light: rgba(255, 255, 255, 0.1);
  --glass-border-medium: rgba(255, 255, 255, 0.2);
  --glass-border-heavy: rgba(255, 255, 255, 0.3);
  
  /* Размытие */
  --glass-blur-light: 8px;
  --glass-blur-medium: 12px;
  --glass-blur-heavy: 16px;
  
  /* Радиусы */
  --radius-sm: 8px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --radius-xl: 24px;
  
  /* Анимации */
  --transition-fast: 0.15s ease;
  --transition-normal: 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  --transition-slow: 0.5s cubic-bezier(0.4, 0, 0.2, 1);
}
```

---

## 🚀 Следующие шаги

1. **[Библиотека компонентов](./03-components-library.md)** - изучите готовые решения
2. **[Паттерны проектирования](./04-design-patterns.md)** - комплексные интерфейсы
3. **[Практическая реализация](./05-implementation.md)** - интеграция в проекты

**⏱️ Время изучения**: ~15 минут  
**🔧 Сложность**: Новичок → Средний