# ✨ Best Practices и Оптимизация

Профессиональные советы по использованию Liquid Glass эффектов в production проектах.

## 🚀 Performance Optimization

### 1. Backdrop-filter оптимизация

#### ❌ Не делайте так:
```css
/* Слишком сильное размытие на каждом элементе */
.card {
  backdrop-filter: blur(50px); /* Тяжело для GPU */
}

/* Размытие на анимированных элементах */
.animated-card {
  backdrop-filter: blur(20px);
  animation: bounce 2s infinite; /* Лагает */
}
```

#### ✅ Лучше так:
```css
/* Умеренное размытие */
.card {
  backdrop-filter: blur(12px); /* Оптимально */
}

/* Отключение эффектов на слабых устройствах */
@media (max-width: 768px), (pointer: coarse) {
  .card {
    backdrop-filter: none;
    background: rgba(255, 255, 255, 0.3);
  }
}

/* Использование will-change для анимаций */
.animated-card {
  will-change: transform;
  backdrop-filter: blur(8px); /* Меньше для анимации */
}

.animated-card:hover {
  transform: translateY(-8px);
}
```

### 2. CSS переменные для производительности

```css
:root {
  /* Единая система размытия */
  --blur-light: 8px;
  --blur-medium: 12px;
  --blur-heavy: 16px;
  
  /* Базовые цвета glass */
  --glass-bg: rgba(255, 255, 255, 0.1);
  --glass-border: rgba(255, 255, 255, 0.2);
  
  /* Условное отключение для слабых устройств */
  --blur-mobile: 0px;
}

@media (min-width: 769px) and (min-resolution: 2dppx) {
  :root {
    --blur-mobile: var(--blur-medium);
  }
}

.glass-component {
  backdrop-filter: blur(var(--blur-mobile));
  background: var(--glass-bg);
  border: 1px solid var(--glass-border);
}
```

### 3. Lazy loading для сложных эффектов

```javascript
// Intersection Observer для активации эффектов
const glassObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('glass-active');
    }
  });
}, { threshold: 0.1 });

// Базовые стили без эффектов
document.querySelectorAll('.glass-lazy').forEach(el => {
  glassObserver.observe(el);
});
```

```css
.glass-lazy {
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.glass-lazy.glass-active {
  backdrop-filter: blur(12px);
  background: rgba(255, 255, 255, 0.1);
}
```

## 🎨 Design Guidelines

### 1. Иерархия glass эффектов

```css
/* Система уровней важности */
.glass-background {
  /* Фоновые элементы - минимальный эффект */
  backdrop-filter: blur(4px);
  background: rgba(255, 255, 255, 0.03);
  border: 1px solid rgba(255, 255, 255, 0.05);
}

.glass-secondary {
  /* Второстепенный контент */
  backdrop-filter: blur(8px);
  background: rgba(255, 255, 255, 0.07);
  border: 1px solid rgba(255, 255, 255, 0.15);
}

.glass-primary {
  /* Основной контент */
  backdrop-filter: blur(12px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.glass-focus {
  /* Элементы в фокусе */
  backdrop-filter: blur(16px);
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.3);
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}
```

### 2. Цветовая адаптация

```css
/* Умная адаптация к фону */
.glass-adaptive {
  /* Базовые стили для темного фона */
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}

/* Автоматическая адаптация к светлой теме */
@media (prefers-color-scheme: light) {
  .glass-adaptive {
    background: rgba(0, 0, 0, 0.05);
    border: 1px solid rgba(0, 0, 0, 0.1);
    color: #1a1a1a;
  }
}

/* Контекстная адаптация */
.light-context .glass-adaptive {
  background: rgba(0, 0, 0, 0.05);
  border: 1px solid rgba(0, 0, 0, 0.1);
  color: #1a1a1a;
}

.dark-context .glass-adaptive {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  color: white;
}
```

### 3. Responsive glass дизайн

```css
/* Mobile-first подход */
.glass-responsive {
  /* Мобильная версия - упрощенная */
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  backdrop-filter: none; /* Отключаем на мобильных */
  border-radius: 12px;
  padding: 16px;
}

/* Планшеты - частичные эффекты */
@media (min-width: 768px) {
  .glass-responsive {
    backdrop-filter: blur(8px);
    background: rgba(255, 255, 255, 0.15);
    border-radius: 16px;
    padding: 20px;
  }
}

/* Десктоп - полные эффекты */
@media (min-width: 1024px) {
  .glass-responsive {
    backdrop-filter: blur(12px);
    background: rgba(255, 255, 255, 0.1);
    border-radius: 20px;
    padding: 24px;
  }
}

/* Высокие разрешения - усиленные эффекты */
@media (min-width: 1024px) and (min-resolution: 2dppx) {
  .glass-responsive {
    backdrop-filter: blur(16px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.12);
  }
}
```

## ♿ Accessibility Best Practices

### 1. Контрастность и читаемость

```css
/* Обеспечиваем минимальный контраст 4.5:1 */
.glass-accessible {
  background: rgba(0, 0, 0, 0.6); /* Темнее для лучшего контраста */
  border: 1px solid rgba(255, 255, 255, 0.3);
  color: white;
  /* Дополнительная тень для текста */
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.8);
}

/* Высококонтрастный режим */
@media (prefers-contrast: high) {
  .glass-accessible {
    background: rgba(0, 0, 0, 0.9);
    border: 2px solid white;
    backdrop-filter: none;
  }
}

/* Проверка контрастности в runtime */
.glass-text {
  /* Fallback цвет с хорошим контрастом */
  color: #ffffff;
  /* Тень для улучшения читаемости */
  text-shadow: 
    0 1px 1px rgba(0, 0, 0, 0.8),
    0 0 1px rgba(0, 0, 0, 0.8);
}
```

### 2. Reduced motion

```css
/* Уважаем предпочтения пользователя */
@media (prefers-reduced-motion: reduce) {
  .glass-animated {
    animation: none;
    transition: none;
  }
  
  .glass-hover:hover {
    transform: none; /* Отключаем движение при hover */
  }
}

/* Альтернативная индикация без движения */
@media (prefers-reduced-motion: reduce) {
  .glass-interactive:hover {
    background: rgba(255, 255, 255, 0.2);
    border-color: rgba(255, 255, 255, 0.4);
  }
  
  .glass-interactive:focus {
    outline: 2px solid rgba(59, 130, 246, 0.8);
    outline-offset: 2px;
  }
}
```

### 3. Семантическая доступность

```html
<!-- Правильная семантика -->
<article class="glass-card" role="article" aria-labelledby="card-title">
  <h3 id="card-title">Заголовок карточки</h3>
  <p>Описание содержимого</p>
  <button aria-describedby="card-title">Действие</button>
</article>

<!-- Screen reader поддержка -->
<div class="glass-modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
  <h2 id="modal-title">Модальное окно</h2>
  <!-- содержимое -->
</div>
```

```css
/* Индикация фокуса для клавиатурной навигации */
.glass-interactive:focus-visible {
  outline: 2px solid rgba(59, 130, 246, 0.8);
  outline-offset: 2px;
  background: rgba(255, 255, 255, 0.15);
}

/* Скрытие outline для мыши, показ для клавиатуры */
.glass-interactive:focus:not(:focus-visible) {
  outline: none;
}
```

## 🛠️ Development Tools

### 1. CSS Debugging

```css
/* Debug helper для проверки стекинга */
.glass-debug {
  position: relative;
}

.glass-debug::before {
  content: attr(data-layer);
  position: absolute;
  top: 4px;
  right: 4px;
  background: rgba(255, 0, 0, 0.8);
  color: white;
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
  z-index: 1000;
  font-family: monospace;
}

/* Использование */
.glass-card {
  /* data-layer="primary" */
}
```

### 2. Performance мониторинг

```javascript
// Проверка поддержки backdrop-filter
function supportsBackdropFilter() {
  return CSS.supports('backdrop-filter', 'blur(1px)') || 
         CSS.supports('-webkit-backdrop-filter', 'blur(1px)');
}

// Fallback для неподдерживаемых браузеров
if (!supportsBackdropFilter()) {
  document.documentElement.classList.add('no-backdrop-filter');
}

// Performance observer для мониторинга
const observer = new PerformanceObserver((list) => {
  for (const entry of list.getEntries()) {
    if (entry.name === 'glass-animation') {
      console.log(`Glass animation took ${entry.duration}ms`);
    }
  }
});
observer.observe({ entryTypes: ['measure'] });

// Измерение производительности анимаций
function measureGlassPerformance() {
  performance.mark('glass-start');
  
  requestAnimationFrame(() => {
    performance.mark('glass-end');
    performance.measure('glass-animation', 'glass-start', 'glass-end');
  });
}
```

### 3. CSS fallbacks

```css
/* Fallback для браузеров без backdrop-filter */
.no-backdrop-filter .glass-component {
  background: rgba(255, 255, 255, 0.25);
  border: 2px solid rgba(255, 255, 255, 0.4);
}

/* Feature detection в CSS */
@supports (backdrop-filter: blur(1px)) {
  .glass-component {
    backdrop-filter: blur(12px);
    background: rgba(255, 255, 255, 0.1);
  }
}

@supports not (backdrop-filter: blur(1px)) {
  .glass-component {
    background: rgba(255, 255, 255, 0.3);
    box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.3);
  }
}
```

## 🎯 Production Checklist

### ✅ Performance
- [ ] backdrop-filter не превышает 16px
- [ ] will-change используется только для анимированных элементов
- [ ] Lazy loading для сложных эффектов
- [ ] Fallback для слабых устройств
- [ ] CSS переменные для управления эффектами

### ✅ Accessibility  
- [ ] Контрастность текста минимум 4.5:1
- [ ] Поддержка prefers-reduced-motion
- [ ] Клавиатурная навигация
- [ ] Screen reader совместимость
- [ ] High contrast mode поддержка

### ✅ Browser Support
- [ ] Fallback для старых браузеров
- [ ] Feature detection
- [ ] Progressive enhancement
- [ ] Prefix для -webkit-backdrop-filter

### ✅ Design System
- [ ] Консистентная иерархия эффектов
- [ ] Единая цветовая система
- [ ] Responsive поведение
- [ ] Dark/Light theme поддержка

## 🐛 Common Issues & Solutions

### 1. Размытие не работает

**Проблема**: backdrop-filter не применяется

**Решения**:
```css
/* Проверьте поддержку браузера */
.glass {
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px); /* Safari */
}

/* Убедитесь в правильном stacking context */
.glass {
  position: relative; /* или absolute/fixed */
  z-index: 1;
}

/* Проверьте родительские элементы */
.parent {
  isolation: isolate; /* Создает новый stacking context */
}
```

### 2. Плохая производительность

**Проблема**: Лаги при скролле или анимациях

**Решения**:
```css
/* Оптимизация для GPU */
.glass-optimized {
  transform: translateZ(0); /* Принудительное использование GPU */
  will-change: transform; /* Только для анимированных элементов */
}

/* Упрощение на мобильных */
@media (max-width: 768px) {
  .glass-mobile {
    backdrop-filter: none;
    background: rgba(255, 255, 255, 0.3);
  }
}
```

### 3. Проблемы с контрастностью

**Проблема**: Текст плохо читается

**Решения**:
```css
/* Усиление фона */
.glass-readable {
  background: rgba(0, 0, 0, 0.4); /* Темнее */
  color: white;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.8);
}

/* Адаптивный контраст */
.glass-smart {
  background: color-mix(in srgb, transparent 70%, black 30%);
}
```

---

## 🎓 Advanced Techniques

### CSS Houdini для продвинутых эффектов

```javascript
// Регистрация custom property
CSS.registerProperty({
  name: '--glass-intensity',
  syntax: '<number>',
  inherits: false,
  initialValue: 1
});
```

```css
.glass-advanced {
  backdrop-filter: blur(calc(var(--glass-intensity) * 12px));
  transition: --glass-intensity 0.3s ease;
}

.glass-advanced:hover {
  --glass-intensity: 1.5;
}
```

### Container Queries для responsive glass

```css
.glass-container {
  container-type: inline-size;
}

@container (width > 400px) {
  .glass-responsive {
    backdrop-filter: blur(12px);
  }
}

@container (width <= 400px) {
  .glass-responsive {
    backdrop-filter: none;
  }
}
```

---

**⏱️ Время изучения**: ~15 минут  
**🔧 Сложность**: Средний → Продвинутый  
**🎯 Результат**: Production-ready Liquid Glass система