# 🚀 Быстрый старт с Liquid Glass

Начните создавать потрясающие интерфейсы за 5 минут!

## ⚡ Мгновенная установка

### Вариант 1: CDN (самый быстрый)
```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquid Glass Demo</title>
    <style>
        /* Liquid Glass Core Styles */
        .liquid-glass {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 24px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .liquid-glass:hover {
            background: rgba(255, 255, 255, 0.15);
            transform: translateY(-2px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        body {
            margin: 0;
            padding: 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }
    </style>
</head>
<body>
    <div class="liquid-glass">
        <h1 style="color: white; margin: 0 0 16px 0;">🌊 Liquid Glass</h1>
        <p style="color: rgba(255,255,255,0.8); margin: 0;">
            Ваш первый glass компонент готов!
        </p>
    </div>
</body>
</html>
```

### Вариант 2: React компонент
```jsx
import React from 'react';

const LiquidGlass = ({ children, className = '', ...props }) => (
  <div 
    className={`liquid-glass ${className}`}
    style={{
      background: 'rgba(255, 255, 255, 0.1)',
      backdropFilter: 'blur(10px)',
      border: '1px solid rgba(255, 255, 255, 0.2)',
      borderRadius: '16px',
      padding: '24px',
      transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    }}
    {...props}
  >
    {children}
  </div>
);

// Использование
export default function App() {
  return (
    <div style={{
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      minHeight: '100vh',
      padding: '40px'
    }}>
      <LiquidGlass>
        <h1 style={{ color: 'white', margin: '0 0 16px 0' }}>
          🌊 Liquid Glass React
        </h1>
        <p style={{ color: 'rgba(255,255,255,0.8)', margin: 0 }}>
          Компонент работает!
        </p>
      </LiquidGlass>
    </div>
  );
}
```

### Вариант 3: CSS классы
```css
/* Добавьте в ваш CSS файл */
.liquid-glass-light {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
}

.liquid-glass-medium {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.3);
}

.liquid-glass-heavy {
  background: rgba(255, 255, 255, 0.2);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.4);
}

/* Базовые стили */
.glass-card {
  border-radius: 16px;
  padding: 24px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.glass-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
}
```

## 🎨 Готовые компоненты (копируй и вставляй)

### 🔘 Glass кнопка
```html
<button class="glass-button">
  Нажми меня
</button>

<style>
.glass-button {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 12px 24px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
}

.glass-button:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: scale(1.05);
}

.glass-button:active {
  transform: scale(0.95);
}
</style>
```

### 📝 Glass форма
```html
<form class="glass-form">
  <input type="email" placeholder="Email" class="glass-input">
  <input type="password" placeholder="Пароль" class="glass-input">
  <button type="submit" class="glass-button">Войти</button>
</form>

<style>
.glass-form {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 32px;
  max-width: 400px;
}

.glass-input {
  width: 100%;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  padding: 12px 16px;
  margin-bottom: 16px;
  color: white;
  font-size: 16px;
}

.glass-input::placeholder {
  color: rgba(255, 255, 255, 0.6);
}

.glass-input:focus {
  outline: none;
  border-color: rgba(255, 255, 255, 0.4);
  background: rgba(255, 255, 255, 0.15);
}
</style>
```

### 🎴 Glass карточка
```html
<div class="glass-card">
  <h3>Заголовок</h3>
  <p>Описание карточки с прозрачным фоном</p>
  <div class="card-footer">
    <button class="glass-button-small">Действие</button>
  </div>
</div>

<style>
.glass-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  padding: 24px;
  max-width: 300px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.glass-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
  background: rgba(255, 255, 255, 0.15);
}

.glass-card h3 {
  color: white;
  margin: 0 0 12px 0;
  font-size: 1.25rem;
}

.glass-card p {
  color: rgba(255, 255, 255, 0.8);
  margin: 0 0 20px 0;
  line-height: 1.5;
}

.card-footer {
  display: flex;
  justify-content: flex-end;
}

.glass-button-small {
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  padding: 8px 16px;
  color: white;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.glass-button-small:hover {
  background: rgba(255, 255, 255, 0.2);
}
</style>
```

## 🌈 Цветовые вариации

### Голубой градиент
```css
.bg-blue-gradient {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
```

### Зеленый градиент
```css
.bg-green-gradient {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
}
```

### Фиолетовый градиент
```css
.bg-purple-gradient {
  background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
}
```

### Темная тема
```css
.glass-dark {
  background: rgba(0, 0, 0, 0.3);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.1);
}
```

## ⚡ 30-секундное демо

Создайте файл `demo.html` и скопируйте этот код:

```html
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Liquid Glass - 30 Second Demo</title>
    <style>
        body {
            margin: 0;
            padding: 40px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }
        
        .container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 24px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .glass-card {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(12px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 16px;
            padding: 24px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .glass-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
            background: rgba(255, 255, 255, 0.15);
        }
        
        .glass-card h3 {
            color: white;
            margin: 0 0 12px 0;
        }
        
        .glass-card p {
            color: rgba(255, 255, 255, 0.8);
            margin: 0 0 20px 0;
            line-height: 1.5;
        }
        
        .glass-button {
            background: rgba(255, 255, 255, 0.1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            border-radius: 8px;
            padding: 8px 16px;
            color: white;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .glass-button:hover {
            background: rgba(255, 255, 255, 0.2);
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="glass-card">
            <h3>🌊 Liquid Glass</h3>
            <p>Создавайте потрясающие интерфейсы с эффектом жидкого стекла</p>
            <button class="glass-button">Узнать больше</button>
        </div>
        
        <div class="glass-card">
            <h3>⚡ Быстро</h3>
            <p>Готовые компоненты позволяют создать интерфейс за минуты</p>
            <button class="glass-button">Попробовать</button>
        </div>
        
        <div class="glass-card">
            <h3>🎨 Красиво</h3>
            <p>Современный дизайн, который впечатляет пользователей</p>
            <button class="glass-button">Примеры</button>
        </div>
    </div>
</body>
</html>
```

Откройте файл в браузере и наслаждайтесь! 🎉

## 🔥 Следующие шаги

1. **[Изучите основы](./02-core-concepts.md)** - понимание принципов дизайна
2. **[Библиотека компонентов](./03-components-library.md)** - 50+ готовых элементов
3. **[Паттерны проектирования](./04-design-patterns.md)** - комплексные решения
4. **[Практическая реализация](./05-implementation.md)** - интеграция в проекты

## 🆘 Нужна помощь?

- 📖 **Документация**: [Полное руководство](../README.md)
- 💬 **Сообщество**: GitHub Discussions
- 🐛 **Баги**: GitHub Issues

---

**🎯 Цель**: За 5 минут вы должны увидеть работающий glass эффект!  
**⏱️ Время**: ~5 минут  
**🔧 Сложность**: Новичок