# 🎨 Библиотека компонентов Liquid Glass

Готовые к использованию компоненты с эффектом жидкого стекла. Копируйте код и адаптируйте под свои нужды.

## 🔘 Кнопки

### Базовые кнопки
```html
<!-- Обычная glass кнопка -->
<button class="glass-btn">Кликните меня</button>

<!-- Primary кнопка -->
<button class="glass-btn glass-btn-primary">Primary Action</button>

<!-- Danger кнопка -->
<button class="glass-btn glass-btn-danger">Delete</button>

<!-- Outline кнопка -->
<button class="glass-btn glass-btn-outline">Secondary</button>
```

```css
.glass-btn {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 12px 24px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  font-size: 16px;
  text-decoration: none;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  justify-content: center;
}

.glass-btn:hover {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

.glass-btn:active {
  transform: translateY(0);
}

.glass-btn-primary {
  background: rgba(59, 130, 246, 0.3);
  border-color: rgba(59, 130, 246, 0.5);
}

.glass-btn-danger {
  background: rgba(239, 68, 68, 0.3);
  border-color: rgba(239, 68, 68, 0.5);
}

.glass-btn-outline {
  background: transparent;
  border: 2px solid rgba(255, 255, 255, 0.3);
}

.glass-btn-outline:hover {
  background: rgba(255, 255, 255, 0.1);
}

/* Размеры */
.glass-btn-small { padding: 8px 16px; font-size: 14px; }
.glass-btn-large { padding: 16px 32px; font-size: 18px; }

/* Состояния */
.glass-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
  transform: none;
}

.glass-btn-loading {
  position: relative;
  color: transparent;
}

.glass-btn-loading::after {
  content: '';
  position: absolute;
  width: 16px;
  height: 16px;
  border: 2px solid transparent;
  border-top: 2px solid currentColor;
  border-radius: 50%;
  animation: spin 1s linear infinite;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

@keyframes spin {
  to { transform: translate(-50%, -50%) rotate(360deg); }
}
```

## 🎴 Карточки

### Простая карточка
```html
<div class="glass-card">
  <h3>Заголовок карточки</h3>
  <p>Описание контента с полупрозрачным фоном и эффектом размытия.</p>
  <div class="glass-card-actions">
    <button class="glass-btn glass-btn-small">Действие</button>
  </div>
</div>
```

```css
.glass-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  padding: 24px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.glass-card:hover {
  transform: translateY(-8px);
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.2);
  background: rgba(255, 255, 255, 0.15);
}

.glass-card h3 {
  color: white;
  margin: 0 0 12px 0;
  font-size: 1.25rem;
  font-weight: 600;
}

.glass-card p {
  color: rgba(255, 255, 255, 0.8);
  margin: 0 0 20px 0;
  line-height: 1.5;
}

.glass-card-actions {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
}
```

### Карточка продукта
```html
<div class="glass-product-card">
  <div class="product-image">
    <img src="product.jpg" alt="Product">
    <div class="product-badge">New</div>
  </div>
  <div class="product-content">
    <h3>Название продукта</h3>
    <p class="product-price">$99.99</p>
    <p class="product-description">Краткое описание продукта</p>
    <button class="glass-btn glass-btn-primary">В корзину</button>
  </div>
</div>
```

```css
.glass-product-card {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(12px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  overflow: hidden;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  max-width: 300px;
}

.glass-product-card:hover {
  transform: translateY(-12px);
  box-shadow: 0 30px 60px rgba(0, 0, 0, 0.3);
}

.product-image {
  position: relative;
  height: 200px;
  overflow: hidden;
}

.product-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: transform 0.3s ease;
}

.glass-product-card:hover .product-image img {
  transform: scale(1.1);
}

.product-badge {
  position: absolute;
  top: 12px;
  right: 12px;
  background: rgba(34, 197, 94, 0.9);
  backdrop-filter: blur(10px);
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
  color: white;
}

.product-content {
  padding: 20px;
}

.product-content h3 {
  margin: 0 0 8px 0;
  color: white;
  font-weight: 600;
}

.product-price {
  font-size: 1.5rem;
  font-weight: 700;
  color: #4ade80;
  margin: 0 0 8px 0;
}

.product-description {
  color: rgba(255, 255, 255, 0.7);
  font-size: 14px;
  margin: 0 0 16px 0;
  line-height: 1.4;
}
```

## 📝 Формы

### Базовая форма
```html
<form class="glass-form">
  <div class="form-group">
    <label for="name">Имя</label>
    <input type="text" id="name" class="glass-input" placeholder="Введите имя">
  </div>
  
  <div class="form-group">
    <label for="email">Email</label>
    <input type="email" id="email" class="glass-input" placeholder="example@email.com">
  </div>
  
  <div class="form-group">
    <label for="message">Сообщение</label>
    <textarea id="message" class="glass-input glass-textarea" placeholder="Ваше сообщение..."></textarea>
  </div>
  
  <button type="submit" class="glass-btn glass-btn-primary">Отправить</button>
</form>
```

```css
.glass-form {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 32px;
  max-width: 500px;
}

.form-group {
  margin-bottom: 20px;
}

.form-group label {
  display: block;
  margin-bottom: 8px;
  color: rgba(255, 255, 255, 0.9);
  font-weight: 500;
  font-size: 14px;
}

.glass-input {
  width: 100%;
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  padding: 12px 16px;
  color: white;
  font-size: 16px;
  transition: all 0.3s ease;
  font-family: inherit;
}

.glass-input::placeholder {
  color: rgba(255, 255, 255, 0.6);
}

.glass-input:focus {
  outline: none;
  border-color: rgba(59, 130, 246, 0.5);
  background: rgba(255, 255, 255, 0.15);
  box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.glass-textarea {
  resize: vertical;
  min-height: 100px;
}

/* Input с иконкой */
.input-with-icon {
  position: relative;
}

.input-with-icon .glass-input {
  padding-left: 44px;
}

.input-with-icon .input-icon {
  position: absolute;
  left: 16px;
  top: 50%;
  transform: translateY(-50%);
  color: rgba(255, 255, 255, 0.6);
  pointer-events: none;
}
```

### Форма входа
```html
<div class="glass-login-form">
  <h2>Вход в систему</h2>
  <form>
    <div class="input-with-icon">
      <span class="input-icon">📧</span>
      <input type="email" class="glass-input" placeholder="Email">
    </div>
    
    <div class="input-with-icon">
      <span class="input-icon">🔒</span>
      <input type="password" class="glass-input" placeholder="Пароль">
    </div>
    
    <div class="form-options">
      <label class="glass-checkbox">
        <input type="checkbox">
        <span class="checkmark"></span>
        Запомнить меня
      </label>
      <a href="#" class="forgot-link">Забыли пароль?</a>
    </div>
    
    <button type="submit" class="glass-btn glass-btn-primary glass-btn-full">Войти</button>
  </form>
</div>
```

```css
.glass-login-form {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 24px;
  padding: 40px;
  max-width: 400px;
  text-align: center;
}

.glass-login-form h2 {
  color: white;
  margin: 0 0 32px 0;
  font-weight: 600;
}

.glass-login-form form {
  display: flex;
  flex-direction: column;
  gap: 20px;
}

.form-options {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
}

.glass-checkbox {
  display: flex;
  align-items: center;
  color: rgba(255, 255, 255, 0.8);
  cursor: pointer;
}

.glass-checkbox input {
  display: none;
}

.checkmark {
  width: 16px;
  height: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 3px;
  margin-right: 8px;
  position: relative;
  transition: all 0.3s ease;
}

.glass-checkbox input:checked + .checkmark {
  background: rgba(59, 130, 246, 0.8);
  border-color: rgba(59, 130, 246, 0.8);
}

.glass-checkbox input:checked + .checkmark::after {
  content: '✓';
  position: absolute;
  color: white;
  font-size: 10px;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.forgot-link {
  color: rgba(59, 130, 246, 0.9);
  text-decoration: none;
  transition: color 0.3s ease;
}

.forgot-link:hover {
  color: rgba(59, 130, 246, 1);
}

.glass-btn-full {
  width: 100%;
}
```

## 🧭 Навигация

### Navbar
```html
<nav class="glass-navbar">
  <div class="navbar-brand">
    <img src="logo.svg" alt="Logo">
    <span>Brand</span>
  </div>
  
  <div class="navbar-menu">
    <a href="#" class="navbar-link active">Главная</a>
    <a href="#" class="navbar-link">О нас</a>
    <a href="#" class="navbar-link">Услуги</a>
    <a href="#" class="navbar-link">Контакты</a>
  </div>
  
  <div class="navbar-actions">
    <button class="glass-btn glass-btn-small">Войти</button>
  </div>
</nav>
```

```css
.glass-navbar {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 50px;
  padding: 12px 24px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1000;
  max-width: 90vw;
}

.navbar-brand {
  display: flex;
  align-items: center;
  gap: 12px;
  color: white;
  font-weight: 600;
}

.navbar-brand img {
  width: 32px;
  height: 32px;
}

.navbar-menu {
  display: flex;
  gap: 24px;
}

.navbar-link {
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  padding: 8px 16px;
  border-radius: 20px;
  transition: all 0.3s ease;
  font-weight: 500;
}

.navbar-link:hover,
.navbar-link.active {
  color: white;
  background: rgba(255, 255, 255, 0.1);
}

@media (max-width: 768px) {
  .navbar-menu {
    display: none;
  }
  
  .glass-navbar {
    border-radius: 20px;
    position: relative;
    top: auto;
    transform: none;
    margin: 20px;
  }
}
```

### Sidebar
```html
<aside class="glass-sidebar">
  <div class="sidebar-header">
    <h3>Dashboard</h3>
  </div>
  
  <nav class="sidebar-nav">
    <a href="#" class="sidebar-link active">
      <span class="icon">📊</span>
      <span>Аналитика</span>
    </a>
    <a href="#" class="sidebar-link">
      <span class="icon">👥</span>
      <span>Пользователи</span>
    </a>
    <a href="#" class="sidebar-link">
      <span class="icon">⚙️</span>
      <span>Настройки</span>
    </a>
  </nav>
</aside>
```

```css
.glass-sidebar {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 20px;
  padding: 24px 0;
  width: 250px;
  height: calc(100vh - 40px);
  position: fixed;
  left: 20px;
  top: 20px;
}

.sidebar-header {
  padding: 0 24px 24px;
  border-bottom: 1px solid rgba(255, 255, 255, 0.1);
  margin-bottom: 24px;
}

.sidebar-header h3 {
  color: white;
  margin: 0;
  font-weight: 600;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
}

.sidebar-link {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 24px;
  color: rgba(255, 255, 255, 0.8);
  text-decoration: none;
  transition: all 0.3s ease;
  border-left: 3px solid transparent;
}

.sidebar-link:hover {
  background: rgba(255, 255, 255, 0.05);
  color: white;
}

.sidebar-link.active {
  background: rgba(255, 255, 255, 0.1);
  color: white;
  border-left-color: rgba(59, 130, 246, 0.8);
}

.sidebar-link .icon {
  font-size: 18px;
}
```

## 🔔 Уведомления

### Toast уведомления
```html
<div class="glass-toast glass-toast-success">
  <div class="toast-icon">✅</div>
  <div class="toast-content">
    <div class="toast-title">Успех!</div>
    <div class="toast-message">Данные сохранены успешно</div>
  </div>
  <button class="toast-close">&times;</button>
</div>
```

```css
.glass-toast {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(15px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  padding: 16px;
  display: flex;
  align-items: center;
  gap: 12px;
  min-width: 320px;
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 10000;
  animation: slideIn 0.3s ease;
}

.glass-toast-success {
  border-left: 4px solid #22c55e;
}

.glass-toast-error {
  border-left: 4px solid #ef4444;
}

.glass-toast-warning {
  border-left: 4px solid #f59e0b;
}

.glass-toast-info {
  border-left: 4px solid #3b82f6;
}

.toast-icon {
  font-size: 20px;
  flex-shrink: 0;
}

.toast-content {
  flex: 1;
}

.toast-title {
  color: white;
  font-weight: 600;
  margin-bottom: 2px;
}

.toast-message {
  color: rgba(255, 255, 255, 0.8);
  font-size: 14px;
}

.toast-close {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 20px;
  cursor: pointer;
  padding: 0;
  width: 24px;
  height: 24px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s ease;
}

.toast-close:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

@keyframes slideIn {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}
```

## 📊 Модальные окна

### Базовое модальное окно
```html
<div class="glass-modal-backdrop">
  <div class="glass-modal">
    <div class="modal-header">
      <h3>Заголовок модального окна</h3>
      <button class="modal-close">&times;</button>
    </div>
    <div class="modal-body">
      <p>Содержимое модального окна с прозрачным фоном и эффектом размытия.</p>
    </div>
    <div class="modal-footer">
      <button class="glass-btn glass-btn-outline">Отмена</button>
      <button class="glass-btn glass-btn-primary">Подтвердить</button>
    </div>
  </div>
</div>
```

```css
.glass-modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(3px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
  animation: fadeIn 0.3s ease;
}

.glass-modal {
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 24px;
  max-width: 90vw;
  max-height: 90vh;
  overflow: hidden;
  animation: modalSlideIn 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 24px 24px 0;
}

.modal-header h3 {
  color: white;
  margin: 0;
  font-weight: 600;
}

.modal-close {
  background: none;
  border: none;
  color: rgba(255, 255, 255, 0.6);
  font-size: 24px;
  cursor: pointer;
  padding: 0;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  transition: all 0.3s ease;
}

.modal-close:hover {
  background: rgba(255, 255, 255, 0.1);
  color: white;
}

.modal-body {
  padding: 24px;
  color: rgba(255, 255, 255, 0.9);
  line-height: 1.6;
}

.modal-footer {
  display: flex;
  gap: 12px;
  justify-content: flex-end;
  padding: 0 24px 24px;
}

@keyframes fadeIn {
  from { opacity: 0; }
  to { opacity: 1; }
}

@keyframes modalSlideIn {
  from {
    transform: translateY(-50px);
    opacity: 0;
  }
  to {
    transform: translateY(0);
    opacity: 1;
  }
}
```

---

## 🎮 Интерактивная демонстрация

Посмотрите все компоненты в действии:
**[📱 Интерактивная демо](./examples/interactive-demo.html)**

## 🚀 Следующие шаги

1. **[Паттерны проектирования](./04-design-patterns.md)** - комплексные решения
2. **[Практическая реализация](./05-implementation.md)** - интеграция в проекты
3. **[Best Practices](./06-best-practices.md)** - оптимизация и советы

**⏱️ Время изучения**: ~30 минут  
**🔧 Сложность**: Новичок → Средний