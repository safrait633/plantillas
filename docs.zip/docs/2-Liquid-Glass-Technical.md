# ⚙️ Liquid Glass - Техническое руководство
*API и реализация эффекта*

## 🔬 Физика эффекта

### Рефракция (закон Снеллиуса)
```glsl
float calculateRefraction(vec3 incident, vec3 normal, float eta) {
    float cosI = dot(incident, normal);
    float sinT2 = eta * eta * (1.0 - cosI * cosI);
    if (sinT2 > 1.0) return 1.0; // Полное отражение
    return fresnel(cosI, sqrt(1.0 - sinT2), eta);
}
```

### Хроматическая аберрация
```glsl
vec3 getDispersedColor(vec2 uv, vec2 refraction) {
    float dispersion = 0.01;
    vec2 redUV = uv + refraction * (1.0 + dispersion);
    vec2 greenUV = uv + refraction;
    vec2 blueUV = uv + refraction * (1.0 - dispersion);
    
    return vec3(
        texture(tex, redUV).r,
        texture(tex, greenUV).g,
        texture(tex, blueUV).b
    );
}
```

## 🎛️ Параметры API

### Основные настройки
```typescript
interface LiquidGlassConfig {
    displacementScale: number;    // 0-200
    aberrationIntensity: number;  // 0-20
    frostLevel: number;          // 0-10
    elasticity: number;          // 0-1
    mode: 'standard' | 'polar' | 'prominent' | 'shader';
}
```

## 🖥️ Платформы

### iOS/macOS (SwiftUI)
```swift
Glass()
    .dispersion(.fractional(0.3))
    .refraction(height: 20, hasDepthEffect: true)
    .cornerRadius(16)
```

### Android (Jetpack Compose)
```kotlin
Box(modifier = Modifier
    .backdrop(BackdropEffect.refraction(16.dp))
    .graphicsLayer { renderEffect = liquidGlassShader }
)
```

### Web (React)
```tsx
<LiquidGlass
    mode="shader"
    displacementScale={80}
    aberrationIntensity={5}
>
    Content
</LiquidGlass>
```

### CSS
```css
.liquid-glass {
    backdrop-filter: blur(12px);
    filter: url(#glass-distortion);
    background: rgba(255,255,255,0.25);
}
```

---

*Документ 2/4 серии Liquid Glass*