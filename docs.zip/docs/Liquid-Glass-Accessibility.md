# Liquid Glass - Accessibility: Обзор и принципы

Главный документ серии руководств по обеспечению доступности Liquid Glass эффектов для людей с ограниченными возможностями.

## 📚 Серия документов по Accessibility

### 1. [Liquid-Glass-Accessibility.md](./Liquid-Glass-Accessibility.md) ✅
**Обзор принципов и guidelines**
- WCAG 2.1/2.2 compliance
- Основные принципы accessible design
- User preferences и настройки
- Cross-platform accessibility standards

### 2. [Liquid-Glass-Accessibility-Implementation.md](./Liquid-Glass-Accessibility-Implementation.md)
**Техническая реализация**
- Screen readers поддержка
- High contrast modes
- Reduce motion implementation
- Keyboard navigation
- Platform-specific accessibility APIs

### 3. [Liquid-Glass-Accessibility-Testing.md](./Liquid-Glass-Accessibility-Testing.md)
**Тестирование доступности**
- Automated accessibility testing
- Manual testing procedures
- Screen reader testing
- User testing with disabilities
- Accessibility audit tools

---

## 🎯 Основные принципы accessibility

### WCAG 2.2 Compliance

Liquid Glass эффекты должны соответствовать принципам WCAG:

#### **1. Perceivable (Воспринимаемость)**
```css
/* Обеспечиваем достаточный контраст */
.glass-element {
  /* Минимальный контраст 4.5:1 для normal text */
  background: rgba(255, 255, 255, 0.8);
  color: #000000; /* Контраст 21:1 */
  
  /* Альтернатива для high contrast mode */
  @media (prefers-contrast: high) {
    background: rgba(255, 255, 255, 0.95);
    border: 2px solid #000000;
  }
}
```

#### **2. Operable (Управляемость)**
```css
/* Уважаем предпочтения пользователя по анимациям */
@media (prefers-reduced-motion: reduce) {
  .glass-element {
    transition: none !important;
    animation: none !important;
  }
}

/* Обеспечиваем keyboard focus */
.glass-button:focus {
  outline: 3px solid #0066cc;
  outline-offset: 2px;
}
```

#### **3. Understandable (Понятность)**
```html
<!-- Семантическая разметка -->
<section class="glass-card" role="region" aria-labelledby="card-title">
  <h2 id="card-title">Заголовок карточки</h2>
  <p>Содержимое с glass эффектом</p>
</section>
```

#### **4. Robust (Надежность)**
```html
<!-- Совместимость с assistive technologies -->
<div class="glass-element" 
     aria-live="polite" 
     aria-describedby="glass-description">
  <span id="glass-description" class="sr-only">
    Полупрозрачная область с размытым фоном
  </span>
</div>
```

---

## 🔧 User Preferences Support

### Reduce Motion Preferences

```css
/* Основная поддержка reduce motion */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
  
  /* Убираем анимации появления glass эффектов */
  .glass-element {
    opacity: 1 !important;
    transform: none !important;
  }
}
```

### High Contrast Support

```css
/* Windows High Contrast Mode */
@media (prefers-contrast: high) {
  .glass-element {
    background: Window;
    color: WindowText;
    border: 1px solid WindowText;
    backdrop-filter: none;
  }
}

/* Дополнительная поддержка для старых браузеров */
@media screen and (-ms-high-contrast: active) {
  .glass-element {
    background: window;
    color: windowText;
    border: 1px solid windowText;
    filter: none;
  }
}
```

### Color Scheme Preferences

```css
/* Поддержка темной темы */
@media (prefers-color-scheme: dark) {
  .glass-element {
    background: rgba(0, 0, 0, 0.8);
    color: #ffffff;
    border-color: rgba(255, 255, 255, 0.2);
  }
}

/* Светлая тема */
@media (prefers-color-scheme: light) {
  .glass-element {
    background: rgba(255, 255, 255, 0.8);
    color: #000000;
    border-color: rgba(0, 0, 0, 0.1);
  }
}
```

---

## 📱 Platform-specific Guidelines

### iOS Accessibility

```swift
// SwiftUI accessibility setup
struct AccessibleGlassView: View {
    var body: some View {
        VStack {
            Text("Содержимое")
        }
        .background(.ultraThinMaterial)
        .accessibilityElement(children: .contain)
        .accessibilityLabel("Карточка с полупрозрачным фоном")
        .accessibilityHint("Содержит информацию о продукте")
        .accessibilityAddTraits(.isButton)
        .accessibilityRemoveTraits(.isImage)
    }
}

// Поддержка reduce motion
extension View {
    func respectReduceMotion<T: View>(@ViewBuilder content: @escaping () -> T) -> some View {
        let reduceMotion = UIAccessibility.isReduceMotionEnabled
        
        return Group {
            if reduceMotion {
                self
            } else {
                content()
            }
        }
    }
}
```

### Android Accessibility

```kotlin
class AccessibleGlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    
    init {
        setupAccessibility()
    }
    
    private fun setupAccessibility() {
        // Базовая accessibility информация
        contentDescription = "Полупрозрачная карточка с размытым фоном"
        
        // Поддержка TalkBack
        ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(
                host: View,
                info: AccessibilityNodeInfoCompat
            ) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                
                info.className = "Card"
                info.addAction(
                    AccessibilityNodeInfoCompat.AccessibilityActionCompat(
                        AccessibilityNodeInfoCompat.ACTION_CLICK,
                        "Открыть детали"
                    )
                )
            }
        })
        
        // Проверяем настройки accessibility
        checkAccessibilitySettings()
    }
    
    private fun checkAccessibilitySettings() {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) 
            as AccessibilityManager
        
        // Reduce motion support
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            val animationScale = Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1.0f
            )
            
            if (animationScale == 0.0f) {
                // Отключаем анимации
                clearAnimation()
            }
        }
        
        // High contrast support
        if (accessibilityManager.isHighTextContrastEnabled) {
            applyHighContrastMode()
        }
    }
    
    private fun applyHighContrastMode() {
        // Увеличиваем контраст для glass эффектов
        alpha = 1.0f
        background = ContextCompat.getDrawable(context, R.drawable.high_contrast_background)
    }
}
```

### Web Accessibility

```javascript
// Accessibility manager для web
class WebAccessibilityManager {
  constructor() {
    this.setupMediaQueries();
    this.setupARIA();
    this.setupKeyboardNavigation();
  }
  
  setupMediaQueries() {
    // Reduce motion support
    const reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    reduceMotionQuery.addEventListener('change', (e) => {
      this.handleReduceMotion(e.matches);
    });
    this.handleReduceMotion(reduceMotionQuery.matches);
    
    // High contrast support
    const highContrastQuery = window.matchMedia('(prefers-contrast: high)');
    highContrastQuery.addEventListener('change', (e) => {
      this.handleHighContrast(e.matches);
    });
    this.handleHighContrast(highContrastQuery.matches);
  }
  
  handleReduceMotion(shouldReduce) {
    const rootElement = document.documentElement;
    
    if (shouldReduce) {
      rootElement.style.setProperty('--animation-duration', '0ms');
      rootElement.style.setProperty('--transition-duration', '0ms');
      rootElement.classList.add('reduce-motion');
    } else {
      rootElement.style.removeProperty('--animation-duration');
      rootElement.style.removeProperty('--transition-duration');
      rootElement.classList.remove('reduce-motion');
    }
  }
  
  handleHighContrast(isHighContrast) {
    const rootElement = document.documentElement;
    
    if (isHighContrast) {
      rootElement.classList.add('high-contrast');
      // Отключаем blur эффекты
      rootElement.style.setProperty('--blur-radius', '0px');
    } else {
      rootElement.classList.remove('high-contrast');
      rootElement.style.removeProperty('--blur-radius');
    }
  }
  
  setupARIA() {
    // Автоматическое добавление ARIA атрибутов
    const glassElements = document.querySelectorAll('.glass-element');
    
    glassElements.forEach(element => {
      if (!element.getAttribute('role')) {
        element.setAttribute('role', 'region');
      }
      
      if (!element.getAttribute('aria-label') && !element.getAttribute('aria-labelledby')) {
        element.setAttribute('aria-label', 'Полупрозрачная область');
      }
      
      // Добавляем описание эффекта для screen readers
      if (!element.querySelector('.sr-only')) {
        const description = document.createElement('span');
        description.className = 'sr-only';
        description.textContent = 'Область с эффектом размытого стекла';
        element.appendChild(description);
      }
    });
  }
  
  setupKeyboardNavigation() {
    // Обеспечиваем корректную навигацию с клавиатуры
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Tab') {
        document.body.classList.add('keyboard-navigation');
      }
    });
    
    document.addEventListener('mousedown', () => {
      document.body.classList.remove('keyboard-navigation');
    });
  }
}

// Screen Reader utilities
class ScreenReaderUtils {
  static announceChange(message, priority = 'polite') {
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', priority);
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = message;
    
    document.body.appendChild(announcement);
    
    // Удаляем через небольшую задержку
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  }
  
  static describeGlassEffect(element) {
    const hasBlur = getComputedStyle(element).backdropFilter !== 'none';
    const opacity = parseFloat(getComputedStyle(element).opacity || '1');
    
    let description = 'Полупрозрачная область';
    
    if (hasBlur) {
      description += ' с размытым фоном';
    }
    
    if (opacity < 0.9) {
      description += ', частично прозрачная';
    }
    
    return description;
  }
}

// Инициализация
const accessibilityManager = new WebAccessibilityManager();
```

---

## 🎨 Design Considerations

### Контраст и читаемость

```css
/* Цветовая палитра для accessibility */
:root {
  /* Основные цвета с достаточным контрастом */
  --glass-bg-light: rgba(255, 255, 255, 0.8);
  --glass-bg-dark: rgba(0, 0, 0, 0.8);
  --glass-border-light: rgba(0, 0, 0, 0.1);
  --glass-border-dark: rgba(255, 255, 255, 0.2);
  
  /* High contrast варианты */
  --glass-bg-high-contrast: rgba(255, 255, 255, 0.95);
  --glass-border-high-contrast: #000000;
  
  /* Цвета текста */
  --text-primary-light: #000000; /* 21:1 contrast */
  --text-primary-dark: #ffffff;  /* 21:1 contrast */
  --text-secondary-light: #333333; /* 12.6:1 contrast */
  --text-secondary-dark: #cccccc;  /* 15.8:1 contrast */
}

/* Адаптивные цвета */
.glass-element {
  background: var(--glass-bg-light);
  color: var(--text-primary-light);
  border: 1px solid var(--glass-border-light);
}

@media (prefers-color-scheme: dark) {
  .glass-element {
    background: var(--glass-bg-dark);
    color: var(--text-primary-dark);
    border-color: var(--glass-border-dark);
  }
}

@media (prefers-contrast: high) {
  .glass-element {
    background: var(--glass-bg-high-contrast);
    border: 2px solid var(--glass-border-high-contrast);
    backdrop-filter: none;
  }
}
```

### Focus Management

```css
/* Стили для keyboard focus */
.glass-element:focus,
.glass-button:focus {
  outline: 3px solid #0066cc;
  outline-offset: 2px;
  position: relative;
  z-index: 1001; /* Выше glass эффектов */
}

/* Скрываем outline для mouse users */
.glass-element:focus:not(.keyboard-navigation),
.glass-button:focus:not(.keyboard-navigation) {
  outline: none;
}

/* Focus within для контейнеров */
.glass-container:focus-within {
  border: 2px solid #0066cc;
  border-radius: 4px;
}

/* Visible focus indicator */
.glass-element[data-focus-visible] {
  box-shadow: 
    0 0 0 3px #0066cc,
    0 4px 12px rgba(0, 0, 0, 0.15);
}
```

---

## 🧪 Testing Guidelines

### Accessibility Checklist

```markdown
## Liquid Glass Accessibility Checklist

### ✅ Visual Accessibility
- [ ] Контраст текста минимум 4.5:1 (normal) / 3:1 (large)
- [ ] Поддержка high contrast mode
- [ ] Поддержка темной/светлой темы
- [ ] Readable text на glass фонах
- [ ] Четкие границы элементов

### ✅ Motor Accessibility  
- [ ] Поддержка reduce motion
- [ ] Отключение parallax при необходимости
- [ ] Статичные альтернативы для анимаций
- [ ] Достаточный размер touch targets (44px+)

### ✅ Cognitive Accessibility
- [ ] Понятная семантическая структура
- [ ] Логичный порядок навигации
- [ ] Четкие labels и descriptions
- [ ] Предсказуемое поведение интерфейса

### ✅ Screen Reader Support
- [ ] Корректные ARIA атрибуты
- [ ] Описания для decorative элементов
- [ ] Live regions для динамического контента
- [ ] Skip links для навигации
```

---

## 🔗 Связанные документы

### Серия Accessibility:
- **[Liquid-Glass-Accessibility-Implementation.md]** - Техническая реализация
- **[Liquid-Glass-Accessibility-Testing.md]** - Тестирование доступности

### Связанные темы:
- [Liquid-Glass-Design-Tokens.md] - Дизайн-система с accessibility
- [Liquid-Glass-Platform-Specific.md] - Platform accessibility APIs
- [Liquid-Glass-Performance-GPU.md] - Производительность для assistive tech

---

## 🚀 Быстрый старт

1. **Изучите основы** - WCAG 2.2 принципы и user preferences
2. **Реализуйте поддержку** - reduce motion, high contrast, screen readers  
3. **Тестируйте** - automated tools + manual testing + real users
4. **Итерируйте** - собирайте обратную связь и улучшайте

Accessibility - это не опция, а необходимость для создания по-настоящему инклюзивных Liquid Glass интерфейсов! ♿️✨