# Liquid Glass - Руководство по анимациям и микровзаимодействиям

Полное руководство по созданию плавных анимаций и микровзаимодействий в стиле Liquid Glass для всех платформ.

## Содержание

1. [Принципы анимации Liquid Glass](#принципы-анимации-liquid-glass)
2. [Временные параметры](#временные-параметры)
3. [CSS Анимации](#css-анимации)
4. [Swift/SwiftUI Анимации](#swiftswiftui-анимации)
5. [React/JavaScript Анимации](#reactjavascript-анимации)
6. [Android Jetpack Compose](#android-jetpack-compose)
7. [Flutter Анимации](#flutter-анимации)
8. [Vue.js Анимации](#vuejs-анимации)
9. [Angular Анимации](#angular-анимации)
10. [React Native Анимации](#react-native-анимации)
11. [Продвинутые техники](#продвинутые-техники)
12. [Производительность анимаций](#производительность-анимаций)

---

## Принципы анимации Liquid Glass

### Основные принципы

1. **Физическая правдоподобность** - анимации должны следовать законам физики
2. **Плавность и непрерывность** - избегать резких скачков
3. **Контекстуальность** - анимация должна соответствовать действию
4. **Жидкостность** - имитация движения жидкости и преломления света
5. **Респонсивность** - быстрый отклик на пользовательские действия

### Кривые анимации (Easing Functions)

```css
/* Liquid Glass характерные кривые */
:root {
  --ease-liquid: cubic-bezier(0.23, 1, 0.32, 1);
  --ease-glass: cubic-bezier(0.25, 0.46, 0.45, 0.94);
  --ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
  --ease-smooth: cubic-bezier(0.4, 0.0, 0.2, 1);
}
```

---

## Временные параметры

### Стандартные длительности

```css
:root {
  /* Микровзаимодействия */
  --duration-instant: 100ms;
  --duration-quick: 200ms;
  --duration-normal: 300ms;
  --duration-slow: 500ms;
  --duration-slower: 700ms;
  
  /* Специальные эффекты */
  --duration-morph: 800ms;
  --duration-shimmer: 1500ms;
  --duration-pulse: 2000ms;
}
```

### Задержки (Delays)

```css
:root {
  --delay-stagger-1: 50ms;
  --delay-stagger-2: 100ms;
  --delay-stagger-3: 150ms;
  --delay-cascade: 200ms;
}
```

---

## CSS Анимации

### Базовые hover эффекты

```css
.glass-hover {
  transition: all var(--duration-normal) var(--ease-liquid);
}

.glass-hover:hover {
  transform: translateY(-4px) scale(1.02);
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
  backdrop-filter: blur(16px);
}
```

### Анимация появления (Fade In + Scale)

```css
@keyframes glassAppear {
  0% {
    opacity: 0;
    transform: scale(0.8) translateY(20px);
    backdrop-filter: blur(0px);
  }
  50% {
    backdrop-filter: blur(8px);
  }
  100% {
    opacity: 1;
    transform: scale(1) translateY(0);
    backdrop-filter: blur(12px);
  }
}

.glass-appear {
  animation: glassAppear var(--duration-slow) var(--ease-liquid) forwards;
}
```

### Волновой эффект (Ripple)

```css
@keyframes glassRipple {
  0% {
    transform: scale(0);
    opacity: 1;
  }
  100% {
    transform: scale(4);
    opacity: 0;
  }
}

.glass-ripple {
  position: relative;
  overflow: hidden;
}

.glass-ripple::after {
  content: '';
  position: absolute;
  border-radius: 50%;
  background: rgba(255, 255, 255, 0.3);
  transform: scale(0);
  animation: glassRipple 600ms var(--ease-smooth);
  pointer-events: none;
}
```

### Мерцающий эффект (Shimmer)

```css
@keyframes glassShimmer {
  0% {
    background-position: -200px 0;
  }
  100% {
    background-position: calc(200px + 100%) 0;
  }
}

.glass-shimmer {
  position: relative;
  overflow: hidden;
}

.glass-shimmer::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: linear-gradient(
    90deg,
    transparent,
    rgba(255, 255, 255, 0.2),
    transparent
  );
  animation: glassShimmer var(--duration-shimmer) ease-in-out infinite;
}
```

### Жидкая морфинг анимация

```css
@keyframes glassMorph {
  0%, 100% {
    border-radius: 12px;
    transform: scale(1);
  }
  25% {
    border-radius: 24px 12px 24px 12px;
    transform: scale(1.02);
  }
  50% {
    border-radius: 12px 24px 12px 24px;
    transform: scale(0.98);
  }
  75% {
    border-radius: 24px 12px 24px 12px;
    transform: scale(1.01);
  }
}

.glass-morph {
  animation: glassMorph var(--duration-morph) var(--ease-liquid) infinite;
}
```

### Пульсация с blur эффектом

```css
@keyframes glassPulse {
  0%, 100% {
    backdrop-filter: blur(10px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  }
  50% {
    backdrop-filter: blur(16px);
    box-shadow: 0 16px 48px rgba(0, 0, 0, 0.2);
  }
}

.glass-pulse {
  animation: glassPulse var(--duration-pulse) var(--ease-smooth) infinite;
}
```

### Каскадная анимация появления

```css
.glass-cascade-item {
  opacity: 0;
  transform: translateY(30px);
  animation: glassAppear var(--duration-normal) var(--ease-liquid) forwards;
}

.glass-cascade-item:nth-child(1) { animation-delay: calc(var(--delay-stagger-1) * 1); }
.glass-cascade-item:nth-child(2) { animation-delay: calc(var(--delay-stagger-1) * 2); }
.glass-cascade-item:nth-child(3) { animation-delay: calc(var(--delay-stagger-1) * 3); }
.glass-cascade-item:nth-child(4) { animation-delay: calc(var(--delay-stagger-1) * 4); }
.glass-cascade-item:nth-child(5) { animation-delay: calc(var(--delay-stagger-1) * 5); }
```

---

## Swift/SwiftUI Анимации

### Базовая spring анимация

```swift
struct AnimatedGlassCard: View {
    @State private var isPressed = false
    @State private var isVisible = false
    
    var body: some View {
        VStack {
            Text("Liquid Glass Card")
                .foregroundColor(.white)
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .opacity(isVisible ? 1 : 0)
        .offset(y: isVisible ? 0 : 20)
        .animation(.spring(response: 0.6, dampingFraction: 0.8, blendDuration: 0), value: isPressed)
        .animation(.spring(response: 0.8, dampingFraction: 0.7, blendDuration: 0), value: isVisible)
        .onTapGesture {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.6)) {
                isPressed.toggle()
            }
        }
        .onAppear {
            withAnimation(.spring(response: 0.8, dampingFraction: 0.7)) {
                isVisible = true
            }
        }
    }
}
```

### Анимация с кастомными кривыми

```swift
struct LiquidGlassButton: View {
    @State private var isHovered = false
    @State private var rippleScale: CGFloat = 0
    @State private var rippleOpacity: Double = 1
    
    var body: some View {
        Button("Liquid Button") {
            triggerRipple()
        }
        .padding(.horizontal, 24)
        .padding(.vertical, 12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 8))
        .scaleEffect(isHovered ? 1.05 : 1.0)
        .shadow(color: .black.opacity(0.1), radius: isHovered ? 20 : 8, x: 0, y: isHovered ? 8 : 4)
        .overlay(
            Circle()
                .fill(.white.opacity(0.3))
                .scaleEffect(rippleScale)
                .opacity(rippleOpacity)
                .allowsHitTesting(false)
        )
        .animation(.interpolatingSpring(stiffness: 300, damping: 15), value: isHovered)
        .onHover { hovering in
            isHovered = hovering
        }
    }
    
    private func triggerRipple() {
        withAnimation(.easeOut(duration: 0.6)) {
            rippleScale = 2.0
            rippleOpacity = 0
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
            rippleScale = 0
            rippleOpacity = 1
        }
    }
}
```

### Морфинг анимация

```swift
struct MorphingGlassShape: View {
    @State private var morphProgress: CGFloat = 0
    
    var body: some View {
        RoundedRectangle(cornerRadius: morphedCornerRadius)
            .fill(.ultraThinMaterial)
            .frame(width: 200, height: 100)
            .scaleEffect(morphedScale)
            .animation(.easeInOut(duration: 2).repeatForever(autoreverses: true), value: morphProgress)
            .onAppear {
                morphProgress = 1
            }
    }
    
    private var morphedCornerRadius: CGFloat {
        let baseRadius: CGFloat = 12
        let maxRadius: CGFloat = 50
        return baseRadius + (maxRadius - baseRadius) * morphProgress
    }
    
    private var morphedScale: CGFloat {
        1.0 + 0.1 * sin(morphProgress * .pi)
    }
}
```

### Каскадная анимация списка

```swift
struct CascadingGlassList: View {
    @State private var appearedItems: Set<Int> = []
    let items = Array(1...10)
    
    var body: some View {
        VStack(spacing: 12) {
            ForEach(items.indices, id: \.self) { index in
                GlassListItem(text: "Item \(items[index])")
                    .opacity(appearedItems.contains(index) ? 1 : 0)
                    .offset(y: appearedItems.contains(index) ? 0 : 30)
                    .animation(
                        .spring(response: 0.6, dampingFraction: 0.8)
                        .delay(Double(index) * 0.1),
                        value: appearedItems
                    )
            }
        }
        .onAppear {
            for index in items.indices {
                DispatchQueue.main.asyncAfter(deadline: .now() + Double(index) * 0.1) {
                    appearedItems.insert(index)
                }
            }
        }
    }
}

struct GlassListItem: View {
    let text: String
    
    var body: some View {
        Text(text)
            .foregroundColor(.white)
            .padding()
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
    }
}
```

---

## React/JavaScript Анимации

### Framer Motion компоненты

```jsx
import { motion, useSpring, useAnimation } from 'framer-motion';

const GlassCard = ({ children }) => {
  const controls = useAnimation();
  
  const cardVariants = {
    hidden: {
      opacity: 0,
      scale: 0.8,
      y: 20,
      filter: 'blur(0px)'
    },
    visible: {
      opacity: 1,
      scale: 1,
      y: 0,
      filter: 'blur(10px)',
      transition: {
        duration: 0.6,
        ease: [0.23, 1, 0.32, 1]
      }
    },
    hover: {
      scale: 1.02,
      y: -4,
      filter: 'blur(16px)',
      transition: {
        duration: 0.3,
        ease: [0.25, 0.46, 0.45, 0.94]
      }
    }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="hidden"
      animate="visible"
      whileHover="hover"
      className="glass-card"
    >
      {children}
    </motion.div>
  );
};
```

### Hook для анимации появления

```jsx
import { useEffect, useState } from 'react';
import { useSpring, animated } from '@react-spring/web';

export const useGlassAppear = (delay = 0) => {
  const [isVisible, setIsVisible] = useState(false);
  
  const styles = useSpring({
    opacity: isVisible ? 1 : 0,
    transform: `translateY(${isVisible ? 0 : 30}px) scale(${isVisible ? 1 : 0.8})`,
    filter: `blur(${isVisible ? 12 : 0}px)`,
    config: {
      tension: 300,
      friction: 20
    },
    delay
  });
  
  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);
  
  return styles;
};

// Использование
const AnimatedGlassComponent = () => {
  const styles = useGlassAppear(200);
  
  return (
    <animated.div style={styles} className="glass-element">
      Content
    </animated.div>
  );
};
```

### Ripple эффект

```jsx
import { useState, useCallback } from 'react';
import { animated, useSpring } from '@react-spring/web';

export const useRipple = () => {
  const [ripples, setRipples] = useState([]);
  
  const createRipple = useCallback((event) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    const newRipple = {
      id: Date.now(),
      x,
      y
    };
    
    setRipples(prev => [...prev, newRipple]);
    
    setTimeout(() => {
      setRipples(prev => prev.filter(ripple => ripple.id !== newRipple.id));
    }, 600);
  }, []);
  
  return { ripples, createRipple };
};

const RippleComponent = ({ children, onClick }) => {
  const { ripples, createRipple } = useRipple();
  
  const handleClick = (e) => {
    createRipple(e);
    onClick?.(e);
  };
  
  return (
    <div className="glass-ripple-container" onClick={handleClick}>
      {children}
      {ripples.map(ripple => (
        <RippleEffect key={ripple.id} x={ripple.x} y={ripple.y} />
      ))}
    </div>
  );
};

const RippleEffect = ({ x, y }) => {
  const styles = useSpring({
    from: { scale: 0, opacity: 1 },
    to: { scale: 4, opacity: 0 },
    config: { duration: 600 }
  });
  
  return (
    <animated.div
      style={{
        ...styles,
        position: 'absolute',
        left: x,
        top: y,
        width: 20,
        height: 20,
        borderRadius: '50%',
        background: 'rgba(255, 255, 255, 0.3)',
        transform: styles.scale.to(s => `translate(-50%, -50%) scale(${s})`)
      }}
    />
  );
};
```

### Морфинг с GSAP

```jsx
import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';

const MorphingGlassCard = ({ children }) => {
  const cardRef = useRef(null);
  
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    
    const tl = gsap.timeline({ repeat: -1, yoyo: true });
    
    tl.to(card, {
      borderRadius: '50px 20px 50px 20px',
      scale: 1.02,
      duration: 2,
      ease: 'power2.inOut'
    })
    .to(card, {
      borderRadius: '20px 50px 20px 50px',
      scale: 0.98,
      duration: 2,
      ease: 'power2.inOut'
    });
    
    return () => tl.kill();
  }, []);
  
  return (
    <div ref={cardRef} className="glass-morph-card">
      {children}
    </div>
  );
};
```

---

## Android Jetpack Compose

### Базовая анимация

```kotlin
@Composable
fun AnimatedGlassCard(
    content: @Composable () -> Unit
) {
    var isVisible by remember { mutableStateOf(false) }
    var isPressed by remember { mutableStateOf(false) }
    
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        )
    )
    
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioLowBouncy,
            stiffness = Spring.StiffnessLow
        )
    )
    
    val offsetY by animateDpAsState(
        targetValue = if (isVisible) 0.dp else 30.dp,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMedium
        )
    )
    
    LaunchedEffect(Unit) {
        isVisible = true
    }
    
    Card(
        modifier = Modifier
            .scale(scale)
            .alpha(alpha)
            .offset(y = offsetY)
            .clickable { isPressed = !isPressed },
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.1f)
        ),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
        Box(modifier = Modifier.padding(20.dp)) {
            content()
        }
    }
}
```

### Каскадная анимация списка

```kotlin
@Composable
fun CascadingGlassList(
    items: List<String>
) {
    LazyColumn {
        itemsIndexed(items) { index, item ->
            AnimatedGlassListItem(
                text = item,
                delay = index * 100
            )
        }
    }
}

@Composable
fun AnimatedGlassListItem(
    text: String,
    delay: Int
) {
    var isVisible by remember { mutableStateOf(false) }
    
    val alpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(
            durationMillis = 600,
            delayMillis = delay,
            easing = FastOutSlowInEasing
        )
    )
    
    val slideDistance = 50.dp
    val offsetY by animateDpAsState(
        targetValue = if (isVisible) 0.dp else slideDistance,
        animationSpec = tween(
            durationMillis = 600,
            delayMillis = delay,
            easing = FastOutSlowInEasing
        )
    )
    
    LaunchedEffect(Unit) {
        isVisible = true
    }
    
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .alpha(alpha)
            .offset(y = offsetY),
        colors = CardDefaults.cardColors(
            containerColor = Color.White.copy(alpha = 0.15f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(16.dp),
            color = Color.White
        )
    }
}
```

### Морфинг анимация

```kotlin
@Composable
fun MorphingGlassShape() {
    val infiniteTransition = rememberInfiniteTransition()
    
    val morphProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        )
    )
    
    val cornerRadius = (12 + 38 * morphProgress).dp
    val scaleX = 1f + 0.1f * sin(morphProgress * PI.toFloat())
    val scaleY = 1f + 0.05f * cos(morphProgress * PI.toFloat())
    
    Box(
        modifier = Modifier
            .size(200.dp, 100.dp)
            .scale(scaleX, scaleY)
            .background(
                color = Color.White.copy(alpha = 0.2f),
                shape = RoundedCornerShape(cornerRadius)
            )
    )
}
```

---

## Flutter Анимации

### Базовая анимация с AnimationController

```dart
class AnimatedGlassCard extends StatefulWidget {
  final Widget child;
  
  const AnimatedGlassCard({Key? key, required this.child}) : super(key: key);

  @override
  State<AnimatedGlassCard> createState() => _AnimatedGlassCardState();
}

class _AnimatedGlassCardState extends State<AnimatedGlassCard>
    with TickerProviderStateMixin {
  late AnimationController _appearController;
  late AnimationController _hoverController;
  
  late Animation<double> _scaleAnimation;
  late Animation<double> _opacityAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _blurAnimation;
  
  @override
  void initState() {
    super.initState();
    
    _appearController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _hoverController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    
    _scaleAnimation = Tween<double>(begin: 0.8, end: 1.0).animate(
      CurvedAnimation(parent: _appearController, curve: Curves.elasticOut),
    );
    
    _opacityAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _appearController, curve: Curves.easeOut),
    );
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _appearController, curve: Curves.easeOut));
    
    _blurAnimation = Tween<double>(begin: 0.0, end: 10.0).animate(
      CurvedAnimation(parent: _appearController, curve: Curves.easeInOut),
    );
    
    _appearController.forward();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: Listenable.merge([_appearController, _hoverController]),
      builder: (context, child) {
        return Transform.scale(
          scale: _scaleAnimation.value * (1.0 + _hoverController.value * 0.02),
          child: Transform.translate(
            offset: Offset(0, -_hoverController.value * 4),
            child: SlideTransition(
              position: _slideAnimation,
              child: FadeTransition(
                opacity: _opacityAnimation,
                child: GestureDetector(
                  onTapDown: (_) => _hoverController.forward(),
                  onTapUp: (_) => _hoverController.reverse(),
                  onTapCancel: () => _hoverController.reverse(),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: Colors.white.withOpacity(0.2),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          blurRadius: 8 + _hoverController.value * 12,
                          offset: Offset(0, 4 + _hoverController.value * 4),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                          sigmaX: _blurAnimation.value,
                          sigmaY: _blurAnimation.value,
                        ),
                        child: widget.child,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  void dispose() {
    _appearController.dispose();
    _hoverController.dispose();
    super.dispose();
  }
}
```

### Каскадная анимация

```dart
class CascadingGlassList extends StatefulWidget {
  final List<String> items;
  
  const CascadingGlassList({Key? key, required this.items}) : super(key: key);

  @override
  State<CascadingGlassList> createState() => _CascadingGlassListState();
}

class _CascadingGlassListState extends State<CascadingGlassList>
    with TickerProviderStateMixin {
  late List<AnimationController> _controllers;
  late List<Animation<double>> _animations;
  
  @override
  void initState() {
    super.initState();
    
    _controllers = List.generate(
      widget.items.length,
      (index) => AnimationController(
        duration: const Duration(milliseconds: 600),
        vsync: this,
      ),
    );
    
    _animations = _controllers.map((controller) {
      return Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: controller, curve: Curves.elasticOut),
      );
    }).toList();
    
    _startCascade();
  }
  
  void _startCascade() {
    for (int i = 0; i < _controllers.length; i++) {
      Timer(Duration(milliseconds: i * 100), () {
        if (mounted) {
          _controllers[i].forward();
        }
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: widget.items.length,
      itemBuilder: (context, index) {
        return AnimatedBuilder(
          animation: _animations[index],
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, 50 * (1 - _animations[index].value)),
              child: Opacity(
                opacity: _animations[index].value,
                child: Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 8,
                  ),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                      color: Colors.white.withOpacity(0.2),
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                      child: Text(
                        widget.items[index],
                        style: const TextStyle(color: Colors.white),
                      ),
                    ),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  @override
  void dispose() {
    for (final controller in _controllers) {
      controller.dispose();
    }
    super.dispose();
  }
}
```

---

## Vue.js Анимации

### Transition компонент

```vue
<template>
  <transition
    name="glass"
    @enter="onEnter"
    @leave="onLeave"
    :css="false"
  >
    <div v-show="visible" class="glass-card">
      <slot />
    </div>
  </transition>
</template>

<script setup>
import { ref } from 'vue'
import { gsap } from 'gsap'

const visible = ref(false)

const onEnter = (el, done) => {
  gsap.set(el, {
    scale: 0.8,
    y: 30,
    opacity: 0,
    filter: 'blur(0px)'
  })
  
  gsap.to(el, {
    scale: 1,
    y: 0,
    opacity: 1,
    filter: 'blur(10px)',
    duration: 0.8,
    ease: 'elastic.out(1, 0.75)',
    onComplete: done
  })
}

const onLeave = (el, done) => {
  gsap.to(el, {
    scale: 0.8,
    y: -30,
    opacity: 0,
    filter: 'blur(0px)',
    duration: 0.4,
    ease: 'power2.in',
    onComplete: done
  })
}

defineExpose({ visible })
</script>

<style scoped>
.glass-card {
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  padding: 20px;
}
</style>
```

### Каскадная анимация с Vue

```vue
<template>
  <div class="cascade-container">
    <transition-group
      name="cascade"
      tag="div"
      @enter="onEnter"
      :css="false"
    >
      <div
        v-for="(item, index) in items"
        :key="item.id"
        :data-index="index"
        class="cascade-item"
      >
        {{ item.text }}
      </div>
    </transition-group>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { gsap } from 'gsap'

const items = ref([
  { id: 1, text: 'Item 1' },
  { id: 2, text: 'Item 2' },
  { id: 3, text: 'Item 3' },
  { id: 4, text: 'Item 4' },
  { id: 5, text: 'Item 5' }
])

const onEnter = (el, done) => {
  const index = el.dataset.index
  
  gsap.set(el, {
    y: 50,
    opacity: 0,
    scale: 0.8,
    filter: 'blur(0px)'
  })
  
  gsap.to(el, {
    y: 0,
    opacity: 1,
    scale: 1,
    filter: 'blur(8px)',
    duration: 0.6,
    delay: index * 0.1,
    ease: 'power2.out',
    onComplete: done
  })
}
</script>

<style scoped>
.cascade-item {
  backdrop-filter: blur(8px);
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 12px;
  padding: 16px;
  margin: 8px 0;
  color: white;
}
</style>
```

---

## Angular Анимации

### Сервис анимаций

```typescript
import { Injectable } from '@angular/core';
import { 
  trigger, 
  state, 
  style, 
  transition, 
  animate, 
  keyframes,
  query,
  stagger
} from '@angular/animations';

@Injectable({
  providedIn: 'root'
})
export class LiquidGlassAnimations {
  
  static glassFadeIn = trigger('glassFadeIn', [
    transition(':enter', [
      style({
        opacity: 0,
        transform: 'translateY(30px) scale(0.8)',
        filter: 'blur(0px)'
      }),
      animate('800ms cubic-bezier(0.23, 1, 0.32, 1)', 
        style({
          opacity: 1,
          transform: 'translateY(0) scale(1)',
          filter: 'blur(10px)'
        })
      )
    ]),
    transition(':leave', [
      animate('400ms cubic-bezier(0.4, 0.0, 0.2, 1)',
        style({
          opacity: 0,
          transform: 'translateY(-30px) scale(0.8)',
          filter: 'blur(0px)'
        })
      )
    ])
  ]);

  static glassCascade = trigger('glassCascade', [
    transition('* => *', [
      query(':enter', [
        style({
          opacity: 0,
          transform: 'translateY(50px)',
          filter: 'blur(0px)'
        }),
        stagger(100, [
          animate('600ms cubic-bezier(0.23, 1, 0.32, 1)',
            style({
              opacity: 1,
              transform: 'translateY(0)',
              filter: 'blur(8px)'
            })
          )
        ])
      ], { optional: true })
    ])
  ]);

  static glassMorph = trigger('glassMorph', [
    state('normal', style({
      borderRadius: '12px',
      transform: 'scale(1)'
    })),
    state('morphed', style({
      borderRadius: '50px 20px 50px 20px',
      transform: 'scale(1.02)'
    })),
    transition('normal <=> morphed', [
      animate('2s cubic-bezier(0.4, 0.0, 0.2, 1)')
    ])
  ]);

  static glassHover = trigger('glassHover', [
    state('normal', style({
      transform: 'translateY(0) scale(1)',
      filter: 'blur(10px)',
      boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)'
    })),
    state('hovered', style({
      transform: 'translateY(-4px) scale(1.02)',
      filter: 'blur(16px)',
      boxShadow: '0 16px 48px rgba(0, 0, 0, 0.15)'
    })),
    transition('normal <=> hovered', [
      animate('300ms cubic-bezier(0.25, 0.46, 0.45, 0.94)')
    ])
  ]);
}
```

### Компонент с анимациями

```typescript
import { Component, Input } from '@angular/core';
import { LiquidGlassAnimations } from './liquid-glass-animations.service';

@Component({
  selector: 'app-animated-glass-card',
  template: `
    <div 
      class="glass-card"
      [@glassFadeIn]
      [@glassHover]="hoverState"
      (mouseenter)="hoverState = 'hovered'"
      (mouseleave)="hoverState = 'normal'"
    >
      <ng-content></ng-content>
    </div>
  `,
  styleUrls: ['./animated-glass-card.component.scss'],
  animations: [
    LiquidGlassAnimations.glassFadeIn,
    LiquidGlassAnimations.glassHover
  ]
})
export class AnimatedGlassCardComponent {
  hoverState = 'normal';
}
```

### Директива для каскадной анимации

```typescript
import { 
  Directive, 
  ElementRef, 
  AfterViewInit, 
  QueryList, 
  ViewChildren 
} from '@angular/core';
import { AnimationBuilder, style, animate } from '@angular/animations';

@Directive({
  selector: '[appGlassCascade]'
})
export class GlassCascadeDirective implements AfterViewInit {
  
  constructor(
    private el: ElementRef,
    private animationBuilder: AnimationBuilder
  ) {}

  ngAfterViewInit() {
    const children = Array.from(this.el.nativeElement.children);
    
    children.forEach((child: HTMLElement, index) => {
      const animation = this.animationBuilder.build([
        style({
          opacity: 0,
          transform: 'translateY(50px)',
          filter: 'blur(0px)'
        }),
        animate(`${600 + index * 100}ms cubic-bezier(0.23, 1, 0.32, 1)`,
          style({
            opacity: 1,
            transform: 'translateY(0)',
            filter: 'blur(8px)'
          })
        )
      ]);
      
      const player = animation.create(child);
      player.play();
    });
  }
}
```

---

## React Native Анимации

### Animated API

```jsx
import React, { useEffect, useRef } from 'react';
import {
  Animated,
  PanResponder,
  Dimensions,
} from 'react-native';

const AnimatedGlassCard = ({ children, style }) => {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        tension: 100,
        friction: 8,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View
      style={[
        style,
        {
          opacity: fadeAnim,
          transform: [
            { scale: scaleAnim },
            { translateY: slideAnim },
          ],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
};
```

### Каскадная анимация

```jsx
import React, { useEffect, useRef } from 'react';
import { Animated, View } from 'react-native';

const CascadingGlassList = ({ items }) => {
  const animatedValues = useRef(
    items.map(() => ({
      opacity: new Animated.Value(0),
      translateY: new Animated.Value(50),
    }))
  ).current;

  useEffect(() => {
    const animations = animatedValues.map((anim, index) =>
      Animated.parallel([
        Animated.timing(anim.opacity, {
          toValue: 1,
          duration: 600,
          delay: index * 100,
          useNativeDriver: true,
        }),
        Animated.timing(anim.translateY, {
          toValue: 0,
          duration: 600,
          delay: index * 100,
          useNativeDriver: true,
        }),
      ])
    );

    Animated.parallel(animations).start();
  }, []);

  return (
    <View>
      {items.map((item, index) => (
        <Animated.View
          key={item.id}
          style={{
            opacity: animatedValues[index].opacity,
            transform: [
              { translateY: animatedValues[index].translateY },
            ],
            marginVertical: 8,
            marginHorizontal: 16,
          }}
        >
          <GlassCard>
            <Text style={{ color: 'white' }}>{item.text}</Text>
          </GlassCard>
        </Animated.View>
      ))}
    </View>
  );
};
```

### Интерактивная анимация с жестами

```jsx
import React, { useRef } from 'react';
import {
  Animated,
  PanResponder,
  Dimensions,
} from 'react-native';

const InteractiveGlassCard = ({ children }) => {
  const pan = useRef(new Animated.ValueXY()).current;
  const scale = useRef(new Animated.Value(1)).current;
  const rotation = useRef(new Animated.Value(0)).current;

  const panResponder = PanResponder.create({
    onMoveShouldSetPanResponder: () => true,
    onPanResponderGrant: () => {
      Animated.spring(scale, {
        toValue: 1.05,
        useNativeDriver: true,
      }).start();
    },
    onPanResponderMove: (evt, gestureState) => {
      pan.setValue({ x: gestureState.dx, y: gestureState.dy });
      
      const rotationValue = gestureState.dx / Dimensions.get('window').width;
      rotation.setValue(rotationValue * 0.1);
    },
    onPanResponderRelease: () => {
      Animated.parallel([
        Animated.spring(pan, {
          toValue: { x: 0, y: 0 },
          useNativeDriver: true,
        }),
        Animated.spring(scale, {
          toValue: 1,
          useNativeDriver: true,
        }),
        Animated.spring(rotation, {
          toValue: 0,
          useNativeDriver: true,
        }),
      ]).start();
    },
  });

  return (
    <Animated.View
      style={{
        transform: [
          { translateX: pan.x },
          { translateY: pan.y },
          { scale: scale },
          { 
            rotate: rotation.interpolate({
              inputRange: [-1, 1],
              outputRange: ['-10deg', '10deg'],
            }),
          },
        ],
      }}
      {...panResponder.panHandlers}
    >
      {children}
    </Animated.View>
  );
};
```

---

## Продвинутые техники

### Шейдерные анимации (WebGL)

```glsl
// Vertex Shader
attribute vec4 position;
attribute vec2 texCoord;
uniform mat4 matrix;
varying vec2 vTexCoord;

void main() {
  gl_Position = matrix * position;
  vTexCoord = texCoord;
}

// Fragment Shader
precision mediump float;
uniform sampler2D texture;
uniform float time;
uniform vec2 resolution;
varying vec2 vTexCoord;

// Жидкое искажение
vec2 liquidDistortion(vec2 uv, float time) {
  vec2 waves = vec2(
    sin(uv.y * 10.0 + time * 2.0) * 0.02,
    cos(uv.x * 8.0 + time * 1.5) * 0.02
  );
  return uv + waves;
}

// Хроматическая аберрация
vec3 chromaticAberration(sampler2D tex, vec2 uv, float strength) {
  vec2 offset = vec2(strength, 0.0);
  float r = texture2D(tex, uv + offset).r;
  float g = texture2D(tex, uv).g;
  float b = texture2D(tex, uv - offset).b;
  return vec3(r, g, b);
}

void main() {
  vec2 uv = vTexCoord;
  uv = liquidDistortion(uv, time);
  
  vec3 color = chromaticAberration(texture, uv, 0.005);
  
  // Стеклянный эффект
  float alpha = 0.7 + 0.3 * sin(time + uv.x * 5.0);
  
  gl_FragColor = vec4(color, alpha);
}
```

### Particle System анимация

```javascript
class LiquidGlassParticles {
  constructor(canvas, particleCount = 50) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.particles = [];
    this.particleCount = particleCount;
    
    this.init();
    this.animate();
  }
  
  init() {
    for (let i = 0; i < this.particleCount; i++) {
      this.particles.push({
        x: Math.random() * this.canvas.width,
        y: Math.random() * this.canvas.height,
        vx: (Math.random() - 0.5) * 2,
        vy: (Math.random() - 0.5) * 2,
        size: Math.random() * 3 + 1,
        opacity: Math.random() * 0.5 + 0.1,
        life: Math.random() * 100,
      });
    }
  }
  
  animate() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    
    this.particles.forEach(particle => {
      // Обновляем позицию
      particle.x += particle.vx;
      particle.y += particle.vy;
      
      // Жидкое движение
      particle.vx += Math.sin(particle.life * 0.01) * 0.1;
      particle.vy += Math.cos(particle.life * 0.01) * 0.1;
      
      // Границы
      if (particle.x < 0 || particle.x > this.canvas.width) particle.vx *= -1;
      if (particle.y < 0 || particle.y > this.canvas.height) particle.vy *= -1;
      
      // Рендеринг с стеклянным эффектом
      this.ctx.save();
      this.ctx.globalAlpha = particle.opacity;
      this.ctx.filter = 'blur(2px)';
      this.ctx.fillStyle = `rgba(255, 255, 255, ${particle.opacity})`;
      this.ctx.beginPath();
      this.ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
      this.ctx.fill();
      this.ctx.restore();
      
      particle.life++;
    });
    
    requestAnimationFrame(() => this.animate());
  }
}
```

---

## Производительность анимаций

### Оптимизация CSS

```css
/* Используйте transform и opacity для GPU ускорения */
.glass-optimized {
  will-change: transform, opacity;
  transform: translateZ(0); /* Принудительное включение GPU слоя */
}

/* Избегайте анимации layout-свойств */
.glass-bad {
  /* ❌ Плохо - вызывает reflow */
  animation: badAnimation 1s ease;
}

@keyframes badAnimation {
  to { width: 200px; height: 100px; }
}

.glass-good {
  /* ✅ Хорошо - только compositor */
  animation: goodAnimation 1s ease;
}

@keyframes goodAnimation {
  to { transform: scale(1.5); opacity: 0.8; }
}

/* Оптимизация backdrop-filter */
.glass-backdrop-optimized {
  /* Ограничиваем область применения blur */
  backdrop-filter: blur(10px);
  isolation: isolate; /* Создаем новый stacking context */
}
```

### Мониторинг производительности

```javascript
// Мониторинг FPS
class PerformanceMonitor {
  constructor() {
    this.frames = 0;
    this.startTime = performance.now();
    this.lastFrameTime = this.startTime;
  }
  
  update() {
    this.frames++;
    const currentTime = performance.now();
    
    if (currentTime - this.startTime >= 1000) {
      const fps = this.frames;
      console.log(`FPS: ${fps}`);
      
      // Предупреждение о низкой производительности
      if (fps < 30) {
        console.warn('Низкая производительность анимаций');
        this.reduceQuality();
      }
      
      this.frames = 0;
      this.startTime = currentTime;
    }
    
    this.lastFrameTime = currentTime;
    requestAnimationFrame(() => this.update());
  }
  
  reduceQuality() {
    // Уменьшаем интенсивность blur
    document.documentElement.style.setProperty('--blur-intensity', '5px');
    // Отключаем сложные анимации
    document.body.classList.add('reduced-motion');
  }
}

const monitor = new PerformanceMonitor();
monitor.update();
```

### Адаптивная производительность

```css
/* Респект к prefers-reduced-motion */
@media (prefers-reduced-motion: reduce) {
  .glass-animated {
    animation: none;
    transition: none;
  }
  
  .glass-blur {
    backdrop-filter: none;
    background: rgba(255, 255, 255, 0.8);
  }
}

/* Адаптация под мощность устройства */
@media (max-resolution: 150dpi) {
  .glass-element {
    backdrop-filter: blur(5px); /* Меньше blur для слабых устройств */
  }
}

@media (min-resolution: 300dpi) {
  .glass-element {
    backdrop-filter: blur(15px); /* Больше blur для мощных устройств */
  }
}
```

---

## Заключение

Анимации в стиле Liquid Glass требуют баланса между визуальной привлекательностью и производительностью. Ключевые принципы:

1. **Используйте аппаратное ускорение** - transform, opacity, filter
2. **Следите за производительностью** - мониторинг FPS, адаптивное качество
3. **Уважайте предпочтения пользователей** - prefers-reduced-motion
4. **Тестируйте на разных устройствах** - от слабых мобильных до мощных десктопов
5. **Создавайте плавные переходы** - физически правдоподобные кривые анимации

Этот документ предоставляет полный набор инструментов для создания профессиональных анимаций в стиле Liquid Glass на любой платформе.