# Liquid Glass - Test Automation Framework

Комплексный фреймворк для автоматизации тестирования Liquid Glass эффектов с поддержкой unit, integration, и E2E тестирования.

## Содержание

1. [Test Architecture](#test-architecture)
2. [Unit Testing Framework](#unit-testing-framework)
3. [Integration Testing](#integration-testing)
4. [E2E Testing Setup](#e2e-testing-setup)
5. [Custom Test Utilities](#custom-test-utilities)
6. [Mocking and Stubbing](#mocking-and-stubbing)

---

## Test Architecture

### Testing Pyramid Structure

```
┌─────────────────────────────────────┐
│           E2E Tests (10%)           │  ← Медленные, дорогие, важные сценарии
├─────────────────────────────────────┤
│       Integration Tests (20%)       │  ← Взаимодействие компонентов
├─────────────────────────────────────┤
│         Unit Tests (70%)            │  ← Быстрые, изолированные, детальные
└─────────────────────────────────────┘
```

### Test Configuration

```javascript
// jest.config.js
module.exports = {
  testEnvironment: 'jsdom',
  setupFilesAfterEnv: ['<rootDir>/tests/setup.js'],
  moduleNameMapping: {
    '^@/(.*)$': '<rootDir>/src/$1',
    '^@tests/(.*)$': '<rootDir>/tests/$1'
  },
  collectCoverageFrom: [
    'src/**/*.{js,ts}',
    '!src/**/*.d.ts',
    '!src/**/*.stories.{js,ts}',
    '!src/**/*.test.{js,ts}'
  ],
  coverageThreshold: {
    global: {
      branches: 80,
      functions: 80,
      lines: 80,
      statements: 80
    }
  },
  testMatch: [
    '<rootDir>/tests/**/*.test.{js,ts}',
    '<rootDir>/src/**/*.test.{js,ts}'
  ],
  transform: {
    '^.+\\.(js|ts)$': 'babel-jest'
  }
};

// tests/setup.js
import 'jest-canvas-mock';
import { configure } from '@testing-library/dom';

// Настройка Testing Library
configure({
  testIdAttribute: 'data-testid'
});

// Mock для WebGL
global.WebGL2RenderingContext = jest.fn();
global.WebGLRenderingContext = jest.fn();

// Mock для ResizeObserver
global.ResizeObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn()
}));

// Mock для IntersectionObserver
global.IntersectionObserver = jest.fn().mockImplementation(() => ({
  observe: jest.fn(),
  unobserve: jest.fn(),
  disconnect: jest.fn()
}));

// Mock для requestAnimationFrame
global.requestAnimationFrame = jest.fn((callback) => {
  return setTimeout(callback, 16);
});

global.cancelAnimationFrame = jest.fn((id) => {
  clearTimeout(id);
});

// Mock для performance API
global.performance = {
  now: jest.fn(() => Date.now()),
  memory: {
    usedJSHeapSize: 1000000,
    totalJSHeapSize: 2000000,
    jsHeapSizeLimit: 4000000
  }
};
```

---

## Unit Testing Framework

### Core Component Tests

```javascript
// tests/unit/LiquidGlass.test.js
import { LiquidGlass } from '@/LiquidGlass';
import { createMockElement, createMockWebGLContext } from '@tests/utils/mocks';

describe('LiquidGlass Core', () => {
  let mockElement;
  let mockGL;
  let liquidGlass;

  beforeEach(() => {
    mockElement = createMockElement();
    mockGL = createMockWebGLContext();
    
    // Mock canvas.getContext
    HTMLCanvasElement.prototype.getContext = jest.fn(() => mockGL);
  });

  afterEach(() => {
    if (liquidGlass) {
      liquidGlass.destroy();
    }
    jest.clearAllMocks();
  });

  describe('Initialization', () => {
    test('should initialize with default options', () => {
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(liquidGlass.options).toMatchObject({
        blur: 10,
        opacity: 0.8,
        quality: 'high'
      });
    });

    test('should merge custom options with defaults', () => {
      const customOptions = {
        blur: 15,
        opacity: 0.9,
        customProperty: 'test'
      };
      
      liquidGlass = new LiquidGlass(mockElement, customOptions);
      
      expect(liquidGlass.options).toMatchObject({
        blur: 15,
        opacity: 0.9,
        quality: 'high',
        customProperty: 'test'
      });
    });

    test('should throw error for invalid element', () => {
      expect(() => {
        new LiquidGlass(null);
      }).toThrow('Element is required');
    });

    test('should initialize WebGL context when available', () => {
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(liquidGlass.hasWebGL).toBe(true);
      expect(mockGL.createProgram).toHaveBeenCalled();
    });

    test('should fallback to CSS when WebGL unavailable', () => {
      HTMLCanvasElement.prototype.getContext = jest.fn(() => null);
      
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(liquidGlass.hasWebGL).toBe(false);
      expect(liquidGlass.fallbackMode).toBe('css');
    });
  });

  describe('Configuration Updates', () => {
    beforeEach(() => {
      liquidGlass = new LiquidGlass(mockElement);
    });

    test('should update blur value', () => {
      liquidGlass.setBlur(20);
      
      expect(liquidGlass.options.blur).toBe(20);
      expect(mockGL.uniform1f).toHaveBeenCalledWith(
        expect.any(Object), // uniform location
        20
      );
    });

    test('should clamp blur value to valid range', () => {
      liquidGlass.setBlur(-5);
      expect(liquidGlass.options.blur).toBe(0);
      
      liquidGlass.setBlur(1000);
      expect(liquidGlass.options.blur).toBe(50); // Максимальное значение
    });

    test('should update opacity value', () => {
      liquidGlass.setOpacity(0.5);
      
      expect(liquidGlass.options.opacity).toBe(0.5);
      expect(mockGL.uniform1f).toHaveBeenCalledWith(
        expect.any(Object),
        0.5
      );
    });

    test('should validate opacity range', () => {
      liquidGlass.setOpacity(-0.5);
      expect(liquidGlass.options.opacity).toBe(0);
      
      liquidGlass.setOpacity(1.5);
      expect(liquidGlass.options.opacity).toBe(1);
    });

    test('should update multiple options at once', () => {
      const newOptions = {
        blur: 25,
        opacity: 0.6,
        quality: 'medium'
      };
      
      liquidGlass.updateOptions(newOptions);
      
      expect(liquidGlass.options).toMatchObject(newOptions);
    });

    test('should emit update event when options change', () => {
      const updateSpy = jest.fn();
      liquidGlass.on('update', updateSpy);
      
      liquidGlass.setBlur(15);
      
      expect(updateSpy).toHaveBeenCalledWith({
        property: 'blur',
        oldValue: 10,
        newValue: 15
      });
    });
  });

  describe('Render Pipeline', () => {
    beforeEach(() => {
      liquidGlass = new LiquidGlass(mockElement);
    });

    test('should render frame correctly', () => {
      liquidGlass.render();
      
      expect(mockGL.clear).toHaveBeenCalledWith(mockGL.COLOR_BUFFER_BIT);
      expect(mockGL.drawArrays).toHaveBeenCalledWith(
        mockGL.TRIANGLE_STRIP,
        0,
        4
      );
    });

    test('should skip render when element not visible', () => {
      mockElement.getBoundingClientRect = jest.fn(() => ({
        width: 0,
        height: 0
      }));
      
      liquidGlass.render();
      
      expect(mockGL.drawArrays).not.toHaveBeenCalled();
    });

    test('should update uniforms before rendering', () => {
      liquidGlass.setBlur(30);
      liquidGlass.render();
      
      expect(mockGL.uniform1f).toHaveBeenCalledWith(
        liquidGlass.uniforms.blur,
        30
      );
    });

    test('should handle WebGL errors gracefully', () => {
      mockGL.drawArrays.mockImplementation(() => {
        throw new Error('WebGL Error');
      });
      
      expect(() => liquidGlass.render()).not.toThrow();
      expect(liquidGlass.fallbackMode).toBe('css');
    });
  });

  describe('Event Handling', () => {
    beforeEach(() => {
      liquidGlass = new LiquidGlass(mockElement);
    });

    test('should handle mouse enter events', () => {
      const event = new MouseEvent('mouseenter');
      mockElement.dispatchEvent(event);
      
      expect(liquidGlass.isHovered).toBe(true);
    });

    test('should handle mouse leave events', () => {
      liquidGlass.isHovered = true;
      
      const event = new MouseEvent('mouseleave');
      mockElement.dispatchEvent(event);
      
      expect(liquidGlass.isHovered).toBe(false);
    });

    test('should update mouse position on mouse move', () => {
      const event = new MouseEvent('mousemove', {
        clientX: 100,
        clientY: 200
      });
      
      mockElement.getBoundingClientRect = jest.fn(() => ({
        left: 50,
        top: 100,
        width: 200,
        height: 300
      }));
      
      mockElement.dispatchEvent(event);
      
      expect(liquidGlass.mousePosition).toEqual({
        x: 0.25, // (100-50)/200
        y: 0.33  // (200-100)/300
      });
    });

    test('should handle resize events', () => {
      const resizeSpy = jest.spyOn(liquidGlass, 'handleResize');
      
      window.dispatchEvent(new Event('resize'));
      
      expect(resizeSpy).toHaveBeenCalled();
    });
  });

  describe('Performance Optimization', () => {
    beforeEach(() => {
      liquidGlass = new LiquidGlass(mockElement);
    });

    test('should throttle render calls', () => {
      const renderSpy = jest.spyOn(liquidGlass, 'render');
      
      // Вызываем render несколько раз подряд
      liquidGlass.render();
      liquidGlass.render();
      liquidGlass.render();
      
      // Должен быть вызван только один раз из-за throttling
      expect(renderSpy).toHaveBeenCalledTimes(1);
    });

    test('should pause rendering when not visible', () => {
      const mockIntersectionObserver = {
        observe: jest.fn(),
        unobserve: jest.fn(),
        disconnect: jest.fn()
      };
      
      global.IntersectionObserver = jest.fn(() => mockIntersectionObserver);
      
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(mockIntersectionObserver.observe).toHaveBeenCalledWith(mockElement);
    });

    test('should cleanup resources on destroy', () => {
      const cleanupSpy = jest.spyOn(liquidGlass, 'cleanup');
      
      liquidGlass.destroy();
      
      expect(cleanupSpy).toHaveBeenCalled();
      expect(mockGL.deleteProgram).toHaveBeenCalled();
      expect(mockGL.deleteBuffer).toHaveBeenCalled();
    });
  });

  describe('Accessibility Features', () => {
    beforeEach(() => {
      liquidGlass = new LiquidGlass(mockElement);
    });

    test('should respect prefers-reduced-motion', () => {
      // Mock prefers-reduced-motion: reduce
      Object.defineProperty(window, 'matchMedia', {
        writable: true,
        value: jest.fn().mockImplementation(query => ({
          matches: query === '(prefers-reduced-motion: reduce)',
          addListener: jest.fn(),
          removeListener: jest.fn()
        }))
      });
      
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(liquidGlass.options.animation).toBe(false);
    });

    test('should add appropriate ARIA attributes', () => {
      expect(mockElement.getAttribute('aria-label')).toBeTruthy();
      expect(mockElement.getAttribute('role')).toBeTruthy();
    });

    test('should handle high contrast mode', () => {
      Object.defineProperty(window, 'matchMedia', {
        writable: true,
        value: jest.fn().mockImplementation(query => ({
          matches: query === '(prefers-contrast: high)',
          addListener: jest.fn(),
          removeListener: jest.fn()
        }))
      });
      
      liquidGlass = new LiquidGlass(mockElement);
      
      expect(liquidGlass.options.opacity).toBeGreaterThan(0.9);
      expect(liquidGlass.options.blur).toBeLessThan(5);
    });
  });
});
```

### Shader Testing

```javascript
// tests/unit/shaders.test.js
import { ShaderManager } from '@/ShaderManager';
import { createMockWebGLContext } from '@tests/utils/mocks';

describe('Shader Management', () => {
  let mockGL;
  let shaderManager;

  beforeEach(() => {
    mockGL = createMockWebGLContext();
    shaderManager = new ShaderManager(mockGL);
  });

  describe('Shader Compilation', () => {
    test('should compile vertex shader successfully', () => {
      const vertexSource = `
        attribute vec2 a_position;
        void main() {
          gl_Position = vec4(a_position, 0.0, 1.0);
        }
      `;
      
      const shader = shaderManager.compileShader(mockGL.VERTEX_SHADER, vertexSource);
      
      expect(mockGL.createShader).toHaveBeenCalledWith(mockGL.VERTEX_SHADER);
      expect(mockGL.shaderSource).toHaveBeenCalledWith(shader, vertexSource);
      expect(mockGL.compileShader).toHaveBeenCalledWith(shader);
    });

    test('should handle shader compilation errors', () => {
      mockGL.getShaderParameter.mockReturnValue(false);
      mockGL.getShaderInfoLog.mockReturnValue('Compilation error');
      
      const invalidSource = 'invalid shader code';
      
      expect(() => {
        shaderManager.compileShader(mockGL.VERTEX_SHADER, invalidSource);
      }).toThrow('Shader compilation failed: Compilation error');
    });

    test('should compile fragment shader successfully', () => {
      const fragmentSource = `
        precision mediump float;
        void main() {
          gl_FragColor = vec4(1.0, 0.0, 0.0, 1.0);
        }
      `;
      
      const shader = shaderManager.compileShader(mockGL.FRAGMENT_SHADER, fragmentSource);
      
      expect(mockGL.createShader).toHaveBeenCalledWith(mockGL.FRAGMENT_SHADER);
    });
  });

  describe('Program Linking', () => {
    test('should create and link shader program', () => {
      const vertexShader = {};
      const fragmentShader = {};
      
      const program = shaderManager.createProgram(vertexShader, fragmentShader);
      
      expect(mockGL.createProgram).toHaveBeenCalled();
      expect(mockGL.attachShader).toHaveBeenCalledWith(program, vertexShader);
      expect(mockGL.attachShader).toHaveBeenCalledWith(program, fragmentShader);
      expect(mockGL.linkProgram).toHaveBeenCalledWith(program);
    });

    test('should handle program linking errors', () => {
      mockGL.getProgramParameter.mockReturnValue(false);
      mockGL.getProgramInfoLog.mockReturnValue('Linking error');
      
      expect(() => {
        shaderManager.createProgram({}, {});
      }).toThrow('Program linking failed: Linking error');
    });
  });

  describe('Uniform Management', () => {
    test('should get uniform locations', () => {
      const program = {};
      const expectedLocation = {};
      mockGL.getUniformLocation.mockReturnValue(expectedLocation);
      
      const location = shaderManager.getUniformLocation(program, 'u_test');
      
      expect(mockGL.getUniformLocation).toHaveBeenCalledWith(program, 'u_test');
      expect(location).toBe(expectedLocation);
    });

    test('should set uniform values', () => {
      const location = {};
      
      shaderManager.setUniform1f(location, 1.5);
      expect(mockGL.uniform1f).toHaveBeenCalledWith(location, 1.5);
      
      shaderManager.setUniform2f(location, 1.0, 2.0);
      expect(mockGL.uniform2f).toHaveBeenCalledWith(location, 1.0, 2.0);
      
      shaderManager.setUniform3f(location, 1.0, 2.0, 3.0);
      expect(mockGL.uniform3f).toHaveBeenCalledWith(location, 1.0, 2.0, 3.0);
    });

    test('should validate uniform values', () => {
      const location = {};
      
      expect(() => {
        shaderManager.setUniform1f(location, NaN);
      }).toThrow('Invalid uniform value: NaN');
      
      expect(() => {
        shaderManager.setUniform1f(location, Infinity);
      }).toThrow('Invalid uniform value: Infinity');
    });
  });
});
```

### Performance Testing

```javascript
// tests/unit/performance.test.js
import { PerformanceMonitor } from '@/PerformanceMonitor';

describe('Performance Monitoring', () => {
  let performanceMonitor;

  beforeEach(() => {
    performanceMonitor = new PerformanceMonitor();
    
    // Mock performance.now() для предсказуемых результатов
    let currentTime = 0;
    jest.spyOn(performance, 'now').mockImplementation(() => {
      currentTime += 16.67; // ~60 FPS
      return currentTime;
    });
  });

  afterEach(() => {
    performanceMonitor.destroy();
    jest.restoreAllMocks();
  });

  describe('FPS Measurement', () => {
    test('should calculate FPS correctly', () => {
      const fps = performanceMonitor.measureFPS(10); // 10 frames
      
      expect(fps).toBeCloseTo(60, 1); // Ожидаем ~60 FPS
    });

    test('should track FPS over time', () => {
      for (let i = 0; i < 100; i++) {
        performanceMonitor.recordFrame();
      }
      
      const avgFPS = performanceMonitor.getAverageFPS();
      expect(avgFPS).toBeCloseTo(60, 1);
    });

    test('should detect FPS drops', () => {
      // Симулируем падение FPS
      performance.now.mockImplementation(() => {
        currentTime += 100; // Slow frame
        return currentTime;
      });
      
      performanceMonitor.recordFrame();
      
      const fpsDrops = performanceMonitor.getFPSDrops();
      expect(fpsDrops.length).toBeGreaterThan(0);
    });
  });

  describe('Memory Monitoring', () => {
    test('should track memory usage', () => {
      if (performance.memory) {
        const memoryUsage = performanceMonitor.getMemoryUsage();
        
        expect(memoryUsage).toHaveProperty('used');
        expect(memoryUsage).toHaveProperty('total');
        expect(memoryUsage).toHaveProperty('limit');
      } else {
        // Если memory API недоступен, проверяем fallback
        expect(() => performanceMonitor.getMemoryUsage()).not.toThrow();
      }
    });

    test('should detect memory leaks', () => {
      const initialMemory = 1000000;
      const leakyMemory = 5000000;
      
      // Mock возрастающего использования памяти
      let memoryCall = 0;
      Object.defineProperty(performance, 'memory', {
        get: () => ({
          usedJSHeapSize: memoryCall++ === 0 ? initialMemory : leakyMemory,
          totalJSHeapSize: 10000000,
          jsHeapSizeLimit: 20000000
        })
      });
      
      performanceMonitor.recordMemorySnapshot();
      performanceMonitor.recordMemorySnapshot();
      
      const memoryLeaks = performanceMonitor.detectMemoryLeaks();
      expect(memoryLeaks.length).toBeGreaterThan(0);
    });
  });

  describe('Performance Metrics', () => {
    test('should calculate frame time distribution', () => {
      const frameTimes = [16, 17, 15, 18, 16, 33, 16, 17]; // One slow frame
      frameTimes.forEach(time => {
        performanceMonitor.recordFrameTime(time);
      });
      
      const distribution = performanceMonitor.getFrameTimeDistribution();
      
      expect(distribution.p50).toBeCloseTo(16.5, 1);
      expect(distribution.p95).toBeCloseTo(33, 1);
      expect(distribution.p99).toBeCloseTo(33, 1);
    });

    test('should identify performance bottlenecks', () => {
      // Симулируем различные типы bottlenecks
      performanceMonitor.recordGPUTime(50); // High GPU time
      performanceMonitor.recordCPUTime(10); // Low CPU time
      
      const bottlenecks = performanceMonitor.identifyBottlenecks();
      
      expect(bottlenecks).toContain('gpu-bound');
    });

    test('should generate performance report', () => {
      for (let i = 0; i < 60; i++) {
        performanceMonitor.recordFrame();
        performanceMonitor.recordFrameTime(16 + Math.random() * 2);
      }
      
      const report = performanceMonitor.generateReport();
      
      expect(report).toHaveProperty('fps');
      expect(report).toHaveProperty('frameTime');
      expect(report).toHaveProperty('bottlenecks');
      expect(report).toHaveProperty('recommendations');
    });
  });
});
```

---

## Integration Testing

### Component Integration Tests

```javascript
// tests/integration/component-integration.test.js
import { render, fireEvent, waitFor } from '@testing-library/dom';
import { LiquidGlass } from '@/LiquidGlass';
import { LiquidGlassButton } from '@/components/LiquidGlassButton';

describe('Component Integration', () => {
  let container;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);
  });

  afterEach(() => {
    document.body.removeChild(container);
  });

  describe('LiquidGlass + Button Integration', () => {
    test('should integrate LiquidGlass with button component', async () => {
      const { getByRole } = render(`
        <button class="liquid-glass-button" data-testid="test-button">
          Click me
        </button>
      `, { container });

      const button = getByRole('button');
      const liquidGlass = new LiquidGlass(button);

      expect(liquidGlass.element).toBe(button);
      expect(button.classList.contains('liquid-glass-active')).toBe(true);
    });

    test('should handle button state changes', async () => {
      const { getByTestId } = render(`
        <button class="liquid-glass-button" data-testid="test-button">
          Click me
        </button>
      `, { container });

      const button = getByTestId('test-button');
      const liquidGlass = new LiquidGlass(button);

      // Test hover state
      fireEvent.mouseEnter(button);
      await waitFor(() => {
        expect(liquidGlass.isHovered).toBe(true);
      });

      // Test active state
      fireEvent.mouseDown(button);
      await waitFor(() => {
        expect(liquidGlass.isActive).toBe(true);
      });

      // Test disabled state
      button.disabled = true;
      button.dispatchEvent(new Event('change'));
      await waitFor(() => {
        expect(liquidGlass.options.opacity).toBeLessThan(0.5);
      });
    });

    test('should cleanup properly when button is removed', async () => {
      const { getByTestId } = render(`
        <button class="liquid-glass-button" data-testid="test-button">
          Click me
        </button>
      `, { container });

      const button = getByTestId('test-button');
      const liquidGlass = new LiquidGlass(button);
      const destroySpy = jest.spyOn(liquidGlass, 'destroy');

      container.removeChild(button);

      // MutationObserver должен вызвать cleanup
      await waitFor(() => {
        expect(destroySpy).toHaveBeenCalled();
      });
    });
  });

  describe('Multiple Instance Integration', () => {
    test('should handle multiple LiquidGlass instances', () => {
      const elements = [];
      const instances = [];

      // Создаем несколько элементов
      for (let i = 0; i < 5; i++) {
        const element = document.createElement('div');
        element.className = 'liquid-glass-element';
        element.setAttribute('data-testid', `element-${i}`);
        container.appendChild(element);
        elements.push(element);

        const instance = new LiquidGlass(element, {
          blur: 10 + i * 2,
          opacity: 0.7 + i * 0.05
        });
        instances.push(instance);
      }

      // Проверяем, что каждый экземпляр независим
      instances.forEach((instance, index) => {
        expect(instance.options.blur).toBe(10 + index * 2);
        expect(instance.options.opacity).toBe(0.7 + index * 0.05);
      });

      // Cleanup
      instances.forEach(instance => instance.destroy());
    });

    test('should handle performance with many instances', async () => {
      const instances = [];
      const startTime = performance.now();

      // Создаем много экземпляров
      for (let i = 0; i < 50; i++) {
        const element = document.createElement('div');
        element.style.cssText = `
          width: 100px;
          height: 100px;
          position: absolute;
          left: ${i * 10}px;
          top: ${i * 5}px;
        `;
        container.appendChild(element);

        const instance = new LiquidGlass(element);
        instances.push(instance);
      }

      const initTime = performance.now() - startTime;

      // Проверяем время инициализации
      expect(initTime).toBeLessThan(1000); // < 1 секунды

      // Cleanup
      instances.forEach(instance => instance.destroy());
    });
  });

  describe('Theme Integration', () => {
    test('should respond to theme changes', async () => {
      const { getByTestId } = render(`
        <div class="liquid-glass-element" data-testid="themed-element"></div>
      `, { container });

      const element = getByTestId('themed-element');
      const liquidGlass = new LiquidGlass(element);

      // Light theme
      document.documentElement.setAttribute('data-theme', 'light');
      await waitFor(() => {
        expect(liquidGlass.options.opacity).toBeCloseTo(0.8, 1);
      });

      // Dark theme
      document.documentElement.setAttribute('data-theme', 'dark');
      await waitFor(() => {
        expect(liquidGlass.options.opacity).toBeCloseTo(0.9, 1);
      });
    });

    test('should integrate with CSS custom properties', () => {
      document.documentElement.style.setProperty('--glass-blur', '15px');
      document.documentElement.style.setProperty('--glass-opacity', '0.85');

      const element = document.createElement('div');
      container.appendChild(element);

      const liquidGlass = new LiquidGlass(element);

      expect(liquidGlass.options.blur).toBe(15);
      expect(liquidGlass.options.opacity).toBe(0.85);
    });
  });
});
```

**Liquid-Glass-Testing-Automation.md частично готов!** 

Теперь создам финальный документ по CI/CD интеграции?