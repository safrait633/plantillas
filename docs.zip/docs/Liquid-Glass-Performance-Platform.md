# Liquid Glass - Оптимизация производительности: Platform-specific

Третья часть комплексного руководства по оптимизации производительности Liquid Glass эффектов, фокусирующаяся на платформо-специфичных оптимизациях и адаптивной производительности.

## Содержание

1. [Platform-specific оптимизации](#platform-specific-оптимизации)
2. [Adaptive Performance](#adaptive-performance)
3. [Thermal Management](#thermal-management)
4. [Cross-Platform Best Practices](#cross-platform-best-practices)

---

## Platform-specific оптимизации

### Web Optimizations

```css
/* CPU/GPU балансировка */
@media (max-resolution: 150dpi) {
  /* Слабые устройства - уменьшаем blur */
  .glass-element {
    backdrop-filter: blur(6px);
  }
}

@media (min-resolution: 300dpi) and (min-width: 1200px) {
  /* Мощные устройства - максимальное качество */
  .glass-element {
    backdrop-filter: blur(20px);
  }
}

/* Оптимизация для браузеров */
@supports (backdrop-filter: blur(1px)) {
  .glass-fallback {
    display: none;
  }
}

@supports not (backdrop-filter: blur(1px)) {
  .glass-effect {
    display: none;
  }
}

/* Container queries для адаптивной производительности */
@container (max-width: 300px) {
  .glass-card {
    backdrop-filter: blur(4px); /* Меньше blur для маленьких элементов */
  }
}

@container (min-width: 800px) {
  .glass-card {
    backdrop-filter: blur(16px); /* Больше blur для больших элементов */
  }
}
```

### iOS Performance Optimizations

```swift
import UIKit

class OptimizedGlassViewController: UIViewController {
    private var displayLink: CADisplayLink?
    private var isLowPowerModeEnabled = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupOptimizations()
    }
    
    private func setupOptimizations() {
        // Мониторинг Low Power Mode
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(lowPowerModeChanged),
            name: .NSProcessInfoPowerStateDidChange,
            object: nil
        )
        
        // Мониторинг thermal state
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(thermalStateChanged),
            name: ProcessInfo.thermalStateDidChangeNotification,
            object: nil
        )
        
        updateOptimizationSettings()
    }
    
    @objc private func lowPowerModeChanged() {
        isLowPowerModeEnabled = ProcessInfo.processInfo.isLowPowerModeEnabled
        updateOptimizationSettings()
    }
    
    @objc private func thermalStateChanged() {
        updateOptimizationSettings()
    }
    
    private func updateOptimizationSettings() {
        let thermalState = ProcessInfo.processInfo.thermalState
        let isThrottling = thermalState == .serious || thermalState == .critical
        
        if isLowPowerModeEnabled || isThrottling {
            // Снижаем качество при ограничениях
            view.subviews.compactMap { $0 as? UIVisualEffectView }.forEach { effectView in
                effectView.effect = UIBlurEffect(style: .light) // Более легкий эффект
            }
        } else {
            // Полное качество
            view.subviews.compactMap { $0 as? UIVisualEffectView }.forEach { effectView in
                effectView.effect = UIBlurEffect(style: .systemMaterial)
            }
        }
    }
    
    // Оптимизация анимаций
    func createOptimizedAnimation() -> CAAnimation {
        let animation = CABasicAnimation(keyPath: "opacity")
        animation.duration = isLowPowerModeEnabled ? 0.1 : 0.3
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        
        // Отключаем сложные анимации при ограничениях
        if ProcessInfo.processInfo.isLowPowerModeEnabled {
            animation.fillMode = .both
            animation.isRemovedOnCompletion = true
        }
        
        return animation
    }
}

// MARK: - Memory Pool для текстур
class TexturePool {
    private var availableTextures: [CGSize: [UIImage]] = [:]
    private let maxTexturesPerSize = 5
    
    func getTexture(size: CGSize) -> UIImage? {
        let textures = availableTextures[size] ?? []
        if let texture = textures.first {
            availableTextures[size]?.removeFirst()
            return texture
        }
        return nil
    }
    
    func returnTexture(_ texture: UIImage, size: CGSize) {
        if var textures = availableTextures[size] {
            if textures.count < maxTexturesPerSize {
                textures.append(texture)
                availableTextures[size] = textures
            }
        } else {
            availableTextures[size] = [texture]
        }
    }
    
    func clearPool() {
        availableTextures.removeAll()
    }
}
```

### Android Optimizations

```kotlin
class OptimizedGlassActivity : AppCompatActivity() {
    private var thermalManager: ThermalManager? = null
    private var isThrottling = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupThermalMonitoring()
        applyPerformanceOptimizations()
    }
    
    @TargetApi(Build.VERSION_CODES.Q)
    private fun setupThermalMonitoring() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            thermalManager = getSystemService(Context.THERMAL_SERVICE) as ThermalManager
            
            val thermalCallback = object : ThermalManager.OnThermalStatusChangedListener {
                override fun onThermalStatusChanged(status: Int) {
                    isThrottling = status >= ThermalManager.THERMAL_STATUS_MODERATE
                    adjustBlurQuality()
                }
            }
            
            thermalManager?.addThermalStatusListener(thermalCallback)
        }
    }
    
    private fun adjustBlurQuality() {
        val blurViews = findViewById<ViewGroup>(android.R.id.content)
            .getAllChildrenOfType<BlurView>()
        
        blurViews.forEach { blurView ->
            when {
                isThrottling -> {
                    // Минимальное качество при перегреве
                    blurView.blurRadius = 4f
                    blurView.downsampleFactor = 8f
                }
                isLowRAMDevice() -> {
                    // Средние настройки для слабых устройств
                    blurView.blurRadius = 8f
                    blurView.downsampleFactor = 4f
                }
                else -> {
                    // Максимальное качество
                    blurView.blurRadius = 16f
                    blurView.downsampleFactor = 1f
                }
            }
        }
    }
    
    private fun isLowRAMDevice(): Boolean {
        val activityManager = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return activityManager.isLowRamDevice
    }
    
    private fun applyPerformanceOptimizations() {
        // Включаем hardware acceleration
        window.setFlags(
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        )
        
        // Оптимизируем для GPU
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            window.statusBarColor = Color.TRANSPARENT
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        }
    }
}

// Extension для поиска view
inline fun <reified T : View> ViewGroup.getAllChildrenOfType(): List<T> {
    val result = mutableListOf<T>()
    
    for (i in 0 until childCount) {
        val child = getChildAt(i)
        if (child is T) {
            result.add(child)
        }
        if (child is ViewGroup) {
            result.addAll(child.getAllChildrenOfType<T>())
        }
    }
    
    return result
}

// Оптимизированный Blur View
class OptimizedBlurView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    
    var blurRadius: Float = 10f
        set(value) {
            field = value.coerceIn(0.1f, 25f)
            invalidate()
        }
    
    var downsampleFactor: Float = 1f
        set(value) {
            field = value.coerceAtLeast(1f)
            invalidate()
        }
    
    private var renderScript: RenderScript? = null
    private var blurScript: ScriptIntrinsicBlur? = null
    private var allocationIn: Allocation? = null
    private var allocationOut: Allocation? = null
    
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        initRenderScript()
    }
    
    private fun initRenderScript() {
        try {
            renderScript = RenderScript.create(context)
            blurScript = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        } catch (e: Exception) {
            Log.e("OptimizedBlurView", "Failed to create RenderScript", e)
        }
    }
    
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        cleanupRenderScript()
    }
    
    private fun cleanupRenderScript() {
        allocationIn?.destroy()
        allocationOut?.destroy()
        blurScript?.destroy()
        renderScript?.destroy()
        
        allocationIn = null
        allocationOut = null
        blurScript = null
        renderScript = null
    }
}
```

---

## Adaptive Performance

### Dynamic Quality Scaling

```javascript
class AdaptiveQualityManager {
  constructor() {
    this.qualityLevel = 'high';
    this.performanceMonitor = new PerformanceMonitor();
    this.thresholds = {
      fps: { high: 55, medium: 45, low: 30 },
      memory: { high: 50, medium: 70, low: 85 }, // percentage
      renderTime: { high: 10, medium: 16, low: 33 } // ms
    };
    
    this.startMonitoring();
  }
  
  startMonitoring() {
    setInterval(() => {
      const metrics = this.performanceMonitor.getMetrics();
      const newQuality = this.calculateOptimalQuality(metrics);
      
      if (newQuality !== this.qualityLevel) {
        this.updateQuality(newQuality);
      }
    }, 1000);
  }
  
  calculateOptimalQuality(metrics) {
    const scores = {
      fps: this.getQualityScore('fps', metrics.fps),
      memory: this.getQualityScore('memory', metrics.memoryUsage),
      renderTime: this.getQualityScore('renderTime', metrics.averageRenderTime)
    };
    
    // Берем худший показатель
    const minScore = Math.min(...Object.values(scores));
    
    switch (minScore) {
      case 3: return 'high';
      case 2: return 'medium';
      case 1: return 'low';
      default: return 'minimal';
    }
  }
  
  getQualityScore(metric, value) {
    const thresholds = this.thresholds[metric];
    
    if (metric === 'fps') {
      if (value >= thresholds.high) return 3;
      if (value >= thresholds.medium) return 2;
      if (value >= thresholds.low) return 1;
      return 0;
    } else {
      // Для memory и renderTime меньше = лучше
      if (value <= thresholds.high) return 3;
      if (value <= thresholds.medium) return 2;
      if (value <= thresholds.low) return 1;
      return 0;
    }
  }
  
  updateQuality(newQuality) {
    console.log(`Quality changed: ${this.qualityLevel} → ${newQuality}`);
    this.qualityLevel = newQuality;
    
    const qualitySettings = this.getQualitySettings(newQuality);
    this.applyQualitySettings(qualitySettings);
  }
  
  getQualitySettings(quality) {
    const settings = {
      high: {
        blurRadius: 16,
        downsample: 1,
        animationDuration: 300,
        useComplexEffects: true
      },
      medium: {
        blurRadius: 12,
        downsample: 2,
        animationDuration: 200,
        useComplexEffects: true
      },
      low: {
        blurRadius: 8,
        downsample: 4,
        animationDuration: 100,
        useComplexEffects: false
      },
      minimal: {
        blurRadius: 4,
        downsample: 8,
        animationDuration: 0,
        useComplexEffects: false
      }
    };
    
    return settings[quality];
  }
  
  applyQualitySettings(settings) {
    // Обновляем CSS переменные
    document.documentElement.style.setProperty('--blur-radius', `${settings.blurRadius}px`);
    document.documentElement.style.setProperty('--animation-duration', `${settings.animationDuration}ms`);
    document.documentElement.style.setProperty('--downsample-factor', settings.downsample);
    
    // Обновляем класс для условных стилей
    document.body.className = document.body.className.replace(/quality-\w+/, '');
    document.body.classList.add(`quality-${this.qualityLevel}`);
    
    // Оповещаем компоненты об изменении качества
    window.dispatchEvent(new CustomEvent('qualityChanged', {
      detail: { quality: this.qualityLevel, settings }
    }));
  }
}

// CSS для адаптивного качества
const adaptiveCSS = `
.quality-high .glass-element {
  backdrop-filter: blur(var(--blur-radius));
  transition: all var(--animation-duration);
}

.quality-medium .glass-element {
  backdrop-filter: blur(var(--blur-radius));
  transition: all var(--animation-duration);
}

.quality-low .glass-element {
  backdrop-filter: blur(var(--blur-radius));
  transition: none;
}

.quality-minimal .glass-element {
  backdrop-filter: none;
  background: rgba(255, 255, 255, 0.8);
  transition: none;
}
`;

// Performance Monitor для адаптивного качества
class PerformanceMonitor {
  constructor() {
    this.metrics = {
      fps: 60,
      memoryUsage: 0,
      averageRenderTime: 0
    };
    
    this.frameCount = 0;
    this.lastTime = performance.now();
    this.renderTimes = [];
    
    this.startTracking();
  }
  
  startTracking() {
    const trackFrame = () => {
      const currentTime = performance.now();
      this.frameCount++;
      
      // Обновляем FPS каждую секунду
      if (currentTime - this.lastTime >= 1000) {
        this.metrics.fps = Math.round((this.frameCount * 1000) / (currentTime - this.lastTime));
        this.frameCount = 0;
        this.lastTime = currentTime;
      }
      
      // Отслеживаем memory
      if ('memory' in performance) {
        const memory = performance.memory;
        this.metrics.memoryUsage = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
      }
      
      // Отслеживаем render time
      if (this.renderTimes.length > 0) {
        this.metrics.averageRenderTime = this.renderTimes.reduce((a, b) => a + b) / this.renderTimes.length;
        if (this.renderTimes.length > 60) {
          this.renderTimes = this.renderTimes.slice(-30); // Храним только последние 30 замеров
        }
      }
      
      requestAnimationFrame(trackFrame);
    };
    
    requestAnimationFrame(trackFrame);
  }
  
  recordRenderTime(time) {
    this.renderTimes.push(time);
  }
  
  getMetrics() {
    return { ...this.metrics };
  }
}

// Инициализация
const qualityManager = new AdaptiveQualityManager();
```

---

## Thermal Management

### Device Temperature Monitoring

```javascript
// Web - Приблизительное определение thermal throttling
class WebThermalManager {
  constructor() {
    this.isThrottling = false;
    this.baselinePerformance = null;
    this.performanceDropThreshold = 0.3; // 30% падение производительности
    
    this.startMonitoring();
  }
  
  startMonitoring() {
    // Устанавливаем baseline после загрузки
    setTimeout(() => {
      this.establishBaseline();
    }, 5000);
    
    // Мониторинг каждые 10 секунд
    setInterval(() => {
      this.checkThermalThrottling();
    }, 10000);
  }
  
  establishBaseline() {
    const startTime = performance.now();
    
    // Выполняем стандартную нагрузку
    this.performStandardWorkload(() => {
      const duration = performance.now() - startTime;
      this.baselinePerformance = duration;
      console.log('Baseline performance established:', duration + 'ms');
    });
  }
  
  checkThermalThrottling() {
    if (!this.baselinePerformance) return;
    
    const startTime = performance.now();
    
    this.performStandardWorkload(() => {
      const duration = performance.now() - startTime;
      const performanceDrop = (duration - this.baselinePerformance) / this.baselinePerformance;
      
      const wasThrottling = this.isThrottling;
      this.isThrottling = performanceDrop > this.performanceDropThreshold;
      
      if (this.isThrottling !== wasThrottling) {
        this.handleThermalStateChange(this.isThrottling);
      }
    });
  }
  
  performStandardWorkload(callback) {
    // Стандартная вычислительная нагрузка для тестирования
    let result = 0;
    const iterations = 100000;
    
    const work = (remaining) => {
      if (remaining <= 0) {
        callback();
        return;
      }
      
      // Выполняем часть работы
      for (let i = 0; i < 1000; i++) {
        result += Math.sin(i) * Math.cos(i);
      }
      
      // Продолжаем асинхронно
      setTimeout(() => work(remaining - 1000), 0);
    };
    
    work(iterations);
  }
  
  handleThermalStateChange(isThrottling) {
    console.log('Thermal state changed:', isThrottling ? 'THROTTLING' : 'NORMAL');
    
    if (isThrottling) {
      // Снижаем нагрузку
      document.documentElement.style.setProperty('--blur-quality', 'low');
      document.documentElement.style.setProperty('--animation-reduced', 'true');
    } else {
      // Восстанавливаем качество
      document.documentElement.style.setProperty('--blur-quality', 'high');
      document.documentElement.style.setProperty('--animation-reduced', 'false');
    }
    
    // Уведомляем компоненты
    window.dispatchEvent(new CustomEvent('thermalStateChanged', {
      detail: { isThrottling }
    }));
  }
  
  getStatus() {
    return {
      isThrottling: this.isThrottling,
      baselinePerformance: this.baselinePerformance,
      recommendation: this.isThrottling ? 'reduce_quality' : 'normal'
    };
  }
}

// iOS Thermal Management через JavaScript bridge
class iOSThermalManager {
  constructor() {
    this.thermalState = 'nominal';
    
    if (window.webkit?.messageHandlers?.thermalManager) {
      // Запрашиваем текущее состояние
      this.requestThermalState();
      
      // Подписываемся на изменения
      window.addEventListener('thermalStateChanged', this.handleThermalStateChange.bind(this));
    }
  }
  
  requestThermalState() {
    window.webkit.messageHandlers.thermalManager.postMessage({ action: 'getThermalState' });
  }
  
  handleThermalStateChange(event) {
    this.thermalState = event.detail.state;
    
    switch (this.thermalState) {
      case 'nominal':
        this.applyQualityLevel('high');
        break;
      case 'fair':
        this.applyQualityLevel('medium');
        break;
      case 'serious':
        this.applyQualityLevel('low');
        break;
      case 'critical':
        this.applyQualityLevel('minimal');
        break;
    }
  }
  
  applyQualityLevel(level) {
    const qualitySettings = {
      high: { blur: 16, animations: true, complexEffects: true },
      medium: { blur: 12, animations: true, complexEffects: false },
      low: { blur: 8, animations: false, complexEffects: false },
      minimal: { blur: 0, animations: false, complexEffects: false }
    };
    
    const settings = qualitySettings[level];
    
    document.documentElement.style.setProperty('--thermal-blur', `${settings.blur}px`);
    document.documentElement.style.setProperty('--thermal-animations', settings.animations ? 'enabled' : 'disabled');
    document.body.classList.toggle('thermal-reduced', level === 'low' || level === 'minimal');
  }
}

// Android Thermal Management
class AndroidThermalManager {
  constructor() {
    this.thermalStatus = 0; // THERMAL_STATUS_NONE
    
    if (window.Android?.getThermalStatus) {
      this.startMonitoring();
    }
  }
  
  startMonitoring() {
    setInterval(() => {
      const status = window.Android.getThermalStatus();
      
      if (status !== this.thermalStatus) {
        this.thermalStatus = status;
        this.handleThermalStatusChange(status);
      }
    }, 5000);
  }
  
  handleThermalStatusChange(status) {
    // Android thermal status levels:
    // 0: THERMAL_STATUS_NONE
    // 1: THERMAL_STATUS_LIGHT
    // 2: THERMAL_STATUS_MODERATE
    // 3: THERMAL_STATUS_SEVERE
    // 4: THERMAL_STATUS_CRITICAL
    
    let qualityLevel;
    switch (status) {
      case 0:
      case 1:
        qualityLevel = 'high';
        break;
      case 2:
        qualityLevel = 'medium';
        break;
      case 3:
        qualityLevel = 'low';
        break;
      case 4:
        qualityLevel = 'minimal';
        break;
      default:
        qualityLevel = 'medium';
    }
    
    this.applyThermalOptimizations(qualityLevel, status);
  }
  
  applyThermalOptimizations(quality, status) {
    console.log(`Android thermal status: ${status}, applying quality: ${quality}`);
    
    // Применяем настройки через CSS
    document.body.setAttribute('data-thermal-status', status.toString());
    document.body.setAttribute('data-quality', quality);
    
    // Уведомляем компоненты
    window.dispatchEvent(new CustomEvent('androidThermalChanged', {
      detail: { status, quality }
    }));
  }
}

// Универсальный thermal manager
class UniversalThermalManager {
  constructor() {
    this.managers = [];
    
    // Инициализируем подходящий manager
    if (this.isIOS()) {
      this.managers.push(new iOSThermalManager());
    } else if (this.isAndroid()) {
      this.managers.push(new AndroidThermalManager());
    } else {
      this.managers.push(new WebThermalManager());
    }
  }
  
  isIOS() {
    return /iPad|iPhone|iPod/.test(navigator.userAgent);
  }
  
  isAndroid() {
    return /Android/.test(navigator.userAgent);
  }
  
  getStatus() {
    return this.managers.map(manager => manager.getStatus?.() || {});
  }
}

// Инициализация
const thermalManager = new UniversalThermalManager();
```

---

## Cross-Platform Best Practices

### Performance Checklist - Complete

```markdown
## Liquid Glass Performance Checklist - Полный

### ✅ GPU Optimization
- [ ] Use `transform` and `opacity` for animations
- [ ] Set `will-change` property strategically
- [ ] Promote elements to GPU layers with `translateZ(0)`
- [ ] Use `isolation: isolate` to prevent layer explosions
- [ ] Prefer `filter` over CSS gradients for blur effects

### ✅ Memory Management
- [ ] Implement texture pooling for repeated operations
- [ ] Use WeakMap/WeakSet for element references
- [ ] Clear unused textures and buffers
- [ ] Monitor memory usage and implement cleanup
- [ ] Use lazy loading for off-screen elements

### ✅ Render Optimization
- [ ] Batch DOM operations
- [ ] Use `contain` property for performance isolation
- [ ] Minimize reflows and repaints
- [ ] Implement virtual scrolling for large lists
- [ ] Use `requestAnimationFrame` for smooth animations

### ✅ Adaptive Performance
- [ ] Implement quality scaling based on device capabilities
- [ ] Respect user preferences (reduce motion, high contrast)
- [ ] Monitor thermal throttling on mobile devices
- [ ] Use feature detection for graceful degradation
- [ ] Implement performance budgets and monitoring

### ✅ Platform-Specific
- [ ] Use native blur materials on iOS/macOS
- [ ] Implement RenderScript blur on Android
- [ ] Use WebGL for complex blur operations on Web
- [ ] Optimize for different screen densities
- [ ] Test on low-end devices

### ✅ Thermal Management
- [ ] Monitor device temperature and throttling
- [ ] Implement adaptive quality scaling
- [ ] Reduce effects during thermal events
- [ ] Provide fallback implementations
- [ ] Use efficient algorithms during throttling

### ✅ Debugging & Profiling
- [ ] Set up performance monitoring
- [ ] Use browser DevTools for profiling
- [ ] Implement custom performance marks
- [ ] Monitor FPS and frame drops
- [ ] Track memory usage patterns
```

### Final Integration Example

```javascript
// Комплексный Glass Performance Manager
class GlassPerformanceManager {
  constructor() {
    this.qualityManager = new AdaptiveQualityManager();
    this.thermalManager = new UniversalThermalManager();
    this.memoryMonitor = new MemoryMonitor();
    
    this.setupIntegration();
  }
  
  setupIntegration() {
    // Интеграция всех систем мониторинга
    window.addEventListener('qualityChanged', this.handleQualityChange.bind(this));
    window.addEventListener('thermalStateChanged', this.handleThermalChange.bind(this));
    window.addEventListener('memoryWarning', this.handleMemoryWarning.bind(this));
    
    this.memoryMonitor.onMemoryStatus('critical', this.handleCriticalMemory.bind(this));
  }
  
  handleQualityChange(event) {
    const { quality, settings } = event.detail;
    console.log(`Performance quality changed to: ${quality}`, settings);
    
    // Применяем настройки ко всем Glass компонентам
    this.applyGlobalSettings(settings);
  }
  
  handleThermalChange(event) {
    const { isThrottling } = event.detail;
    
    if (isThrottling) {
      // Принудительно снижаем качество
      this.qualityManager.forceQuality('low');
    } else {
      // Возвращаем автоматическое управление
      this.qualityManager.enableAutomatic();
    }
  }
  
  handleMemoryWarning() {
    // Очищаем кэши и снижаем качество
    this.clearCaches();
    this.qualityManager.forceQuality('minimal');
  }
  
  handleCriticalMemory(memoryInfo) {
    console.error('Critical memory situation:', memoryInfo);
    
    // Экстренные меры
    this.emergencyCleanup();
    this.qualityManager.forceQuality('minimal');
  }
  
  applyGlobalSettings(settings) {
    // Применяем настройки ко всем Glass элементам
    const glassElements = document.querySelectorAll('[data-glass]');
    
    glassElements.forEach(element => {
      element.style.setProperty('--blur-radius', `${settings.blurRadius}px`);
      element.style.setProperty('--animation-duration', `${settings.animationDuration}ms`);
      
      if (!settings.useComplexEffects) {
        element.classList.add('simple-mode');
      } else {
        element.classList.remove('simple-mode');
      }
    });
  }
  
  clearCaches() {
    // Очищаем все кэши
    if (window.glassTextureCache) {
      window.glassTextureCache.clear();
    }
    
    // Принудительная сборка мусора
    if (window.gc) {
      window.gc();
    }
  }
  
  emergencyCleanup() {
    // Экстренная очистка всех ресурсов
    this.clearCaches();
    
    // Отключаем все анимации
    document.documentElement.style.setProperty('--animation-duration', '0ms');
    
    // Минимальный blur
    document.documentElement.style.setProperty('--blur-radius', '2px');
    
    // Уведомляем о критической ситуации
    window.dispatchEvent(new CustomEvent('performanceEmergency'));
  }
  
  getStatus() {
    return {
      quality: this.qualityManager.qualityLevel,
      thermal: this.thermalManager.getStatus(),
      memory: this.memoryMonitor.getMemoryReport()
    };
  }
}

// Глобальная инициализация
window.glassPerformanceManager = new GlassPerformanceManager();

// Экспорт для модульных систем
if (typeof module !== 'undefined' && module.exports) {
  module.exports = GlassPerformanceManager;
}
```

---

## Заключение части 3

В третьей части мы завершили полное руководство по оптимизации:

### 🌟 **Platform-specific:**
1. **Web** - CSS оптимизации, feature detection, container queries
2. **iOS** - Low Power Mode, thermal state, texture pooling
3. **Android** - thermal management, low RAM detection, RenderScript

### 🔄 **Adaptive Performance:**
- Динамическое масштабирование качества
- Мониторинг FPS, памяти, render time
- Автоматическая подстройка под возможности устройства

### 🌡️ **Thermal Management:**
- Мониторинг температуры устройства
- Адаптивное снижение нагрузки
- Cross-platform detection и handling

### 🎯 **Интеграция:**
- Единый Performance Manager
- Координация всех систем мониторинга
- Экстренные меры при критических ситуациях

**📋 Все части серии:**
- [Liquid-Glass-Performance-GPU.md] - GPU оптимизация и основы
- [Liquid-Glass-Performance-Memory.md] - управление памятью и профилирование
- [Liquid-Glass-Performance-Platform.md] - платформо-специфичные оптимизации ✅

Теперь у вас есть полное руководство по оптимизации производительности Liquid Glass эффектов!