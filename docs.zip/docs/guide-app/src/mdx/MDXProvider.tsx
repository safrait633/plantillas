import React from 'react'
import { MDXProvider as Provider } from '@mdx-js/react'
import { Callout } from '../components/Callout'
import { Tabs, Tab } from '../components/Tabs'
import { PreCode } from '../components/CodeBlock'

const components = { Callout, Tabs, Tab, pre: PreCode }

export function MDXProvider({ children }: { children: React.ReactNode }) {
  return <Provider components={components as any}>{children}</Provider>
}

export default MDXProvider
