import React from 'react'

function parseLang(className?: string) {
  if (!className) return { lang: undefined, withLines: false }
  const m = className.match(/language-([A-Za-z0-9+#-]+)(\+lines)?/)
  return { lang: m?.[1], withLines: Boolean(m?.[2]) }
}

export function CodeBlock({ code, className }: { code: string; className?: string }) {
  const { lang, withLines } = parseLang(className)
  const [copied, setCopied] = React.useState(false)
  const onCopy = async () => {
    try { await navigator.clipboard.writeText(code); setCopied(true); setTimeout(()=>setCopied(false), 1200) } catch {}
  }
  const lines = code.replace(/\n$/, '').split('\n')
  return (
    <div className={`code-block ${lang ? 'code-with-header' : ''} ${withLines ? 'code-lines' : ''}`}>
      {lang && (
        <div className="code-meta">
          <span className="lang">{lang.toUpperCase()}</span>
          <button className="copy-btn" onClick={onCopy}>{copied ? 'Copied' : 'Copy'}</button>
        </div>
      )}
      <pre className={`hljs ${className ?? ''}`}>
        <code>
          {withLines
            ? lines.map((l, i) => <span key={i}>{l}\n</span>)
            : code}
        </code>
      </pre>
    </div>
  )
}

export function PreCode(props: any) {
  // MDX завернёт как <pre><code className=...>...</code></pre>
  const child = React.Children.only(props.children) as React.ReactElement<{ className?: string; children?: any }>
  const className = child?.props?.className
  const code = String(child?.props?.children ?? '')
  return <CodeBlock className={className} code={code} />
}

export default CodeBlock
