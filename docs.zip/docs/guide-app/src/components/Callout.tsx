import React from 'react'

type CalloutType = 'info' | 'tip' | 'warn' | 'danger'

const palette: Record<CalloutType, { border: string; bg: string; label: string }> = {
  info:   { border: '#0A84FF', bg: 'color-mix(in srgb, #0A84FF 10%, transparent)', label: 'Info' },
  tip:    { border: '#30D158', bg: 'color-mix(in srgb, #30D158 10%, transparent)', label: 'Tip' },
  warn:   { border: '#FF9F0A', bg: 'color-mix(in srgb, #FF9F0A 10%, transparent)', label: 'Warning' },
  danger: { border: '#FF453A', bg: 'color-mix(in srgb, #FF453A 10%, transparent)', label: 'Danger' },
}

export function Callout({ type = 'info', title, children }: { type?: CalloutType; title?: string; children: React.ReactNode }) {
  const c = palette[type]
  return (
    <div className="glass-surface callout" style={{ borderLeft: `4px solid ${c.border}`, backgroundImage: `linear-gradient(180deg, var(--bg-elev-1), var(--bg-elev-2)), radial-gradient(${c.bg}, transparent)` }}>
      <strong style={{ display: 'block', marginBottom: 8 }}>{title ?? c.label}</strong>
      <div>{children}</div>
    </div>
  )
}

export default Callout
