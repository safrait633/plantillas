import React from 'react'

type TabProps = { id: string; title: string; children: React.ReactNode }

export function Tabs({ children, defaultId }: { children: React.ReactElement<TabProps>[] | React.ReactElement<TabProps>; defaultId?: string }) {
  const items = React.Children.toArray(children) as React.ReactElement<TabProps>[]
  const first = items[0]
  const [active, setActive] = React.useState<string>(defaultId ?? (first?.props.id ?? 'tab-0'))
  return (
    <div className="tabs glass-surface" style={{ padding: 0 }}>
      <div className="tabs-bar" role="tablist" style={{ display: 'flex', gap: 4, padding: '8px 8px 0 8px' }}>
        {items.map((tab) => (
          <button key={tab.props.id} role="tab" aria-selected={active===tab.props.id} className={`btn ${active===tab.props.id ? 'primary' : ''}`} onClick={() => setActive(tab.props.id)}>{tab.props.title}</button>
        ))}
      </div>
      <div className="tabs-content" style={{ padding: 16 }}>
        {items.map((tab) => active===tab.props.id && (
          <div key={tab.props.id} role="tabpanel">
            {tab.props.children}
          </div>
        ))}
      </div>
    </div>
  )
}

export function Tab({ children }: TabProps) {
  return <>{children}</>
}

export default Tabs
