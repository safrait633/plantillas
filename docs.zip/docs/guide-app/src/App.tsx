import { BrowserRouter, NavLink, Route, Routes, useParams } from 'react-router-dom'
import React from 'react'
import './App.css'
import './index.css'

function Navbar() {
  const [theme, setTheme] = React.useState<string | null>(() => localStorage.getItem('theme'))
  React.useEffect(() => {
    if (theme) {
      document.documentElement.setAttribute('data-theme', theme)
    } else {
      document.documentElement.removeAttribute('data-theme')
    }
  }, [theme])

  function toggleTheme() {
    setTheme((prev) => {
      const next = prev === 'dark' ? 'light' : (prev === 'light' ? null : 'dark')
      if (next) localStorage.setItem('theme', next); else localStorage.removeItem('theme')
      return next
    })
  }

  return (
    <header style={{ position: 'sticky', top: 0, zIndex: 10 }}>
      <nav className="glass-surface" style={{ padding: '10px 16px' }}>
        <div className="container row" style={{ justifyContent: 'space-between' }}>
          <div className="row" style={{ gap: 12 }}>
            <a href="/" aria-label="Liquid Glass Home" style={{ fontWeight: 600, letterSpacing: -0.2 }}>Liquid Glass</a>
            <span style={{ color: 'var(--text-muted)' }}>|</span>
            <NavLink to="/" className={({isActive}) => isActive ? 'active' : ''}>Главная</NavLink>
            <NavLink to="/getting-started" className={({isActive}) => isActive ? 'active' : ''}>Старт</NavLink>
            <NavLink to="/core-concepts" className={({isActive}) => isActive ? 'active' : ''}>Концепции</NavLink>
            <NavLink to="/components" className={({isActive}) => isActive ? 'active' : ''}>Компоненты</NavLink>
            <NavLink to="/best-practices" className={({isActive}) => isActive ? 'active' : ''}>Практики</NavLink>
            <NavLink to="/demo" className={({isActive}) => isActive ? 'active' : ''}>Демо</NavLink>
            <NavLink to="/docs" className={({isActive}) => isActive ? 'active' : ''}>Docs</NavLink>
          </div>
          <div className="row" style={{ gap: 8 }}>
            <button className="btn" onClick={toggleTheme} aria-label="Toggle theme">
              Тема: {theme ?? 'auto'}
            </button>
            <a className="btn primary" href="https://react.dev" target="_blank" rel="noreferrer">React</a>
          </div>
        </div>
      </nav>
    </header>
  )
}

function Toc() {
  const [items, setItems] = React.useState<{ id: string; text: string; level: number }[]>([])
  const [active, setActive] = React.useState<string>('')
  React.useEffect(() => {
    const container = document.querySelector('.markdown')
    if (!container) return
    const hs = Array.from(container.querySelectorAll('h1, h2, h3')) as HTMLHeadingElement[]
    const entries = hs.map(h => ({ id: h.id, text: h.textContent ?? '', level: parseInt(h.tagName.substring(1), 10) }))
    setItems(entries)
    const observer = new IntersectionObserver((obs) => {
      obs.forEach(entry => {
        if (entry.isIntersecting) setActive((entry.target as HTMLElement).id)
      })
    }, { rootMargin: '0px 0px -70% 0px' })
    hs.forEach(h => observer.observe(h))
    return () => observer.disconnect()
  }, [])
  return (
    <nav aria-label="Содержание">
      <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
        {items.map(i => (
          <li key={i.id} style={{ margin: '4px 0 4px', paddingLeft: (i.level-1)*12 }}>
            <a href={`#${i.id}`} className={active===i.id ? 'active' : ''}>{i.text}</a>
          </li>
        ))}
      </ul>
    </nav>
  )
}

function GlassSurface(props: React.HTMLAttributes<HTMLDivElement>) {
  return <div {...props} className={`glass-surface ${props.className ?? ''}`.trim()} />
}

function Home() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <div className="stack">
        <GlassSurface style={{ padding: 24 }}>
          <h1>Liquid Glass Guide</h1>
          <p>Лёгкая, нейтральная палитра, продуманная типографика и деликатное стекло.</p>
          <div className="row">
            <a className="btn primary" href="/getting-started">Начать</a>
            <a className="btn" href="/components">Компоненты</a>
          </div>
        </GlassSurface>

        <section>
          <h2>Принципы</h2>
          <div className="row" style={{ flexWrap: 'wrap' }}>
            <GlassSurface style={{ padding: 16, flex: '1 1 320px' }}>
              <h3>Нейтральные цвета</h3>
              <p>Серые и белые с акцентом iOS Blue. Избегаем кислотных оттенков.</p>
            </GlassSurface>
            <GlassSurface style={{ padding: 16, flex: '1 1 320px' }}>
              <h3>Простота</h3>
              <p>Минимум эффектов. Акцент на содержании и удобстве.</p>
            </GlassSurface>
            <GlassSurface style={{ padding: 16, flex: '1 1 320px' }}>
              <h3>Стекло</h3>
              <p>Тонкий блюр, мягкие тени, лёгкие границы. Без лишнего глянца.</p>
            </GlassSurface>
          </div>
        </section>
      </div>
    </main>
  )
}

function GettingStarted() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <GlassSurface style={{ padding: 24 }}>
        <h2>Быстрый старт</h2>
        <p>Этот гайд построен на React + Vite. Компоненты выдержаны в стиле Apple с Liquid Glass.</p>
      </GlassSurface>
    </main>
  )
}

function CoreConcepts() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <GlassSurface style={{ padding: 24 }}>
        <h2>Ключевые концепции</h2>
        <ul>
          <li>GlassSurface: базовая стеклянная поверхность.</li>
          <li>Система токенов: цвета, отступы, радиусы.</li>
          <li>Адаптивность и доступность по умолчанию.</li>
        </ul>
      </GlassSurface>
    </main>
  )
}

function ComponentsPage() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <div className="stack">
        <GlassSurface style={{ padding: 24 }}>
          <h2>Компоненты</h2>
          <div className="row">
            <button className="btn">По умолчанию</button>
            <button className="btn primary">Акцент</button>
          </div>
        </GlassSurface>
        <GlassSurface style={{ padding: 24 }}>
          <h3>Card</h3>
          <p>Карточка на стекле с мягкой тенью и тонкой границей.</p>
        </GlassSurface>
      </div>
    </main>
  )
}

function BestPractices() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <GlassSurface style={{ padding: 24 }}>
        <h2>Лучшие практики</h2>
        <ul>
          <li>Соблюдайте контраст и читайте с системных цветов.</li>
          <li>Минимизируйте шум и декоративные эффекты.</li>
          <li>Учитывайте prefer-reduced-motion и prefers-color-scheme.</li>
        </ul>
      </GlassSurface>
    </main>
  )
}

function Demo() {
  const [blur, setBlur] = React.useState(20)
  const [radius, setRadius] = React.useState(16)
  const [shadow, setShadow] = React.useState(10)

  const style: React.CSSProperties = {
    padding: 24,
    backdropFilter: `saturate(180%) blur(${blur}px)`,
    WebkitBackdropFilter: `saturate(180%) blur(${blur}px)`,
    borderRadius: radius,
    boxShadow: `0 ${shadow}px ${shadow * 3}px rgba(0,0,0,${Math.min(0.06 + shadow/200, 0.6)})`,
  }

  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <div className="stack">
        <GlassSurface style={{ padding: 24 }}>
          <h2>Демо</h2>
          <p>Настройте параметры стекла и сразу увидите результат.</p>
          <div className="row" style={{ flexWrap: 'wrap', gap: 16 }}>
            <label>blur: {blur}px <input type="range" min={0} max={50} value={blur} onChange={e=>setBlur(parseInt(e.target.value))} /></label>
            <label>radius: {radius}px <input type="range" min={0} max={32} value={radius} onChange={e=>setRadius(parseInt(e.target.value))} /></label>
            <label>shadow: {shadow}px <input type="range" min={0} max={30} value={shadow} onChange={e=>setShadow(parseInt(e.target.value))} /></label>
          </div>
        </GlassSurface>

        <div className="row" style={{ gap: 16, alignItems: 'stretch', flexWrap: 'wrap' }}>
          <div style={{ flex: '1 1 320px' }}>
            <div className="glass-surface" style={style}>
              <h3>Поверхность</h3>
              <p>Это живая карточка с вашими параметрами.</p>
              <button className="btn primary">Кнопка</button>
            </div>
          </div>
          <div style={{ flex: '1 1 320px' }}>
            <div className="glass-surface" style={style}>
              <h3>Ещё одна</h3>
              <p>Проверьте читаемость и контраст.</p>
              <button className="btn">Вторичная</button>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

function Docs() {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <GlassSurface style={{ padding: 24 }}>
        <h2>Документация</h2>
        <p>Раздел рендерит существующие Markdown-файлы из <code>docs/guide</code>.</p>
        <ul>
          <li><NavLink to="/docs/getting-started">01-getting-started.md</NavLink></li>
          <li><NavLink to="/docs/core-concepts">02-core-concepts.md</NavLink></li>
          <li><NavLink to="/docs/components">03-components-library.md</NavLink></li>
          <li><NavLink to="/docs/best-practices">06-best-practices.md</NavLink></li>
          <li><NavLink to="/docs/mdx-demo">MDX Demo (Callout, CodeTabs)</NavLink></li>
        </ul>
        <h3>Модули</h3>
        <ul>
          {Object.keys(moduleDocsByName).map((name) => (
            <li key={name}><NavLink to={`/docs/modules/${encodeURIComponent(name)}`}>{name}</NavLink></li>
          ))}
        </ul>
      </GlassSurface>
    </main>
  )
}

import ReactMarkdown from 'react-markdown'
import rehypeHighlight from 'rehype-highlight'
import rehypeSlug from 'rehype-slug'
import rehypeAutolinkHeadings from 'rehype-autolink-headings'
import { CodeBlock } from './components/CodeBlock'
import gettingStarted from '../../../docs/guide/01-getting-started.md?raw'
import coreConcepts from '../../../docs/guide/02-core-concepts.md?raw'
import componentsLib from '../../../docs/guide/03-components-library.md?raw'
import bestPractices from '../../../docs/guide/06-best-practices.md?raw'
import { MDXProvider } from './mdx/MDXProvider'
import MdxDemo from './pages/MdxDemo.mdx'
// Загружаем модульные документы как сырой markdown
const moduleDocsRaw = import.meta.glob('../../../docs/modules/*.md', { as: 'raw', eager: true }) as Record<string, string>
const moduleDocsByName: Record<string, string> = Object.fromEntries(
  Object.entries(moduleDocsRaw).map(([path, content]) => [path.split('/').pop()!, content])
)

function DocPage({ md }: { md: string }) {
  return (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <div className="row" style={{ alignItems: 'flex-start' }}>
        <div style={{ flex: '1 1 720px' }}>
          <GlassSurface style={{ padding: 24 }}>
            <div className="markdown">
              <ReactMarkdown
                rehypePlugins={[rehypeHighlight, rehypeSlug, [rehypeAutolinkHeadings, { behavior: 'wrap', properties: { className: 'anchor' } }]]}
                components={{
                  pre: ({ node, ...props }) => <pre {...props} />,
                  code(props: any) {
                    const { inline, className, children } = props
                    const code = String(children ?? '')
                    if (inline) {
                      return <code className={className} {...props}>{children}</code>
                    }
                    return <CodeBlock className={className} code={code} />
                  },
                }}
              >
                {md}
              </ReactMarkdown>
            </div>
          </GlassSurface>
        </div>
        <aside style={{ position: 'sticky', top: 64, flex: '0 0 280px' }}>
          <GlassSurface style={{ padding: 16 }}>
            <h3 style={{ marginTop: 0 }}>Содержание</h3>
            <Toc />
          </GlassSurface>
        </aside>
      </div>
    </main>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <MDXProvider>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/getting-started" element={<GettingStarted />} />
        <Route path="/core-concepts" element={<CoreConcepts />} />
        <Route path="/components" element={<ComponentsPage />} />
        <Route path="/best-practices" element={<BestPractices />} />
        <Route path="/demo" element={<Demo />} />
        <Route path="/docs" element={<Docs />} />
        <Route path="/docs/mdx-demo" element={<MdxDemo />} />
        <Route path="/docs/getting-started" element={<DocPage md={gettingStarted} />} />
        <Route path="/docs/core-concepts" element={<DocPage md={coreConcepts} />} />
        <Route path="/docs/components" element={<DocPage md={componentsLib} />} />
        <Route path="/docs/best-practices" element={<DocPage md={bestPractices} />} />
        <Route path="/docs/modules/:file" element={<ModuleDocRoute />} />
      </Routes>
      </MDXProvider>
    </BrowserRouter>
  )
}

function ModuleDocRoute() {
  const { file } = useParams()
  const name = file ? decodeURIComponent(file) : ''
  const md = name && moduleDocsByName[name]
  return md ? (
    <DocPage md={md} />
  ) : (
    <main className="container" style={{ padding: '24px 16px 64px' }}>
      <GlassSurface style={{ padding: 24 }}>
        <h2>Не найдено</h2>
        <p>Файл модуля “{name}” отсутствует.</p>
      </GlassSurface>
    </main>
  )
}
