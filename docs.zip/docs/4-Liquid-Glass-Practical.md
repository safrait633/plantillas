# 💻 Liquid Glass - Практическое руководство
*Примеры кода и внедрение*

## 🚀 Быстрый старт

### React компонент
```tsx
import LiquidGlass from 'liquid-glass-react';

function MyButton() {
    return (
        <LiquidGlass
            mode="standard"
            displacementScale={60}
            aberrationIntensity={3}
            onClick={() => console.log('Clicked!')}
        >
            Нажми меня
        </LiquidGlass>
    );
}
```

### CSS версия
```css
.glass-card {
    backdrop-filter: blur(12px);
    background: rgba(255,255,255,0.25);
    border: 1px solid rgba(255,255,255,0.3);
    border-radius: 16px;
    box-shadow: 0 8px 32px rgba(0,0,0,0.1);
}
```

## ⚡ Оптимизация производительности

### Предкомпиляция шейдеров
```typescript
class ShaderManager {
    static async precompile() {
        const shaders = ['liquid-glass', 'displacement'];
        for (const shader of shaders) {
            await this.compileShader(shader);
        }
    }
}
```

### Кэширование displacement maps
```typescript
const cache = new Map<string, ImageData>();

function getDisplacementMap(w: number, h: number, mode: string) {
    const key = `${w}x${h}-${mode}`;
    if (!cache.has(key)) {
        cache.set(key, generateMap(w, h, mode));
    }
    return cache.get(key);
}
```

### Адаптивное качество
```typescript
const quality = {
    ultra: { scale: 1.0, aberration: 1.0 },
    high: { scale: 0.8, aberration: 0.8 },
    medium: { scale: 0.6, aberration: 0.6 },
    low: { scale: 0.4, aberration: 0.4 }
};

function getQualityLevel(fps: number) {
    if (fps >= 55) return quality.ultra;
    if (fps >= 45) return quality.high;
    if (fps >= 35) return quality.medium;
    return quality.low;
}
```

## 🔧 Отладка

### Performance monitoring
```typescript
const monitor = {
    frameStart: 0,
    startFrame() { this.frameStart = performance.now(); },
    endFrame() {
        const time = performance.now() - this.frameStart;
        if (time > 16.67) console.warn(`Slow frame: ${time}ms`);
    }
};
```

## 📚 Полезные ссылки

- [Apple Documentation](https://developer.apple.com/documentation/SwiftUI/Applying-Liquid-Glass-to-custom-views)
- [React Library](https://github.com/rdev/liquid-glass-react)
- [Android Implementation](https://jitpack.io/#Kyant0/AndroidLiquidGlass)

---

*Документ 4/4 серии Liquid Glass*