# Liquid Glass - Testing and QA Guide

Комплексное руководство по тестированию и обеспечению качества Liquid Glass эффектов с автоматизацией, performance тестированием и cross-platform валидацией.

## Содержание

1. [Overview](#overview)
2. [Visual Regression Testing](#visual-regression-testing)
3. [Performance Testing](#performance-testing)
4. [Cross-Browser Compatibility](#cross-browser-compatibility)
5. [Automated Testing Framework](#automated-testing-framework)
6. [CI/CD Integration](#cicd-integration)
7. [Quality Assurance Procedures](#quality-assurance-procedures)

---

## Overview

### Testing Strategy

Liquid Glass эффекты требуют специального подхода к тестированию из-за их визуальной природы и зависимости от производительности GPU. Наша стратегия тестирования включает:

#### 📊 **Типы тестирования:**
- **Visual Regression** - автоматическое сравнение скриншотов
- **Performance Testing** - измерение FPS, GPU time, memory usage
- **Cross-Platform Testing** - валидация на разных устройствах и браузерах
- **Accessibility Testing** - проверка доступности эффектов
- **Integration Testing** - тестирование взаимодействия компонентов
- **Unit Testing** - тестирование отдельных функций и модулей

#### 🔧 **Инструменты тестирования:**
- **Playwright** - E2E тестирование и визуальные тесты
- **Jest** - Unit тестирование JavaScript
- **WebGL Inspector** - анализ WebGL performance
- **Lighthouse** - performance аудит
- **Storybook** - компонентное тестирование
- **Chrome DevTools** - debugging и профилирование

#### 📈 **Метрики качества:**
- **Visual Accuracy** - соответствие design system
- **Performance Benchmarks** - 60 FPS на target устройствах
- **Cross-Platform Consistency** - идентичный вид на всех платформах
- **Accessibility Compliance** - WCAG 2.2 AA
- **Memory Efficiency** - отсутствие утечек памяти
- **Load Time** - быстрая инициализация эффектов

---

## Visual Regression Testing

### Automated Screenshot Comparison

```javascript
// tests/visual/liquid-glass-visual.test.js
import { test, expect } from '@playwright/test';

class LiquidGlassVisualTester {
  constructor(page) {
    this.page = page;
    this.testConfigs = {
      'blur-basic': {
        blur: 10,
        opacity: 0.8,
        viewport: { width: 1200, height: 800 }
      },
      'blur-high': {
        blur: 20,
        opacity: 0.9,
        viewport: { width: 1200, height: 800 }
      },
      'distortion-light': {
        blur: 8,
        opacity: 0.7,
        distortion: 0.1,
        viewport: { width: 1200, height: 800 }
      },
      'mobile-portrait': {
        blur: 6,
        opacity: 0.8,
        viewport: { width: 375, height: 812 }
      },
      'tablet-landscape': {
        blur: 12,
        opacity: 0.85,
        viewport: { width: 1024, height: 768 }
      }
    };
  }

  async setupLiquidGlass(config) {
    await this.page.setViewportSize(config.viewport);
    
    // Инициализируем Liquid Glass с тестовыми параметрами
    await this.page.evaluate((config) => {
      window.liquidGlass = new LiquidGlass({
        blur: config.blur,
        opacity: config.opacity,
        distortion: config.distortion || 0,
        animation: false // Отключаем анимации для стабильных скриншотов
      });
    }, config);

    // Ждем инициализации
    await this.page.waitForFunction(() => window.liquidGlass && window.liquidGlass.isReady);
  }

  async captureVariations(testName) {
    const config = this.testConfigs[testName];
    await this.setupLiquidGlass(config);

    // Основной скриншот
    await expect(this.page).toHaveScreenshot(`${testName}-base.png`);

    // Скриншот с hover состоянием
    await this.page.hover('.liquid-glass-element');
    await this.page.waitForTimeout(500); // Ждем завершения hover эффекта
    await expect(this.page).toHaveScreenshot(`${testName}-hover.png`);

    // Скриншот с активным состоянием
    await this.page.click('.liquid-glass-element');
    await this.page.waitForTimeout(300);
    await expect(this.page).toHaveScreenshot(`${testName}-active.png`);

    // Скриншот с disabled состоянием
    await this.page.evaluate(() => {
      document.querySelector('.liquid-glass-element').setAttribute('disabled', 'true');
    });
    await this.page.waitForTimeout(200);
    await expect(this.page).toHaveScreenshot(`${testName}-disabled.png`);
  }

  async testColorVariations(testName) {
    const colors = ['blue', 'green', 'purple', 'orange', 'red'];
    
    for (const color of colors) {
      await this.page.evaluate((color) => {
        window.liquidGlass.setTint(color);
      }, color);
      
      await this.page.waitForTimeout(100);
      await expect(this.page).toHaveScreenshot(`${testName}-${color}.png`);
    }
  }

  async testDarkModeCompatibility(testName) {
    // Light mode
    await this.page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'light');
    });
    await this.page.waitForTimeout(200);
    await expect(this.page).toHaveScreenshot(`${testName}-light-mode.png`);

    // Dark mode
    await this.page.evaluate(() => {
      document.documentElement.setAttribute('data-theme', 'dark');
    });
    await this.page.waitForTimeout(200);
    await expect(this.page).toHaveScreenshot(`${testName}-dark-mode.png`);
  }
}

// Основные visual тесты
test.describe('Liquid Glass Visual Regression', () => {
  let visualTester;

  test.beforeEach(async ({ page }) => {
    visualTester = new LiquidGlassVisualTester(page);
    await page.goto('/test-pages/liquid-glass-playground');
  });

  test('Basic blur variations', async () => {
    await visualTester.captureVariations('blur-basic');
    await visualTester.captureVariations('blur-high');
  });

  test('Distortion effects', async () => {
    await visualTester.captureVariations('distortion-light');
  });

  test('Responsive layouts', async () => {
    await visualTester.captureVariations('mobile-portrait');
    await visualTester.captureVariations('tablet-landscape');
  });

  test('Color tint variations', async () => {
    await visualTester.testColorVariations('blur-basic');
  });

  test('Theme compatibility', async () => {
    await visualTester.testDarkModeCompatibility('blur-basic');
  });

  test('High contrast mode', async ({ page }) => {
    // Эмулируем high contrast mode
    await page.emulateMedia({ colorScheme: 'dark', reducedMotion: 'reduce' });
    await page.addStyleTag({
      content: `
        @media (prefers-contrast: high) {
          .liquid-glass-element {
            --glass-opacity: 0.95;
            --glass-blur: 5px;
          }
        }
      `
    });
    
    await visualTester.setupLiquidGlass(visualTester.testConfigs['blur-basic']);
    await expect(page).toHaveScreenshot('high-contrast-mode.png');
  });
});

// Performance visual тесты
test.describe('Performance Visual Tests', () => {
  test('Animation frame consistency', async ({ page }) => {
    await page.goto('/test-pages/liquid-glass-animation');
    
    // Записываем кадры анимации
    const frames = [];
    for (let i = 0; i < 10; i++) {
      await page.evaluate((frame) => {
        window.liquidGlass.setAnimationProgress(frame / 9);
      }, i);
      
      await page.waitForTimeout(16); // ~60fps
      const screenshot = await page.screenshot();
      frames.push(screenshot);
    }
    
    // Проверяем плавность анимации
    for (let i = 0; i < frames.length; i++) {
      await expect(page).toHaveScreenshot(`animation-frame-${i}.png`);
    }
  });

  test('Stress test visual stability', async ({ page }) => {
    await page.goto('/test-pages/liquid-glass-stress');
    
    // Создаем множество элементов с Liquid Glass
    await page.evaluate(() => {
      for (let i = 0; i < 50; i++) {
        const element = document.createElement('div');
        element.className = 'liquid-glass-element';
        element.style.cssText = `
          width: 100px;
          height: 100px;
          position: absolute;
          left: ${Math.random() * 800}px;
          top: ${Math.random() * 600}px;
        `;
        document.body.appendChild(element);
        new LiquidGlass(element);
      }
    });
    
    await page.waitForTimeout(1000); // Ждем стабилизации
    await expect(page).toHaveScreenshot('stress-test-50-elements.png');
  });
});
```

### Advanced Visual Testing

```javascript
// tests/visual/advanced-visual.test.js
class AdvancedVisualTester {
  constructor(page) {
    this.page = page;
    this.threshold = 0.1; // 0.1% pixel difference tolerance
  }

  async compareWithTolerance(screenshotName, options = {}) {
    const screenshot = await this.page.screenshot();
    
    // Используем Playwright's built-in visual comparison с настройками
    await expect(this.page).toHaveScreenshot(screenshotName, {
      threshold: options.threshold || this.threshold,
      maxDiffPixels: options.maxDiffPixels || 100,
      animations: 'disabled',
      ...options
    });
  }

  async testBrowserSpecificRendering() {
    const browsers = ['chromium', 'firefox', 'webkit'];
    
    for (const browserName of browsers) {
      await this.page.evaluate(() => {
        // Применяем browser-specific стили если нужно
        document.body.setAttribute('data-browser', navigator.userAgent);
      });
      
      await this.compareWithTolerance(`cross-browser-${browserName}.png`);
    }
  }

  async testRetinaDisplay() {
    // Эмулируем Retina display
    await this.page.setViewportSize({ width: 1200, height: 800 });
    await this.page.emulateMedia({ devicePixelRatio: 2 });
    
    await this.compareWithTolerance('retina-display.png', {
      threshold: 0.05 // Более строгий threshold для Retina
    });
  }

  async testPrintStyles() {
    // Тестируем как выглядит в print режиме
    await this.page.emulateMedia({ media: 'print' });
    await this.compareWithTolerance('print-mode.png');
  }

  async captureAnimationSequence(duration = 1000, fps = 30) {
    const frames = [];
    const frameInterval = 1000 / fps;
    const totalFrames = Math.floor(duration / frameInterval);
    
    for (let i = 0; i < totalFrames; i++) {
      const progress = i / (totalFrames - 1);
      
      await this.page.evaluate((progress) => {
        if (window.liquidGlass && window.liquidGlass.setAnimationProgress) {
          window.liquidGlass.setAnimationProgress(progress);
        }
      }, progress);
      
      await this.page.waitForTimeout(frameInterval);
      
      const screenshot = await this.page.screenshot();
      frames.push({
        frame: i,
        progress: progress,
        screenshot: screenshot
      });
    }
    
    return frames;
  }

  async validateAnimationSmoothness(frames) {
    // Анализируем плавность анимации
    const smoothnessMetrics = {
      frameDrops: 0,
      inconsistentTiming: 0,
      visualJumps: 0
    };
    
    for (let i = 1; i < frames.length; i++) {
      const currentFrame = frames[i];
      const previousFrame = frames[i - 1];
      
      // Здесь можно добавить логику анализа различий между кадрами
      // Например, используя image comparison библиотеки
    }
    
    return smoothnessMetrics;
  }
}

test.describe('Advanced Visual Testing', () => {
  let advancedTester;

  test.beforeEach(async ({ page }) => {
    advancedTester = new AdvancedVisualTester(page);
    await page.goto('/test-pages/liquid-glass-advanced');
  });

  test('Cross-browser rendering consistency', async () => {
    await advancedTester.testBrowserSpecificRendering();
  });

  test('High DPI display support', async () => {
    await advancedTester.testRetinaDisplay();
  });

  test('Print media compatibility', async () => {
    await advancedTester.testPrintStyles();
  });

  test('Animation sequence validation', async () => {
    const frames = await advancedTester.captureAnimationSequence(2000, 60);
    const metrics = await advancedTester.validateAnimationSmoothness(frames);
    
    expect(metrics.frameDrops).toBeLessThan(3);
    expect(metrics.visualJumps).toBeLessThan(1);
  });
});
```

---

## Performance Testing

### Automated Performance Monitoring

```javascript
// tests/performance/liquid-glass-performance.test.js
import { test, expect } from '@playwright/test';

class PerformanceTester {
  constructor(page) {
    this.page = page;
    this.metrics = {
      fps: [],
      frameTime: [],
      gpuTime: [],
      memoryUsage: [],
      cpuUsage: []
    };
  }

  async startPerformanceMonitoring() {
    // Включаем performance timeline
    await this.page.evaluate(() => {
      window.performanceData = [];
      window.startTime = performance.now();
      
      // Monitor FPS
      let frameCount = 0;
      let lastTime = performance.now();
      
      function measureFPS() {
        const now = performance.now();
        frameCount++;
        
        if (now - lastTime >= 1000) {
          const fps = Math.round((frameCount * 1000) / (now - lastTime));
          window.performanceData.push({
            type: 'fps',
            value: fps,
            timestamp: now - window.startTime
          });
          
          frameCount = 0;
          lastTime = now;
        }
        
        requestAnimationFrame(measureFPS);
      }
      
      requestAnimationFrame(measureFPS);
      
      // Monitor memory usage
      if (performance.memory) {
        setInterval(() => {
          window.performanceData.push({
            type: 'memory',
            value: performance.memory.usedJSHeapSize / 1024 / 1024, // MB
            timestamp: performance.now() - window.startTime
          });
        }, 1000);
      }
    });
  }

  async collectPerformanceData() {
    const data = await this.page.evaluate(() => window.performanceData);
    
    data.forEach(entry => {
      if (this.metrics[entry.type]) {
        this.metrics[entry.type].push(entry.value);
      }
    });
    
    return data;
  }

  calculateMetrics() {
    const results = {};
    
    Object.keys(this.metrics).forEach(metric => {
      const values = this.metrics[metric];
      if (values.length > 0) {
        results[metric] = {
          min: Math.min(...values),
          max: Math.max(...values),
          avg: values.reduce((a, b) => a + b, 0) / values.length,
          p95: this.percentile(values, 95),
          p99: this.percentile(values, 99)
        };
      }
    });
    
    return results;
  }

  percentile(arr, p) {
    const sorted = [...arr].sort((a, b) => a - b);
    const index = Math.ceil(sorted.length * (p / 100)) - 1;
    return sorted[index];
  }

  async benchmarkConfiguration(config) {
    await this.page.evaluate((config) => {
      if (window.liquidGlass) {
        window.liquidGlass.updateConfig(config);
      }
    }, config);

    await this.startPerformanceMonitoring();
    
    // Выполняем типичные операции пользователя
    await this.simulateUserInteractions();
    
    // Ждем сбора данных
    await this.page.waitForTimeout(5000);
    
    const performanceData = await this.collectPerformanceData();
    return this.calculateMetrics();
  }

  async simulateUserInteractions() {
    // Hover эффекты
    for (let i = 0; i < 10; i++) {
      await this.page.hover('.liquid-glass-element', { 
        position: { x: 50 + i * 10, y: 50 + i * 10 } 
      });
      await this.page.waitForTimeout(100);
    }

    // Click interactions
    for (let i = 0; i < 5; i++) {
      await this.page.click('.liquid-glass-button');
      await this.page.waitForTimeout(200);
    }

    // Scroll с sticky элементами
    await this.page.evaluate(() => {
      window.scrollTo({ top: 1000, behavior: 'smooth' });
    });
    await this.page.waitForTimeout(1000);

    await this.page.evaluate(() => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    await this.page.waitForTimeout(1000);
  }

  async stressTest(elementCount = 50) {
    await this.page.evaluate((count) => {
      // Создаем много элементов с Liquid Glass
      for (let i = 0; i < count; i++) {
        const element = document.createElement('div');
        element.className = 'liquid-glass-stress-element';
        element.style.cssText = `
          width: 80px;
          height: 80px;
          position: absolute;
          left: ${Math.random() * (window.innerWidth - 80)}px;
          top: ${Math.random() * (window.innerHeight - 80)}px;
          backdrop-filter: blur(10px);
          background: rgba(255, 255, 255, 0.1);
          border-radius: 8px;
        `;
        document.body.appendChild(element);
      }
    }, elementCount);

    await this.startPerformanceMonitoring();
    await this.page.waitForTimeout(3000);
    
    return await this.collectPerformanceData();
  }
}

test.describe('Performance Testing', () => {
  let performanceTester;

  test.beforeEach(async ({ page }) => {
    performanceTester = new PerformanceTester(page);
    await page.goto('/test-pages/liquid-glass-performance');
  });

  test('Baseline performance benchmarks', async () => {
    const baselineConfig = {
      blur: 10,
      opacity: 0.8,
      quality: 'high'
    };

    const metrics = await performanceTester.benchmarkConfiguration(baselineConfig);
    
    // Проверяем соответствие performance targets
    expect(metrics.fps.avg).toBeGreaterThan(55); // Средний FPS > 55
    expect(metrics.fps.p95).toBeGreaterThan(45);  // 95% времени FPS > 45
    expect(metrics.memory.max).toBeLessThan(100); // Пик памяти < 100MB
  });

  test('High quality vs Performance comparison', async () => {
    const highQualityConfig = {
      blur: 20,
      opacity: 0.9,
      quality: 'high',
      samples: 25
    };

    const performanceConfig = {
      blur: 8,
      opacity: 0.8,
      quality: 'performance',
      samples: 9
    };

    const highQualityMetrics = await performanceTester.benchmarkConfiguration(highQualityConfig);
    const performanceMetrics = await performanceTester.benchmarkConfiguration(performanceConfig);

    // Performance config должен быть быстрее
    expect(performanceMetrics.fps.avg).toBeGreaterThan(highQualityMetrics.fps.avg);
    expect(performanceMetrics.memory.avg).toBeLessThan(highQualityMetrics.memory.avg);
  });

  test('Mobile device simulation', async ({ page }) => {
    // Эмулируем слабое мобильное устройство
    await page.emulate({
      viewport: { width: 375, height: 667 },
      devicePixelRatio: 2,
      isMobile: true,
      hasTouch: true,
      slowMo: 100 // Замедляем для эмуляции слабого CPU
    });

    const mobileConfig = {
      blur: 6,
      opacity: 0.7,
      quality: 'performance'
    };

    const metrics = await performanceTester.benchmarkConfiguration(mobileConfig);
    
    // Более мягкие требования для мобильных устройств
    expect(metrics.fps.avg).toBeGreaterThan(40);
    expect(metrics.fps.p95).toBeGreaterThan(30);
  });

  test('Memory leak detection', async ({ page }) => {
    await performanceTester.startPerformanceMonitoring();
    
    // Создаем и удаляем элементы в цикле
    for (let cycle = 0; cycle < 5; cycle++) {
      await page.evaluate(() => {
        // Создаем элементы
        const elements = [];
        for (let i = 0; i < 20; i++) {
          const element = document.createElement('div');
          element.className = 'liquid-glass-temp';
          document.body.appendChild(element);
          elements.push(new LiquidGlass(element));
        }
        
        // Удаляем элементы
        setTimeout(() => {
          elements.forEach(lg => lg.destroy());
          document.querySelectorAll('.liquid-glass-temp').forEach(el => el.remove());
        }, 1000);
      });
      
      await page.waitForTimeout(2000);
    }
    
    const data = await performanceTester.collectPerformanceData();
    const memoryData = data.filter(d => d.type === 'memory');
    
    // Проверяем, что память не растет постоянно
    const initialMemory = memoryData[0]?.value || 0;
    const finalMemory = memoryData[memoryData.length - 1]?.value || 0;
    const memoryGrowth = finalMemory - initialMemory;
    
    expect(memoryGrowth).toBeLessThan(20); // Рост памяти < 20MB
  });

  test('Stress test with many elements', async () => {
    const stressData = await performanceTester.stressTest(100);
    const fpsData = stressData.filter(d => d.type === 'fps');
    
    if (fpsData.length > 0) {
      const avgFPS = fpsData.reduce((sum, d) => sum + d.value, 0) / fpsData.length;
      expect(avgFPS).toBeGreaterThan(25); // Минимум 25 FPS даже со 100 элементами
    }
  });
});
```

---

## Подробные руководства в отдельных документах

Для полного покрытия Testing и QA, создам специализированные документы:

### 📋 **Testing документы:**
1. **Liquid-Glass-Testing-Cross-Browser.md** - Cross-browser совместимость
2. **Liquid-Glass-Testing-Automation.md** - Автоматизация тестирования
3. **Liquid-Glass-Testing-CI-CD.md** - CI/CD интеграция

Это обеспечит полное покрытие всех аспектов тестирования Liquid Glass эффектов! 🧪✅

**Следующий шаг:** Создать первый специализированный документ по Cross-Browser тестированию?