# Liquid Glass - Платформо-специфичная документация

Углубленный анализ особенностей реализации Liquid Glass для каждой платформы с учетом platform guidelines и best practices.

## Содержание

1. [iOS/macOS - Human Interface Guidelines](#iosmacos---human-interface-guidelines)
2. [Android - Material Design 3](#android---material-design-3)
3. [Web - W3C Standards](#web---w3c-standards)
4. [Flutter - Design Language](#flutter---design-language)
5. [React Native - Cross-Platform](#react-native---cross-platform)
6. [Desktop - Electron/Tauri](#desktop---electrontauri)
7. [Кроссплатформенная совместимость](#кроссплатформенная-совместимость)

---

## iOS/macOS - Human Interface Guidelines

### Интеграция с системным дизайном

#### Использование системных материалов

```swift
// Системные материалы Apple
enum SystemMaterial {
    case ultraThin      // Очень тонкий материал
    case thin           // Тонкий материал
    case regular        // Обычный материал
    case thick          // Толстый материал
    case ultraThick     // Очень толстый материал
}

struct AdaptiveGlassCard: View {
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        VStack {
            Text("Системный Liquid Glass")
                .foregroundColor(.primary)
        }
        .padding(20)
        .background(adaptiveMaterial, in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(.quaternary, lineWidth: 0.5)
        )
    }
    
    private var adaptiveMaterial: Material {
        switch colorScheme {
        case .light:
            return .ultraThinMaterial
        case .dark:
            return .thinMaterial
        @unknown default:
            return .regularMaterial
        }
    }
}
```

#### Семантические цвета

```swift
extension Color {
    // Адаптивные цвета для Liquid Glass
    static let liquidGlassPrimary = Color(.systemBackground).opacity(0.8)
    static let liquidGlassSecondary = Color(.secondarySystemBackground).opacity(0.9)
    static let liquidGlassAccent = Color(.tintColor).opacity(0.3)
    
    // Для темной темы
    static let liquidGlassDarkPrimary = Color(.systemBackground).opacity(0.6)
    static let liquidGlassDarkSecondary = Color(.secondarySystemBackground).opacity(0.7)
}

struct SemanticGlassButton: View {
    var body: some View {
        Button("Семантическая кнопка") {
            // Action
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 8))
        .foregroundColor(.primary)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(.separator, lineWidth: 0.5)
        )
    }
}
```

#### Dynamic Type поддержка

```swift
struct AccessibleGlassCard: View {
    @Environment(\.dynamicTypeSize) var dynamicTypeSize
    
    var body: some View {
        VStack(spacing: adaptiveSpacing) {
            Text("Заголовок")
                .font(.headline)
            Text("Описание")
                .font(.body)
        }
        .padding(adaptivePadding)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: adaptiveCornerRadius))
    }
    
    private var adaptiveSpacing: CGFloat {
        switch dynamicTypeSize {
        case .xSmall, .small, .medium:
            return 8
        case .large, .xLarge:
            return 12
        case .xxLarge, .xxxLarge:
            return 16
        default:
            return 20
        }
    }
    
    private var adaptivePadding: CGFloat {
        dynamicTypeSize.isAccessibilitySize ? 24 : 16
    }
    
    private var adaptiveCornerRadius: CGFloat {
        dynamicTypeSize.isAccessibilitySize ? 20 : 12
    }
}
```

#### Accessibility

```swift
struct AccessibleGlassButton: View {
    let title: String
    let action: () -> Void
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.body.weight(.medium))
                .foregroundColor(.primary)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 8))
        .accessibilityLabel(title)
        .accessibilityRole(.button)
        .accessibilityAddTraits(.isButton)
        .accessibilityRemoveTraits(.isStaticText)
        .accessibilityAction(.default) {
            action()
        }
    }
}
```

#### Respect для Reduce Motion

```swift
struct MotionSensitiveGlassCard: View {
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    @State private var isVisible = false
    
    var body: some View {
        VStack {
            Text("Motion-Aware Card")
        }
        .padding(20)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .scaleEffect(isVisible ? 1 : 0.8)
        .opacity(isVisible ? 1 : 0)
        .animation(
            reduceMotion ? .none : .spring(response: 0.6, dampingFraction: 0.8),
            value: isVisible
        )
        .onAppear {
            isVisible = true
        }
    }
}
```

### Платформо-специфичные особенности macOS

```swift
#if os(macOS)
struct MacOSGlassWindow: View {
    var body: some View {
        VStack {
            // Контент
        }
        .frame(minWidth: 400, minHeight: 300)
        .background(.ultraThinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(.quaternary, lineWidth: 1)
        )
    }
}

extension NSWindow {
    func setupLiquidGlassAppearance() {
        // Прозрачность окна
        self.isOpaque = false
        self.backgroundColor = NSColor.clear
        
        // Эффект размытия
        let visualEffect = NSVisualEffectView()
        visualEffect.material = .sidebar
        visualEffect.blendingMode = .behindWindow
        visualEffect.state = .active
        
        self.contentView = visualEffect
    }
}
#endif
```

---

## Android - Material Design 3

### Material You интеграция

#### Dynamic Color

```kotlin
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val colorScheme = MaterialTheme.colorScheme
    
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = colorScheme.surfaceVariant.copy(alpha = 0.8f)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = colorScheme.outline.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        )
    ) {
        Box(
            modifier = Modifier
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            colorScheme.surface.copy(alpha = 0.9f),
                            colorScheme.surface.copy(alpha = 0.7f)
                        )
                    )
                )
                .padding(16.dp)
        ) {
            content()
        }
    }
}
```

#### Adaptive Themes

```kotlin
@Composable
fun AdaptiveLiquidGlassTheme(
    content: @Composable () -> Unit
) {
    val context = LocalContext.current
    val isDynamicColorSupported = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S
    
    val colorScheme = when {
        isDynamicColorSupported -> {
            val dynamicColorScheme = if (isSystemInDarkTheme()) {
                dynamicDarkColorScheme(context)
            } else {
                dynamicLightColorScheme(context)
            }
            
            // Адаптируем для Liquid Glass
            dynamicColorScheme.copy(
                surface = dynamicColorScheme.surface.copy(alpha = 0.85f),
                surfaceVariant = dynamicColorScheme.surfaceVariant.copy(alpha = 0.9f)
            )
        }
        else -> {
            if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()
        }
    }
    
    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}
```

#### Motion System

```kotlin
@Composable
fun MaterialMotionGlassCard(
    visible: Boolean,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val transition = updateTransition(targetState = visible, label = "card_transition")
    
    val scale by transition.animateFloat(
        transitionSpec = {
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessLow
            )
        },
        label = "scale"
    ) { isVisible ->
        if (isVisible) 1f else 0.8f
    }
    
    val alpha by transition.animateFloat(
        transitionSpec = {
            tween(
                durationMillis = MotionTokens.DurationMedium2.toInt(),
                easing = MotionTokens.EasingEmphasizedInterpolator
            )
        },
        label = "alpha"
    ) { isVisible ->
        if (isVisible) 1f else 0f
    }
    
    val offsetY by transition.animateDp(
        transitionSpec = {
            spring(
                dampingRatio = Spring.DampingRatioMediumBouncy,
                stiffness = Spring.StiffnessMedium
            )
        },
        label = "offset"
    ) { isVisible ->
        if (isVisible) 0.dp else 32.dp
    }
    
    Card(
        modifier = modifier
            .scale(scale)
            .alpha(alpha)
            .offset(y = offsetY),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f)
        )
    ) {
        content()
    }
}
```

#### Accessibility Support

```kotlin
@Composable
fun AccessibleLiquidGlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val haptic = LocalHapticFeedback.current
    
    Button(
        onClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            onClick()
        },
        modifier = modifier
            .semantics {
                contentDescription = text
                role = Role.Button
            },
        colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
        ),
        shape = RoundedCornerShape(8.dp),
        elevation = ButtonDefaults.buttonElevation(
            defaultElevation = 4.dp,
            pressedElevation = 8.dp
        )
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge
        )
    }
}
```

### Material Design 3 Guidelines для Liquid Glass

```kotlin
object LiquidGlassTokens {
    // Цветовые токены
    val SurfaceContainerLow = ColorSchemeKeyTokens.SurfaceContainerLow
    val SurfaceContainerHigh = ColorSchemeKeyTokens.SurfaceContainerHigh
    val SurfaceContainer = ColorSchemeKeyTokens.SurfaceContainer
    
    // Прозрачность
    val AlphaLevel1 = 0.8f
    val AlphaLevel2 = 0.9f
    val AlphaLevel3 = 0.95f
    
    // Elevation
    val ElevationLevel1 = ElevationTokens.Level1 // 1.dp
    val ElevationLevel2 = ElevationTokens.Level2 // 3.dp
    val ElevationLevel3 = ElevationTokens.Level3 // 6.dp
    
    // Shape
    val CornerSmall = ShapeKeyTokens.CornerSmall   // 4.dp
    val CornerMedium = ShapeKeyTokens.CornerMedium // 8.dp
    val CornerLarge = ShapeKeyTokens.CornerLarge   // 12.dp
}
```

---

## Web - W3C Standards

### CSS Custom Properties System

```css
:root {
  /* Liquid Glass Design System */
  
  /* Blur Values */
  --lg-blur-xs: 2px;
  --lg-blur-sm: 4px;
  --lg-blur-md: 8px;
  --lg-blur-lg: 12px;
  --lg-blur-xl: 16px;
  --lg-blur-2xl: 24px;
  
  /* Alpha Values */
  --lg-alpha-10: 0.1;
  --lg-alpha-15: 0.15;
  --lg-alpha-20: 0.2;
  --lg-alpha-30: 0.3;
  --lg-alpha-40: 0.4;
  
  /* Border Radius */
  --lg-radius-sm: 4px;
  --lg-radius-md: 8px;
  --lg-radius-lg: 12px;
  --lg-radius-xl: 16px;
  --lg-radius-2xl: 24px;
  
  /* Shadows */
  --lg-shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.1);
  --lg-shadow-md: 0 4px 16px rgba(0, 0, 0, 0.1);
  --lg-shadow-lg: 0 8px 32px rgba(0, 0, 0, 0.15);
  --lg-shadow-xl: 0 16px 48px rgba(0, 0, 0, 0.2);
  
  /* Transitions */
  --lg-transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
  --lg-transition-normal: 300ms cubic-bezier(0.4, 0, 0.2, 1);
  --lg-transition-slow: 500ms cubic-bezier(0.23, 1, 0.32, 1);
}

/* Semantic Color Tokens */
:root {
  --lg-surface-primary: rgba(255, 255, 255, var(--lg-alpha-15));
  --lg-surface-secondary: rgba(255, 255, 255, var(--lg-alpha-10));
  --lg-surface-accent: rgba(74, 144, 226, var(--lg-alpha-20));
  --lg-surface-warning: rgba(255, 193, 7, var(--lg-alpha-20));
  --lg-surface-error: rgba(244, 67, 54, var(--lg-alpha-20));
  --lg-surface-success: rgba(76, 175, 80, var(--lg-alpha-20));
  
  --lg-border-primary: rgba(255, 255, 255, var(--lg-alpha-30));
  --lg-border-secondary: rgba(255, 255, 255, var(--lg-alpha-20));
}

/* Dark theme adaptation */
@media (prefers-color-scheme: dark) {
  :root {
    --lg-surface-primary: rgba(0, 0, 0, var(--lg-alpha-30));
    --lg-surface-secondary: rgba(0, 0, 0, var(--lg-alpha-20));
    --lg-border-primary: rgba(255, 255, 255, var(--lg-alpha-20));
    --lg-border-secondary: rgba(255, 255, 255, var(--lg-alpha-10));
  }
}
```

### Utility Classes System

```css
/* Liquid Glass Utility Classes */

/* Glass Surfaces */
.lg-surface-1 {
  backdrop-filter: blur(var(--lg-blur-md));
  background: var(--lg-surface-primary);
  border: 1px solid var(--lg-border-primary);
}

.lg-surface-2 {
  backdrop-filter: blur(var(--lg-blur-lg));
  background: var(--lg-surface-secondary);
  border: 1px solid var(--lg-border-secondary);
}

.lg-surface-3 {
  backdrop-filter: blur(var(--lg-blur-xl));
  background: var(--lg-surface-accent);
  border: 1px solid var(--lg-border-primary);
}

/* Interactive States */
.lg-interactive {
  transition: all var(--lg-transition-normal);
  cursor: pointer;
}

.lg-interactive:hover {
  transform: translateY(-2px);
  box-shadow: var(--lg-shadow-lg);
  backdrop-filter: blur(var(--lg-blur-xl));
}

.lg-interactive:active {
  transform: translateY(0);
  transition-duration: 100ms;
}

/* Rounded Corners */
.lg-rounded-sm { border-radius: var(--lg-radius-sm); }
.lg-rounded-md { border-radius: var(--lg-radius-md); }
.lg-rounded-lg { border-radius: var(--lg-radius-lg); }
.lg-rounded-xl { border-radius: var(--lg-radius-xl); }
.lg-rounded-2xl { border-radius: var(--lg-radius-2xl); }

/* Shadows */
.lg-shadow-sm { box-shadow: var(--lg-shadow-sm); }
.lg-shadow-md { box-shadow: var(--lg-shadow-md); }
.lg-shadow-lg { box-shadow: var(--lg-shadow-lg); }
.lg-shadow-xl { box-shadow: var(--lg-shadow-xl); }
```

### Progressive Enhancement

```css
/* Base styles without backdrop-filter */
.glass-card {
  background: rgba(255, 255, 255, 0.9);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: var(--lg-radius-lg);
  box-shadow: var(--lg-shadow-md);
}

/* Enhanced styles for supporting browsers */
@supports (backdrop-filter: blur(1px)) {
  .glass-card {
    backdrop-filter: blur(var(--lg-blur-lg));
    background: var(--lg-surface-primary);
  }
}

/* Fallback for older browsers */
@supports not (backdrop-filter: blur(1px)) {
  .glass-card {
    background: rgba(255, 255, 255, 0.95);
    border: 2px solid rgba(255, 255, 255, 0.5);
  }
}
```

### Accessibility Features

```css
/* Respect user preferences */
@media (prefers-reduced-motion: reduce) {
  .lg-interactive {
    transition: none;
  }
  
  .lg-animated {
    animation: none;
  }
}

@media (prefers-contrast: high) {
  .lg-surface-1,
  .lg-surface-2,
  .lg-surface-3 {
    backdrop-filter: none;
    background: rgba(255, 255, 255, 0.95);
    border: 2px solid rgba(0, 0, 0, 0.8);
  }
  
  @media (prefers-color-scheme: dark) {
    .lg-surface-1,
    .lg-surface-2,
    .lg-surface-3 {
      background: rgba(0, 0, 0, 0.95);
      border: 2px solid rgba(255, 255, 255, 0.8);
    }
  }
}

/* Focus management */
.lg-interactive:focus-visible {
  outline: 2px solid currentColor;
  outline-offset: 2px;
}
```

### Performance Optimizations

```css
/* GPU Layer Promotion */
.lg-optimized {
  will-change: transform, opacity;
  transform: translateZ(0);
  backface-visibility: hidden;
}

/* Containment */
.lg-container {
  contain: layout style paint;
}

/* Critical path optimization */
.lg-above-fold {
  contain: strict;
}

/* Resource hints in HTML */
/*
<link rel="preload" href="/fonts/inter.woff2" as="font" type="font/woff2" crossorigin>
<link rel="prefetch" href="/css/liquid-glass-extended.css">
*/
```

---

## Flutter - Design Language

### Material Design 3 в Flutter

```dart
class LiquidGlassTheme {
  static ThemeData getLightTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF4A90E2),
        brightness: Brightness.light,
      ).copyWith(
        surface: const Color(0xFF4A90E2).withOpacity(0.1),
        surfaceVariant: Colors.white.withOpacity(0.8),
      ),
      cardTheme: CardTheme(
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        color: Colors.white.withOpacity(0.1),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.white.withOpacity(0.2),
          foregroundColor: Colors.black87,
          elevation: 4,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
  
  static ThemeData getDarkTheme() {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF4A90E2),
        brightness: Brightness.dark,
      ).copyWith(
        surface: Colors.black.withOpacity(0.3),
        surfaceVariant: Colors.black.withOpacity(0.6),
      ),
      cardTheme: CardTheme(
        elevation: 8,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        color: Colors.black.withOpacity(0.3),
      ),
    );
  }
}
```

### Adaptive Design для разных платформ

```dart
class AdaptiveLiquidGlassCard extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  
  const AdaptiveLiquidGlassCard({
    Key? key,
    required this.child,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Platform.isIOS || Platform.isMacOS
        ? _buildCupertinoCard(context)
        : _buildMaterialCard(context);
  }
  
  Widget _buildCupertinoCard(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: CupertinoColors.systemBackground.withOpacity(0.8),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: CupertinoColors.separator.withOpacity(0.3),
          ),
          boxShadow: [
            BoxShadow(
              color: CupertinoColors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
  
  Widget _buildMaterialCard(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: child,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
```

### Responsive Design

```dart
class ResponsiveLiquidGlassLayout extends StatelessWidget {
  final List<Widget> children;
  
  const ResponsiveLiquidGlassLayout({
    Key? key,
    required this.children,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth > 1200) {
          return _buildDesktopLayout();
        } else if (constraints.maxWidth > 800) {
          return _buildTabletLayout();
        } else {
          return _buildMobileLayout();
        }
      },
    );
  }
  
  Widget _buildDesktopLayout() {
    return GridView.count(
      crossAxisCount: 3,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      children: children.map((child) => 
        AdaptiveLiquidGlassCard(child: child)
      ).toList(),
    );
  }
  
  Widget _buildTabletLayout() {
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      children: children.map((child) => 
        AdaptiveLiquidGlassCard(child: child)
      ).toList(),
    );
  }
  
  Widget _buildMobileLayout() {
    return ListView.separated(
      itemCount: children.length,
      separatorBuilder: (context, index) => const SizedBox(height: 8),
      itemBuilder: (context, index) => 
        AdaptiveLiquidGlassCard(child: children[index]),
    );
  }
}
```

---

## React Native - Cross-Platform

### Platform-Specific Implementations

```jsx
import { Platform, StyleSheet } from 'react-native';
import { BlurView } from '@react-native-community/blur';

const LiquidGlassCard = ({ children, style }) => {
  if (Platform.OS === 'ios') {
    return (
      <BlurView blurType="light" blurAmount={10} style={[styles.card, style]}>
        <View style={styles.border}>
          {children}
        </View>
      </BlurView>
    );
  }
  
  // Android fallback
  return (
    <View style={[styles.cardAndroid, style]}>
      {children}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
  },
  cardAndroid: {
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    borderRadius: 16,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  border: {
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: 'rgba(255, 255, 255, 0.3)',
    borderRadius: 16,
    padding: 16,
  },
});
```

### Adaptive Safe Areas

```jsx
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const AdaptiveLiquidGlassHeader = ({ title }) => {
  const insets = useSafeAreaInsets();
  
  return (
    <BlurView 
      blurType="light" 
      blurAmount={20}
      style={[
        styles.header,
        {
          paddingTop: insets.top + 16,
          paddingLeft: Math.max(insets.left, 16),
          paddingRight: Math.max(insets.right, 16),
        }
      ]}
    >
      <Text style={styles.title}>{title}</Text>
    </BlurView>
  );
};

const styles = StyleSheet.create({
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    zIndex: 1000,
  },
  title: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    textAlign: 'center',
    paddingBottom: 16,
  },
});
```

---

## Desktop - Electron/Tauri

### Electron с нативными эффектами

```javascript
// main.js
const { app, BrowserWindow } = require('electron');

function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    transparent: true,
    frame: false,
    vibrancy: 'under-window', // macOS
    backgroundMaterial: 'acrylic', // Windows
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
    },
  });
  
  // Windows specific
  if (process.platform === 'win32') {
    win.setBackgroundMaterial('acrylic');
  }
  
  win.loadFile('index.html');
}

app.whenReady().then(createWindow);
```

```css
/* renderer CSS */
body {
  background: transparent;
  -webkit-app-region: drag;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
}

.titlebar {
  height: 30px;
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.2);
  -webkit-app-region: drag;
}

.content {
  -webkit-app-region: no-drag;
  padding: 20px;
}

.glass-window {
  background: rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(20px);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}
```

### Tauri с системной интеграцией

```rust
// src-tauri/src/main.rs
use tauri::{Manager, Window};

#[tauri::command]
fn set_window_effects(window: Window) {
    #[cfg(target_os = "macos")]
    {
        use cocoa::appkit::{NSWindow, NSWindowTitleVisibility};
        use cocoa::base::id;
        
        unsafe {
            let ns_window = window.ns_window().unwrap() as id;
            ns_window.setTitlebarAppearsTransparent_(true);
            ns_window.setTitleVisibility_(NSWindowTitleVisibility::NSWindowTitleHidden);
        }
    }
    
    #[cfg(target_os = "windows")]
    {
        use windows::Win32::UI::Shell::DwmExtendFrameIntoClientArea;
        // Windows Acrylic implementation
    }
}

fn main() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![set_window_effects])
        .setup(|app| {
            let window = app.get_window("main").unwrap();
            set_window_effects(window);
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
```

---

## Кроссплатформенная совместимость

### Design Token System

```json
{
  "liquidGlass": {
    "blur": {
      "xs": { "value": "2px" },
      "sm": { "value": "4px" },
      "md": { "value": "8px" },
      "lg": { "value": "12px" },
      "xl": { "value": "16px" },
      "2xl": { "value": "24px" }
    },
    "opacity": {
      "10": { "value": "0.1" },
      "15": { "value": "0.15" },
      "20": { "value": "0.2" },
      "30": { "value": "0.3" },
      "40": { "value": "0.4" }
    },
    "radius": {
      "sm": { "value": "4px" },
      "md": { "value": "8px" },
      "lg": { "value": "12px" },
      "xl": { "value": "16px" },
      "2xl": { "value": "24px" }
    },
    "elevation": {
      "1": { "value": "0 2px 8px rgba(0, 0, 0, 0.1)" },
      "2": { "value": "0 4px 16px rgba(0, 0, 0, 0.1)" },
      "3": { "value": "0 8px 32px rgba(0, 0, 0, 0.15)" },
      "4": { "value": "0 16px 48px rgba(0, 0, 0, 0.2)" }
    }
  }
}
```

### Feature Detection

```javascript
// Feature detection utility
class LiquidGlassSupport {
  static hasBackdropFilter() {
    return CSS.supports('backdrop-filter', 'blur(1px)') ||
           CSS.supports('-webkit-backdrop-filter', 'blur(1px)');
  }
  
  static hasColorSchemeSupport() {
    return window.matchMedia('(prefers-color-scheme: dark)').matches !== undefined;
  }
  
  static hasReducedMotionSupport() {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  }
  
  static hasHighContrastSupport() {
    return window.matchMedia('(prefers-contrast: high)').matches;
  }
  
  static getOptimalConfiguration() {
    return {
      useBackdropFilter: this.hasBackdropFilter(),
      respectColorScheme: this.hasColorSchemeSupport(),
      reduceAnimations: this.hasReducedMotionSupport(),
      highContrast: this.hasHighContrastSupport(),
    };
  }
}

// Usage
const config = LiquidGlassSupport.getOptimalConfiguration();
console.log('Liquid Glass Configuration:', config);
```

### Migration Utilities

```typescript
interface PlatformAdapter {
  platform: 'ios' | 'android' | 'web' | 'desktop';
  adaptBackdropFilter(value: number): string;
  adaptBorderRadius(value: number): string;
  adaptElevation(level: number): any;
}

class IOSAdapter implements PlatformAdapter {
  platform = 'ios' as const;
  
  adaptBackdropFilter(value: number): string {
    return `.ultraThinMaterial`; // SwiftUI Material
  }
  
  adaptBorderRadius(value: number): string {
    return `${value}px`;
  }
  
  adaptElevation(level: number): any {
    return {
      shadowOffset: { width: 0, height: level * 2 },
      shadowOpacity: 0.1,
      shadowRadius: level * 4,
    };
  }
}

class AndroidAdapter implements PlatformAdapter {
  platform = 'android' as const;
  
  adaptBackdropFilter(value: number): string {
    return `blur(${value}px)`;
  }
  
  adaptBorderRadius(value: number): string {
    return `${value}dp`;
  }
  
  adaptElevation(level: number): any {
    return `${level * 2}dp`;
  }
}

class WebAdapter implements PlatformAdapter {
  platform = 'web' as const;
  
  adaptBackdropFilter(value: number): string {
    return `blur(${value}px)`;
  }
  
  adaptBorderRadius(value: number): string {
    return `${value}px`;
  }
  
  adaptElevation(level: number): any {
    return `0 ${level * 2}px ${level * 8}px rgba(0, 0, 0, 0.1)`;
  }
}
```

---

## Заключение

Платформо-специфичная реализация Liquid Glass требует глубокого понимания:

### iOS/macOS
- **Human Interface Guidelines** соблюдение
- **Системные материалы** (.ultraThinMaterial, .regularMaterial)
- **Accessibility** (Dynamic Type, Reduce Motion, VoiceOver)
- **Семантические цвета** адаптивность

### Android
- **Material Design 3** принципы
- **Dynamic Color** поддержка
- **Motion System** integration
- **Accessibility** (TalkBack, высокий контраст)

### Web
- **Progressive Enhancement** подход
- **W3C Standards** соответствие
- **CSS Custom Properties** система
- **Performance** оптимизация

### Cross-Platform
- **Design Tokens** унификация
- **Feature Detection** adaptive загрузка
- **Platform Adapters** абстракция различий

Каждая платформа имеет свои уникальные возможности и ограничения, которые необходимо учитывать при реализации Liquid Glass эффектов.