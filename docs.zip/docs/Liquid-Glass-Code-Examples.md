# Liquid Glass - Примеры кода для всех платформ

Этот документ содержит практические примеры реализации Liquid Glass эффектов на различных платформах и в разных технологиях.

## Содержание

1. [iOS/macOS - Swift/SwiftUI](#ios-macos-swift-swiftui)
2. [Web - CSS](#web-css)
3. [React/JavaScript](#react-javascript)
4. [Android - Kotlin/Jetpack Compose](#android-kotlin-jetpack-compose)
5. [Flutter/Dart](#flutter-dart)
6. [Vue.js](#vue-js)
7. [Angular](#angular)
8. [React Native](#react-native)

---

## iOS/macOS - Swift/SwiftUI

### Базовая стеклянная кнопка

```swift
struct GlassButton: View {
    let title: String
    let action: () -> Void
    @State private var isPressed = false
    
    var body: some View {
        Button(action: action) {
            Text(title)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
        }
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(.white.opacity(0.3), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.1), radius: 8, x: 0, y: 4)
        .scaleEffect(isPressed ? 0.95 : 1.0)
        .onLongPressGesture(minimumDuration: 0, maximumDistance: .infinity) { pressing in
            withAnimation(.easeInOut(duration: 0.1)) {
                isPressed = pressing
            }
        }
    }
}
```

### Стеклянная карточка с контентом

```swift
struct GlassCard<Content: View>: View {
    let content: Content
    
    init(@ViewBuilder content: () -> Content) {
        self.content = content()
    }
    
    var body: some View {
        VStack(spacing: 16) {
            content
        }
        .padding(20)
        .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 16))
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.2), lineWidth: 1)
        )
        .shadow(color: .black.opacity(0.1), radius: 20, x: 0, y: 10)
    }
}

// Использование
GlassCard {
    VStack(alignment: .leading, spacing: 12) {
        Text("Заголовок")
            .font(.headline)
            .foregroundColor(.white)
        
        Text("Описание контента с несколькими строками текста.")
            .font(.body)
            .foregroundColor(.white.opacity(0.8))
    }
}
```

### Стеклянное поле ввода

```swift
struct GlassTextField: View {
    @Binding var text: String
    let placeholder: String
    @FocusState private var isFocused: Bool
    
    var body: some View {
        TextField(placeholder, text: $text)
            .textFieldStyle(PlainTextFieldStyle())
            .padding(.horizontal, 16)
            .padding(.vertical, 12)
            .foregroundColor(.white)
            .background(.thinMaterial, in: RoundedRectangle(cornerRadius: 12))
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(isFocused ? .blue.opacity(0.6) : .white.opacity(0.3), lineWidth: 2)
            )
            .focused($isFocused)
            .animation(.easeInOut(duration: 0.2), value: isFocused)
    }
}
```

### Стеклянная навигационная панель

```swift
struct GlassNavigationView<Content: View>: View {
    let title: String
    let content: Content
    
    init(title: String, @ViewBuilder content: () -> Content) {
        self.title = title
        self.content = content()
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Стеклянная навигационная панель
            HStack {
                Text(title)
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Spacer()
                
                Button(action: {}) {
                    Image(systemName: "bell")
                        .foregroundColor(.white)
                        .font(.title2)
                }
                .background(.ultraThinMaterial, in: Circle())
                .frame(width: 44, height: 44)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 16)
            .background(.regularMaterial)
            .overlay(
                Rectangle()
                    .fill(.white.opacity(0.1))
                    .frame(height: 1),
                alignment: .bottom
            )
            
            content
        }
    }
}
```

---

## Web - CSS

### Базовые стеклянные эффекты

```css
/* Основной класс для стеклянного эффекта */
.glass {
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 12px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

/* Стеклянная кнопка */
.glass-button {
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  padding: 12px 24px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.glass-button::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
  transition: left 0.5s;
}

.glass-button:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
  box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
}

.glass-button:hover::before {
  left: 100%;
}

.glass-button:active {
  transform: translateY(0);
}
```

### Адаптивная стеклянная карточка

```css
.glass-card {
  backdrop-filter: blur(16px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  padding: 24px;
  margin: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.glass-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
}

.glass-card:hover {
  transform: translateY(-4px);
  box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
  border-color: rgba(255, 255, 255, 0.3);
}

/* Темная тема */
@media (prefers-color-scheme: dark) {
  .glass-card {
    background: rgba(0, 0, 0, 0.3);
    border-color: rgba(255, 255, 255, 0.1);
  }
}

/* Мобильная адаптация */
@media (max-width: 768px) {
  .glass-card {
    margin: 8px;
    padding: 16px;
    border-radius: 12px;
  }
}
```

---

## React/JavaScript

### Стеклянный компонент кнопки

```jsx
import React, { useState } from 'react';
import styled, { keyframes, css } from 'styled-components';

const shimmer = keyframes`
  0% { transform: translateX(-100%); }
  100% { transform: translateX(100%); }
`;

const StyledGlassButton = styled.button`
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  padding: 12px 24px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    transition: left 0.5s;
  }
  
  &:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 12px 35px rgba(0, 0, 0, 0.15);
    
    &::before {
      left: 100%;
    }
  }
  
  &:active {
    transform: translateY(0);
  }
  
  ${props => props.variant === 'primary' && css`
    background: rgba(74, 144, 226, 0.3);
    border-color: rgba(74, 144, 226, 0.5);
    
    &:hover {
      background: rgba(74, 144, 226, 0.4);
    }
  `}
  
  ${props => props.disabled && css`
    opacity: 0.5;
    cursor: not-allowed;
    
    &:hover {
      transform: none;
      background: rgba(255, 255, 255, 0.2);
    }
  `}
`;

const GlassButton = ({ 
  children, 
  onClick, 
  variant = 'default', 
  disabled = false,
  ...props 
}) => {
  const [isLoading, setIsLoading] = useState(false);
  
  const handleClick = async () => {
    if (disabled || isLoading) return;
    
    setIsLoading(true);
    try {
      await onClick?.();
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <StyledGlassButton
      onClick={handleClick}
      variant={variant}
      disabled={disabled || isLoading}
      {...props}
    >
      {isLoading ? 'Loading...' : children}
    </StyledGlassButton>
  );
};

export default GlassButton;
```

### Стеклянная карточка с анимацией

```jsx
import React, { useRef, useEffect } from 'react';
import styled from 'styled-components';

const CardContainer = styled.div`
  backdrop-filter: blur(16px);
  background: rgba(255, 255, 255, 0.1);
  border: 1px solid rgba(255, 255, 255, 0.2);
  border-radius: 16px;
  padding: 24px;
  margin: 16px;
  box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
  cursor: pointer;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 1px;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
  }
  
  &:hover {
    transform: translateY(-4px) scale(1.02);
    box-shadow: 0 16px 48px rgba(0, 0, 0, 0.15);
    border-color: rgba(255, 255, 255, 0.3);
  }
`;

const GlassCard = ({ children, onClick }) => {
  const cardRef = useRef(null);
  
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    
    const handleMouseMove = (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const rotateX = (y - centerY) / 10;
      const rotateY = (centerX - x) / 10;
      
      card.style.transform = `
        translateY(-4px) 
        rotateX(${rotateX}deg) 
        rotateY(${rotateY}deg)
        scale(1.02)
      `;
    };
    
    const handleMouseLeave = () => {
      card.style.transform = 'translateY(0) rotateX(0) rotateY(0) scale(1)';
    };
    
    card.addEventListener('mousemove', handleMouseMove);
    card.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      card.removeEventListener('mousemove', handleMouseMove);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);
  
  return (
    <CardContainer ref={cardRef} onClick={onClick}>
      {children}
    </CardContainer>
  );
};

export default GlassCard;
```

### Хук для стеклянных эффектов

```jsx
import { useState, useEffect } from 'react';

export const useGlassEffect = (intensity = 10) => {
  const [glassStyle, setGlassStyle] = useState({});
  
  useEffect(() => {
    setGlassStyle({
      backdropFilter: `blur(${intensity}px)`,
      background: `rgba(255, 255, 255, ${0.1 + intensity * 0.01})`,
      border: `1px solid rgba(255, 255, 255, ${0.2 + intensity * 0.005})`,
      borderRadius: '12px',
      boxShadow: `0 ${intensity * 0.8}px ${intensity * 3.2}px rgba(0, 0, 0, 0.1)`,
    });
  }, [intensity]);
  
  return glassStyle;
};

// Компонент с использованием хука
const GlassContainer = ({ children, intensity = 10 }) => {
  const glassStyle = useGlassEffect(intensity);
  
  return (
    <div style={glassStyle}>
      {children}
    </div>
  );
};
```

---

## Android - Kotlin/Jetpack Compose

### Стеклянная кнопка

```kotlin
@Composable
fun GlassButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    variant: ButtonVariant = ButtonVariant.Default
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    
    val animatedElevation by animateDpAsState(
        targetValue = if (isPressed) 2.dp else 8.dp,
        animationSpec = tween(100)
    )
    
    val backgroundColor = when (variant) {
        ButtonVariant.Primary -> Color(0x4D4A90E2)
        ButtonVariant.Secondary -> Color(0x1AFFFFFF)
        ButtonVariant.Default -> Color(0x33FFFFFF)
    }
    
    Card(
        modifier = modifier
            .clickable(
                interactionSource = interactionSource,
                indication = null
            ) { if (enabled) onClick() },
        colors = CardDefaults.cardColors(
            containerColor = backgroundColor
        ),
        border = BorderStroke(
            width = 1.dp,
            color = Color.White.copy(alpha = 0.3f)
        ),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = animatedElevation
        )
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(horizontal = 24.dp, vertical = 12.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = text,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

enum class ButtonVariant {
    Default, Primary, Secondary
}
```

### Стеклянная карточка с содержимым

```kotlin
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    var isHovered by remember { mutableStateOf(false) }
    
    val animatedElevation by animateDpAsState(
        targetValue = if (isHovered) 16.dp else 8.dp,
        animationSpec = tween(300)
    )
    
    val animatedScale by animateFloatAsState(
        targetValue = if (isHovered) 1.02f else 1f,
        animationSpec = tween(300)
    )
    
    Card(
        modifier = modifier
            .scale(animatedScale)
            .then(
                if (onClick != null) {
                    Modifier
                        .clickable { onClick() }
                        .onGloballyPositioned { isHovered = true }
                } else Modifier
            ),
        colors = CardDefaults.cardColors(
            containerColor = Color(0x1AFFFFFF)
        ),
        border = BorderStroke(
            width = 1.dp,
            color = Color.White.copy(alpha = 0.2f)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = animatedElevation
        )
    ) {
        Column(
            modifier = Modifier.padding(20.dp)
        ) {
            content()
        }
    }
}
```

### Стеклянное поле ввода

```kotlin
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isError: Boolean = false
) {
    var isFocused by remember { mutableStateOf(false) }
    
    val borderColor by animateColorAsState(
        targetValue = when {
            isError -> Color(0xFFF44336)
            isFocused -> Color(0xFF4A90E2)
            else -> Color.White.copy(alpha = 0.3f)
        },
        animationSpec = tween(200)
    )
    
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = {
            Text(
                text = placeholder,
                color = Color.White.copy(alpha = 0.6f)
            )
        },
        modifier = modifier
            .onFocusChanged { isFocused = it.isFocused },
        enabled = enabled,
        colors = TextFieldDefaults.outlinedTextFieldColors(
            focusedTextColor = Color.White,
            unfocusedTextColor = Color.White,
            containerColor = Color(0x1AFFFFFF),
            focusedBorderColor = borderColor,
            unfocusedBorderColor = borderColor
        ),
        shape = RoundedCornerShape(12.dp)
    )
}
```

---

## Flutter/Dart

### Стеклянная кнопка

```dart
class GlassButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final Color? backgroundColor;
  final Color? textColor;
  final double? borderRadius;
  
  const GlassButton({
    Key? key,
    required this.text,
    this.onPressed,
    this.backgroundColor,
    this.textColor,
    this.borderRadius,
  }) : super(key: key);

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _scaleAnimation;
  
  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => _animationController.forward(),
      onTapUp: (_) => _animationController.reverse(),
      onTapCancel: () => _animationController.reverse(),
      onTap: widget.onPressed,
      child: AnimatedBuilder(
        animation: _scaleAnimation,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnimation.value,
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                color: widget.backgroundColor ?? Colors.white.withOpacity(0.2),
                borderRadius: BorderRadius.circular(
                  widget.borderRadius ?? 8,
                ),
                border: Border.all(
                  color: Colors.white.withOpacity(0.3),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(
                  widget.borderRadius ?? 8,
                ),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                  child: Text(
                    widget.text,
                    style: TextStyle(
                      color: widget.textColor ?? Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }
}
```

### Стеклянная карточка

```dart
class GlassCard extends StatelessWidget {
  final Widget child;
  final Color? backgroundColor;
  final double? borderRadius;
  final EdgeInsetsGeometry? padding;
  final VoidCallback? onTap;
  final double? blurSigma;
  
  const GlassCard({
    Key? key,
    required this.child,
    this.backgroundColor,
    this.borderRadius,
    this.padding,
    this.onTap,
    this.blurSigma,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: backgroundColor ?? Colors.white.withOpacity(0.1),
          borderRadius: BorderRadius.circular(borderRadius ?? 16),
          border: Border.all(
            color: Colors.white.withOpacity(0.2),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(borderRadius ?? 16),
          child: BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: blurSigma ?? 16,
              sigmaY: blurSigma ?? 16,
            ),
            child: Container(
              padding: padding ?? const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white.withOpacity(0.1),
                    Colors.white.withOpacity(0.05),
                  ],
                ),
              ),
              child: child,
            ),
          ),
        ),
      ),
    );
  }
}
```

### Стеклянное поле ввода

```dart
class GlassTextField extends StatefulWidget {
  final String? hintText;
  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;
  final bool obscureText;
  final TextInputType? keyboardType;
  
  const GlassTextField({
    Key? key,
    this.hintText,
    this.controller,
    this.onChanged,
    this.obscureText = false,
    this.keyboardType,
  }) : super(key: key);

  @override
  State<GlassTextField> createState() => _GlassTextFieldState();
}

class _GlassTextFieldState extends State<GlassTextField> {
  bool _isFocused = false;
  
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: _isFocused 
            ? Colors.blue.withOpacity(0.6)
            : Colors.white.withOpacity(0.3),
          width: 2,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
          child: TextField(
            controller: widget.controller,
            onChanged: widget.onChanged,
            obscureText: widget.obscureText,
            keyboardType: widget.keyboardType,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 16,
            ),
            decoration: InputDecoration(
              hintText: widget.hintText,
              hintStyle: TextStyle(
                color: Colors.white.withOpacity(0.6),
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
            ),
            onTap: () => setState(() => _isFocused = true),
            onEditingComplete: () => setState(() => _isFocused = false),
          ),
        ),
      ),
    );
  }
}
```

---

## Vue.js

### Композабл для стеклянных эффектов

```vue
<template>
  <div 
    :class="glassClasses"
    :style="glassStyles"
    @mouseenter="handleHover(true)"
    @mouseleave="handleHover(false)"
  >
    <slot />
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const props = defineProps({
  intensity: {
    type: Number,
    default: 10
  },
  variant: {
    type: String,
    default: 'default',
    validator: (value) => ['default', 'primary', 'secondary'].includes(value)
  },
  hoverable: {
    type: Boolean,
    default: false
  }
})

const isHovered = ref(false)

const glassClasses = computed(() => [
  'glass-component',
  `glass-component--${props.variant}`,
  {
    'glass-component--hovered': isHovered.value,
    'glass-component--hoverable': props.hoverable
  }
])

const glassStyles = computed(() => ({
  '--blur-intensity': `${props.intensity}px`,
  '--opacity': 0.1 + props.intensity * 0.01,
  '--border-opacity': 0.2 + props.intensity * 0.005,
  '--shadow-blur': `${props.intensity * 3.2}px`
}))

const handleHover = (state) => {
  if (props.hoverable) {
    isHovered.value = state
  }
}
</script>

<style scoped>
.glass-component {
  backdrop-filter: blur(var(--blur-intensity));
  background: rgba(255, 255, 255, var(--opacity));
  border: 1px solid rgba(255, 255, 255, var(--border-opacity));
  border-radius: 12px;
  box-shadow: 0 8px var(--shadow-blur) rgba(0, 0, 0, 0.1);
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.glass-component--primary {
  background: rgba(74, 144, 226, var(--opacity));
  border-color: rgba(74, 144, 226, var(--border-opacity));
}

.glass-component--secondary {
  background: rgba(156, 39, 176, var(--opacity));
  border-color: rgba(156, 39, 176, var(--border-opacity));
}

.glass-component--hoverable:hover,
.glass-component--hovered {
  transform: translateY(-2px);
  box-shadow: 0 12px calc(var(--shadow-blur) * 1.5) rgba(0, 0, 0, 0.15);
}

.glass-component::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
}
</style>
```

### Стеклянная кнопка Vue

```vue
<template>
  <button 
    :class="buttonClasses"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <span v-if="!loading" class="button-content">
      <slot />
    </span>
    <div v-else class="loading-spinner">
      <div class="spinner"></div>
    </div>
  </button>
</template>

<script setup>
import { ref, computed } from 'vue'

const props = defineProps({
  variant: {
    type: String,
    default: 'default'
  },
  size: {
    type: String,
    default: 'medium'
  },
  disabled: {
    type: Boolean,
    default: false
  }
})

const emit = defineEmits(['click'])

const loading = ref(false)

const buttonClasses = computed(() => [
  'glass-button',
  `glass-button--${props.variant}`,
  `glass-button--${props.size}`,
  {
    'glass-button--disabled': props.disabled || loading.value,
    'glass-button--loading': loading.value
  }
])

const handleClick = async () => {
  if (props.disabled || loading.value) return
  
  loading.value = true
  try {
    await emit('click')
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.glass-button {
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;
}

.glass-button--medium {
  padding: 12px 24px;
  font-size: 16px;
}

.glass-button--small {
  padding: 8px 16px;
  font-size: 14px;
}

.glass-button--large {
  padding: 16px 32px;
  font-size: 18px;
}

.glass-button:hover:not(.glass-button--disabled) {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}

.glass-button--disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.loading-spinner {
  display: flex;
  align-items: center;
  justify-content: center;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top: 2px solid white;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
```

---

## Angular

### Директива для стеклянных эффектов

```typescript
import { Directive, ElementRef, Input, Renderer2, OnInit } from '@angular/core';

@Directive({
  selector: '[appGlass]'
})
export class GlassDirective implements OnInit {
  @Input() glassIntensity: number = 10;
  @Input() glassVariant: 'default' | 'primary' | 'secondary' = 'default';
  @Input() glassHoverable: boolean = false;

  constructor(
    private el: ElementRef,
    private renderer: Renderer2
  ) {}

  ngOnInit() {
    this.applyGlassEffect();
    
    if (this.glassHoverable) {
      this.addHoverEffects();
    }
  }

  private applyGlassEffect() {
    const element = this.el.nativeElement;
    
    this.renderer.setStyle(element, 'backdrop-filter', `blur(${this.glassIntensity}px)`);
    this.renderer.setStyle(element, 'border-radius', '12px');
    this.renderer.setStyle(element, 'position', 'relative');
    this.renderer.setStyle(element, 'overflow', 'hidden');
    this.renderer.setStyle(element, 'transition', 'all 0.3s ease');
    
    const opacity = 0.1 + this.glassIntensity * 0.01;
    const borderOpacity = 0.2 + this.glassIntensity * 0.005;
    
    switch (this.glassVariant) {
      case 'primary':
        this.renderer.setStyle(element, 'background', `rgba(74, 144, 226, ${opacity})`);
        this.renderer.setStyle(element, 'border', `1px solid rgba(74, 144, 226, ${borderOpacity})`);
        break;
      case 'secondary':
        this.renderer.setStyle(element, 'background', `rgba(156, 39, 176, ${opacity})`);
        this.renderer.setStyle(element, 'border', `1px solid rgba(156, 39, 176, ${borderOpacity})`);
        break;
      default:
        this.renderer.setStyle(element, 'background', `rgba(255, 255, 255, ${opacity})`);
        this.renderer.setStyle(element, 'border', `1px solid rgba(255, 255, 255, ${borderOpacity})`);
    }
    
    this.renderer.setStyle(element, 'box-shadow', `0 8px ${this.glassIntensity * 3.2}px rgba(0, 0, 0, 0.1)`);
  }

  private addHoverEffects() {
    const element = this.el.nativeElement;
    
    this.renderer.listen(element, 'mouseenter', () => {
      this.renderer.setStyle(element, 'transform', 'translateY(-2px)');
      this.renderer.setStyle(element, 'box-shadow', `0 12px ${this.glassIntensity * 4.8}px rgba(0, 0, 0, 0.15)`);
    });
    
    this.renderer.listen(element, 'mouseleave', () => {
      this.renderer.setStyle(element, 'transform', 'translateY(0)');
      this.renderer.setStyle(element, 'box-shadow', `0 8px ${this.glassIntensity * 3.2}px rgba(0, 0, 0, 0.1)`);
    });
  }
}
```

### Стеклянный компонент кнопки

```typescript
import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-glass-button',
  template: `
    <button 
      class="glass-button"
      [class]="buttonClasses"
      [disabled]="disabled || loading"
      (click)="handleClick()"
    >
      <ng-content *ngIf="!loading"></ng-content>
      <div *ngIf="loading" class="loading-spinner">
        <div class="spinner"></div>
      </div>
    </button>
  `,
  styleUrls: ['./glass-button.component.scss']
})
export class GlassButtonComponent {
  @Input() variant: 'default' | 'primary' | 'secondary' = 'default';
  @Input() size: 'small' | 'medium' | 'large' = 'medium';
  @Input() disabled: boolean = false;
  @Output() clickEvent = new EventEmitter<void>();

  loading = false;

  get buttonClasses(): string {
    return [
      'glass-button',
      `glass-button--${this.variant}`,
      `glass-button--${this.size}`,
      this.disabled || this.loading ? 'glass-button--disabled' : '',
      this.loading ? 'glass-button--loading' : ''
    ].filter(Boolean).join(' ');
  }

  async handleClick() {
    if (this.disabled || this.loading) return;
    
    this.loading = true;
    try {
      this.clickEvent.emit();
    } finally {
      setTimeout(() => {
        this.loading = false;
      }, 500);
    }
  }
}
```

```scss
// glass-button.component.scss
.glass-button {
  backdrop-filter: blur(10px);
  background: rgba(255, 255, 255, 0.2);
  border: 1px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  color: white;
  font-weight: 500;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  overflow: hidden;

  &--medium {
    padding: 12px 24px;
    font-size: 16px;
  }

  &--small {
    padding: 8px 16px;
    font-size: 14px;
  }

  &--large {
    padding: 16px 32px;
    font-size: 18px;
  }

  &--primary {
    background: rgba(74, 144, 226, 0.3);
    border-color: rgba(74, 144, 226, 0.5);
  }

  &--secondary {
    background: rgba(156, 39, 176, 0.3);
    border-color: rgba(156, 39, 176, 0.5);
  }

  &:hover:not(&--disabled) {
    background: rgba(255, 255, 255, 0.3);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
  }

  &--disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
}

.loading-spinner {
  display: flex;
  align-items: center;
  justify-content: center;
}

.spinner {
  width: 20px;
  height: 20px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-top: 2px solid white;
  border-radius: 50%;
  animation: spin 1s linear infinite;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
```

---

## React Native

### Стеклянная кнопка

```jsx
import React, { useRef } from 'react';
import {
  TouchableOpacity,
  Text,
  Animated,
  StyleSheet,
  View,
} from 'react-native';
import { BlurView } from '@react-native-community/blur';

const GlassButton = ({ 
  title, 
  onPress, 
  variant = 'default',
  disabled = false,
  style 
}) => {
  const scaleValue = useRef(new Animated.Value(1)).current;
  
  const handlePressIn = () => {
    Animated.spring(scaleValue, {
      toValue: 0.95,
      useNativeDriver: true,
    }).start();
  };
  
  const handlePressOut = () => {
    Animated.spring(scaleValue, {
      toValue: 1,
      useNativeDriver: true,
    }).start();
  };
  
  const getVariantStyle = () => {
    switch (variant) {
      case 'primary':
        return {
          backgroundColor: 'rgba(74, 144, 226, 0.3)',
          borderColor: 'rgba(74, 144, 226, 0.5)',
        };
      case 'secondary':
        return {
          backgroundColor: 'rgba(156, 39, 176, 0.3)',
          borderColor: 'rgba(156, 39, 176, 0.5)',
        };
      default:
        return {
          backgroundColor: 'rgba(255, 255, 255, 0.2)',
          borderColor: 'rgba(255, 255, 255, 0.3)',
        };
    }
  };
  
  return (
    <Animated.View
      style={[
        { transform: [{ scale: scaleValue }] },
        style
      ]}
    >
      <TouchableOpacity
        style={[styles.button, getVariantStyle(), disabled && styles.disabled]}
        onPress={onPress}
        onPressIn={handlePressIn}
        onPressOut={handlePressOut}
        disabled={disabled}
        activeOpacity={0.8}
      >
        <BlurView
          style={styles.blur}
          blurType="light"
          blurAmount={10}
        >
          <Text style={[styles.text, disabled && styles.disabledText]}>
            {title}
          </Text>
        </BlurView>
      </TouchableOpacity>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: 8,
    borderWidth: 1,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
  },
  blur: {
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  text: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
    textAlign: 'center',
  },
  disabled: {
    opacity: 0.5,
  },
  disabledText: {
    opacity: 0.7,
  },
});

export default GlassButton;
```

### Стеклянная карточка

```jsx
import React from 'react';
import {
  View,
  StyleSheet,
  TouchableOpacity,
} from 'react-native';
import { BlurView } from '@react-native-community/blur';

const GlassCard = ({ 
  children, 
  onPress, 
  style, 
  blurType = 'light',
  blurAmount = 16 
}) => {
  const Container = onPress ? TouchableOpacity : View;
  
  return (
    <Container
      style={[styles.container, style]}
      onPress={onPress}
      activeOpacity={onPress ? 0.9 : 1}
    >
      <BlurView
        style={styles.blur}
        blurType={blurType}
        blurAmount={blurAmount}
      >
        <View style={styles.content}>
          {children}
        </View>
      </BlurView>
    </Container>
  );
};

const styles = StyleSheet.create({
  container: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    overflow: 'hidden',
    margin: 8,
    elevation: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
  },
  blur: {
    flex: 1,
  },
  content: {
    padding: 20,
  },
});

export default GlassCard;
```

---

## Заключение

Этот документ показывает, как Liquid Glass эффекты могут быть реализованы на различных платформах:

- **iOS/macOS**: Использование `.ultraThinMaterial`, `.regularMaterial` в SwiftUI
- **Web/CSS**: `backdrop-filter`, `rgba` фоны, CSS анимации
- **React**: Styled-components, hooks, интерактивные состояния
- **Android**: Material Design 3, Jetpack Compose, Card компоненты
- **Flutter**: `BackdropFilter`, `ImageFilter.blur()`, Container декорации
- **Vue.js**: Композаблы, реактивные стили, CSS переменные
- **Angular**: Директивы, компоненты, TypeScript типизация
- **React Native**: BlurView, Animated API, TouchableOpacity

Каждая платформа имеет свои особенности реализации, но основные принципы остаются едиными: размытие фона, полупрозрачность, границы и тени для создания эффекта "жидкого стекла".