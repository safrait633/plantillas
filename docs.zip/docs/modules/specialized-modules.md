# Специализированные модули

Отраслевые модули для медицины, фитнеса, геолокации и финансов с применением Liquid Glass эффектов.

## 🏥 Медицинские и здоровьесберегающие модули

### Медицинская карта
**Назначение**: Цифровое досье пациента с историей болезни  
**Компоненты**: Личные данные, история болезни, анализы, назначения  
**Glass эффекты**: Конфиденциальные панели, secure overlay  

```jsx
const MedicalRecord = ({ patient, permissions }) => {
  const [activeSection, setActiveSection] = useState('overview');
  const [isSecureMode, setIsSecureMode] = useState(true);

  return (
    <div className="medical-record-container">
      {/* Заголовок карты */}
      <LiquidGlass blur="heavy" className="patient-header secure">
        <div className="patient-info">
          <Avatar src={patient.photo} size="large" />
          <div className="patient-details">
            <h2>{patient.name}</h2>
            <p>Дата рождения: {patient.birthDate}</p>
            <p>ID пациента: {patient.id}</p>
          </div>
        </div>
        
        <div className="security-controls">
          <Button
            variant={isSecureMode ? "primary" : "ghost"}
            onClick={() => setIsSecureMode(!isSecureMode)}
          >
            <Icon name="shield" />
            {isSecureMode ? "Защищенный режим" : "Обычный режим"}
          </Button>
        </div>
      </LiquidGlass>

      <div className="medical-content">
        {/* Навигация по разделам */}
        <LiquidGlass blur="medium" className="medical-nav">
          {[
            { id: 'overview', label: 'Обзор', icon: 'overview' },
            { id: 'history', label: 'История болезни', icon: 'history' },
            { id: 'tests', label: 'Анализы', icon: 'test-tube' },
            { id: 'medications', label: 'Лекарства', icon: 'pill' },
            { id: 'appointments', label: 'Приемы', icon: 'calendar' }
          ].map(section => (
            <button
              key={section.id}
              className={`nav-item ${activeSection === section.id ? 'active' : ''}`}
              onClick={() => setActiveSection(section.id)}
            >
              <Icon name={section.icon} />
              {section.label}
            </button>
          ))}
        </LiquidGlass>

        {/* Содержимое раздела */}
        <LiquidGlass blur="light" className="medical-section">
          {activeSection === 'overview' && (
            <MedicalOverview patient={patient} />
          )}
          {activeSection === 'history' && (
            <MedicalHistory history={patient.medicalHistory} />
          )}
          {activeSection === 'tests' && (
            <TestResults tests={patient.testResults} />
          )}
          {activeSection === 'medications' && (
            <MedicationList medications={patient.medications} />
          )}
          {activeSection === 'appointments' && (
            <AppointmentHistory appointments={patient.appointments} />
          )}
        </LiquidGlass>
      </div>

      {/* Экстренная информация */}
      <LiquidGlass blur="heavy" className="emergency-info floating">
        <h4>Экстренная информация</h4>
        <div className="emergency-details">
          <div className="allergies">
            <Icon name="warning" />
            <span>Аллергии: {patient.allergies.join(', ')}</span>
          </div>
          <div className="blood-type">
            <Icon name="blood" />
            <span>Группа крови: {patient.bloodType}</span>
          </div>
          <div className="emergency-contact">
            <Icon name="phone" />
            <span>Экстренный контакт: {patient.emergencyContact}</span>
          </div>
        </div>
      </LiquidGlass>
    </div>
  );
};
```

### Трекер жизненных показателей
**Назначение**: Мониторинг пульса, давления, температуры  
**Компоненты**: Графики показателей, нормы, тревоги  
**Glass эффекты**: Real-time панели с пульсацией  

```jsx
const VitalSignsTracker = ({ vitals, patient }) => {
  const [selectedPeriod, setSelectedPeriod] = useState('day');
  const [criticalAlerts, setCriticalAlerts] = useState([]);

  return (
    <div className="vitals-tracker">
      {/* Критические уведомления */}
      {criticalAlerts.length > 0 && (
        <LiquidGlass blur="heavy" className="critical-alerts">
          {criticalAlerts.map(alert => (
            <div key={alert.id} className="alert critical">
              <Icon name="warning" />
              <span>{alert.message}</span>
              <Button size="small" variant="ghost">Подтвердить</Button>
            </div>
          ))}
        </LiquidGlass>
      )}

      {/* Текущие показатели */}
      <div className="current-vitals">
        <LiquidGlass blur="medium" className="vital-card heart-rate">
          <div className="vital-header">
            <Icon name="heart" className="pulsing" />
            <h3>Пульс</h3>
          </div>
          <div className="vital-value">
            <span className="value">{vitals.current.heartRate}</span>
            <span className="unit">уд/мин</span>
          </div>
          <div className="vital-status normal">Норма</div>
        </LiquidGlass>

        <LiquidGlass blur="medium" className="vital-card blood-pressure">
          <div className="vital-header">
            <Icon name="activity" />
            <h3>Давление</h3>
          </div>
          <div className="vital-value">
            <span className="value">{vitals.current.bloodPressure}</span>
            <span className="unit">мм рт.ст.</span>
          </div>
          <div className="vital-status normal">Норма</div>
        </LiquidGlass>

        <LiquidGlass blur="medium" className="vital-card temperature">
          <div className="vital-header">
            <Icon name="thermometer" />
            <h3>Температура</h3>
          </div>
          <div className="vital-value">
            <span className="value">{vitals.current.temperature}</span>
            <span className="unit">°C</span>
          </div>
          <div className="vital-status normal">Норма</div>
        </LiquidGlass>

        <LiquidGlass blur="medium" className="vital-card oxygen">
          <div className="vital-header">
            <Icon name="lungs" />
            <h3>Кислород</h3>
          </div>
          <div className="vital-value">
            <span className="value">{vitals.current.oxygenSaturation}</span>
            <span className="unit">%</span>
          </div>
          <div className="vital-status normal">Норма</div>
        </LiquidGlass>
      </div>

      {/* График показателей */}
      <LiquidGlass blur="light" className="vitals-chart">
        <div className="chart-header">
          <h3>Динамика показателей</h3>
          <div className="period-selector">
            {['day', 'week', 'month'].map(period => (
              <Button
                key={period}
                variant={selectedPeriod === period ? "primary" : "ghost"}
                size="small"
                onClick={() => setSelectedPeriod(period)}
              >
                {period === 'day' ? 'День' : period === 'week' ? 'Неделя' : 'Месяц'}
              </Button>
            ))}
          </div>
        </div>
        
        <VitalSignsChart
          data={vitals.history[selectedPeriod]}
          period={selectedPeriod}
        />
      </LiquidGlass>
    </div>
  );
};
```

### Телемедицинские консультации
**Назначение**: Видеосвязь с медицинскими специалистами  
**Компоненты**: Видеозвонок, чат, документы, рецепты  
**Glass эффекты**: Secure видео-интерфейс  

---

## 💪 Модули фитнеса и активности

### Трекер физической активности
**Назначение**: Подсчет шагов, калорий, дистанции  
**Компоненты**: Дневные цели, статистика, достижения  
**Glass эффекты**: Прогрессивные кольца активности  

```jsx
const ActivityTracker = ({ dailyActivity, goals, achievements }) => {
  const [selectedMetric, setSelectedMetric] = useState('steps');
  
  return (
    <div className="activity-tracker">
      {/* Кольца активности */}
      <LiquidGlass blur="medium" className="activity-rings">
        <div className="rings-container">
          <div className="activity-ring steps">
            <svg viewBox="0 0 100 100">
              <circle
                cx="50" cy="50" r="45"
                fill="none"
                stroke="rgba(99, 102, 241, 0.2)"
                strokeWidth="8"
              />
              <circle
                cx="50" cy="50" r="45"
                fill="none"
                stroke="rgb(99, 102, 241)"
                strokeWidth="8"
                strokeDasharray={`${dailyActivity.steps / goals.steps * 283} 283`}
                transform="rotate(-90 50 50)"
                className="progress-circle"
              />
            </svg>
            <div className="ring-content">
              <span className="value">{dailyActivity.steps.toLocaleString()}</span>
              <span className="label">шагов</span>
            </div>
          </div>

          <div className="activity-ring calories">
            <svg viewBox="0 0 100 100">
              <circle
                cx="50" cy="50" r="35"
                fill="none"
                stroke="rgba(239, 68, 68, 0.2)"
                strokeWidth="8"
              />
              <circle
                cx="50" cy="50" r="35"
                fill="none"
                stroke="rgb(239, 68, 68)"
                strokeWidth="8"
                strokeDasharray={`${dailyActivity.calories / goals.calories * 220} 220`}
                transform="rotate(-90 50 50)"
                className="progress-circle"
              />
            </svg>
            <div className="ring-content">
              <span className="value">{dailyActivity.calories}</span>
              <span className="label">ккал</span>
            </div>
          </div>

          <div className="activity-ring exercise">
            <svg viewBox="0 0 100 100">
              <circle
                cx="50" cy="50" r="25"
                fill="none"
                stroke="rgba(34, 197, 94, 0.2)"
                strokeWidth="8"
              />
              <circle
                cx="50" cy="50" r="25"
                fill="none"
                stroke="rgb(34, 197, 94)"
                strokeWidth="8"
                strokeDasharray={`${dailyActivity.exerciseMinutes / goals.exerciseMinutes * 157} 157`}
                transform="rotate(-90 50 50)"
                className="progress-circle"
              />
            </svg>
            <div className="ring-content">
              <span className="value">{dailyActivity.exerciseMinutes}</span>
              <span className="label">мин</span>
            </div>
          </div>
        </div>
      </LiquidGlass>

      {/* Детальная статистика */}
      <LiquidGlass blur="light" className="activity-details">
        <div className="metrics-tabs">
          {[
            { id: 'steps', label: 'Шаги', icon: 'footprints' },
            { id: 'distance', label: 'Дистанция', icon: 'map' },
            { id: 'calories', label: 'Калории', icon: 'flame' },
            { id: 'heartRate', label: 'Пульс', icon: 'heart' }
          ].map(metric => (
            <button
              key={metric.id}
              className={`metric-tab ${selectedMetric === metric.id ? 'active' : ''}`}
              onClick={() => setSelectedMetric(metric.id)}
            >
              <Icon name={metric.icon} />
              {metric.label}
            </button>
          ))}
        </div>

        <div className="metric-content">
          <ActivityMetricChart
            type={selectedMetric}
            data={dailyActivity[selectedMetric]}
            goal={goals[selectedMetric]}
          />
        </div>
      </LiquidGlass>

      {/* Достижения */}
      <LiquidGlass blur="medium" className="achievements">
        <h3>Недавние достижения</h3>
        <div className="achievements-list">
          {achievements.slice(0, 3).map(achievement => (
            <div key={achievement.id} className="achievement-item">
              <div className="achievement-icon">
                <Icon name={achievement.icon} />
              </div>
              <div className="achievement-content">
                <h4>{achievement.title}</h4>
                <p>{achievement.description}</p>
                <span className="achievement-date">{achievement.date}</span>
              </div>
            </div>
          ))}
        </div>
      </LiquidGlass>
    </div>
  );
};
```

### Планы тренировок
**Назначение**: Структурированные программы упражнений  
**Компоненты**: Упражнения, подходы, таймеры, прогресс  
**Glass эффекты**: Интерактивные карточки упражнений  

### Мониторинг сна
**Назначение**: Отслеживание качества и продолжительности сна  
**Компоненты**: Фазы сна, статистика, рекомендации  
**Glass эффекты**: Ночная тема с мягким glass  

---

## 🗺️ Модули геолокации и карт

### Интерактивные карты
**Назначение**: Отображение объектов на географической карте  
**Компоненты**: Маркеры, кластеры, фильтры, поиск  
**Glass эффекты**: Floating панели информации  

```jsx
const InteractiveMap = ({ locations, filters, onLocationSelect }) => {
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [mapStyle, setMapStyle] = useState('standard');
  const [showFilters, setShowFilters] = useState(false);

  return (
    <div className="interactive-map-container">
      {/* Карта */}
      <div className="map-wrapper">
        <MapComponent
          locations={locations}
          style={mapStyle}
          onLocationClick={setSelectedLocation}
        />

        {/* Floating панель управления */}
        <LiquidGlass blur="heavy" className="map-controls floating">
          <div className="control-group">
            <Button
              variant={showFilters ? "primary" : "ghost"}
              onClick={() => setShowFilters(!showFilters)}
            >
              <Icon name="filter" />
            </Button>
            <Button variant="ghost">
              <Icon name="search" />
            </Button>
            <Button variant="ghost">
              <Icon name="location" />
            </Button>
          </div>
          
          <div className="style-selector">
            {['standard', 'satellite', 'terrain'].map(style => (
              <Button
                key={style}
                size="small"
                variant={mapStyle === style ? "primary" : "ghost"}
                onClick={() => setMapStyle(style)}
              >
                {style}
              </Button>
            ))}
          </div>
        </LiquidGlass>

        {/* Панель фильтров */}
        {showFilters && (
          <LiquidGlass blur="medium" className="map-filters floating-left">
            <h4>Фильтры</h4>
            <div className="filter-groups">
              <FilterGroup
                title="Категория"
                options={filters.categories}
                type="checkbox"
              />
              <FilterGroup
                title="Рейтинг"
                options={filters.ratings}
                type="range"
              />
              <FilterGroup
                title="Расстояние"
                options={filters.distance}
                type="slider"
              />
            </div>
          </LiquidGlass>
        )}

        {/* Информация о выбранном месте */}
        {selectedLocation && (
          <LiquidGlass blur="heavy" className="location-info floating-bottom">
            <div className="location-header">
              <img src={selectedLocation.image} alt={selectedLocation.name} />
              <div className="location-details">
                <h3>{selectedLocation.name}</h3>
                <p>{selectedLocation.address}</p>
                <div className="location-rating">
                  <StarRating value={selectedLocation.rating} />
                  <span>({selectedLocation.reviewCount} отзывов)</span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="small"
                onClick={() => setSelectedLocation(null)}
              >
                <Icon name="close" />
              </Button>
            </div>
            
            <div className="location-actions">
              <Button variant="primary">Маршрут</Button>
              <Button variant="ghost">Подробнее</Button>
              <Button variant="ghost">Поделиться</Button>
            </div>
          </LiquidGlass>
        )}
      </div>

      {/* Список локаций */}
      <LiquidGlass blur="light" className="locations-sidebar">
        <div className="sidebar-header">
          <h3>Найденные места</h3>
          <span className="results-count">{locations.length} мест</span>
        </div>
        
        <div className="locations-list">
          {locations.map(location => (
            <div
              key={location.id}
              className={`location-item ${selectedLocation?.id === location.id ? 'selected' : ''}`}
              onClick={() => setSelectedLocation(location)}
            >
              <img src={location.thumbnail} alt={location.name} />
              <div className="item-content">
                <h4>{location.name}</h4>
                <p>{location.description}</p>
                <div className="item-meta">
                  <span className="distance">{location.distance}</span>
                  <StarRating value={location.rating} size="small" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </LiquidGlass>
    </div>
  );
};
```

### Построение маршрутов
**Назначение**: Навигация от точки А до точки Б  
**Компоненты**: Расчет маршрута, альтернативы, навигация  
**Glass эффекты**: Floating панель маршрута  

### Геофенсинг
**Назначение**: Уведомления при входе/выходе из зон  
**Компоненты**: Зоны на карте, триггеры, уведомления  
**Glass эффекты**: Полупрозрачные зоны на карте  

---

## 💰 Финансовые модули

### Кошелек и баланс
**Назначение**: Отображение текущих финансовых средств  
**Компоненты**: Множественные валюты, карты, операции  
**Glass эффекты**: Secure панели с финансовой информацией  

```jsx
const DigitalWallet = ({ accounts, transactions, cards }) => {
  const [selectedAccount, setSelectedAccount] = useState(accounts[0]);
  const [showSensitiveData, setShowSensitiveData] = useState(false);

  return (
    <div className="digital-wallet">
      {/* Баланс и карты */}
      <LiquidGlass blur="heavy" className="wallet-overview secure">
        <div className="security-toggle">
          <Button
            variant="ghost"
            size="small"
            onClick={() => setShowSensitiveData(!showSensitiveData)}
          >
            <Icon name={showSensitiveData ? "eye-off" : "eye"} />
          </Button>
        </div>

        <div className="total-balance">
          <h2>Общий баланс</h2>
          <div className="balance-amount">
            {showSensitiveData ? (
              <span className="amount">₽{selectedAccount.balance.toLocaleString()}</span>
            ) : (
              <span className="amount-hidden">••••••</span>
            )}
          </div>
        </div>

        <div className="accounts-carousel">
          {accounts.map(account => (
            <LiquidGlass
              key={account.id}
              blur="medium"
              className={`account-card ${selectedAccount.id === account.id ? 'selected' : ''}`}
              onClick={() => setSelectedAccount(account)}
            >
              <div className="card-header">
                <span className="account-type">{account.type}</span>
                <Icon name={account.provider} />
              </div>
              
              <div className="card-number">
                {showSensitiveData ? account.number : `••••••••••••${account.number.slice(-4)}`}
              </div>
              
              <div className="card-balance">
                {showSensitiveData ? (
                  `₽${account.balance.toLocaleString()}`
                ) : (
                  '•••••••'
                )}
              </div>
            </LiquidGlass>
          ))}
        </div>
      </LiquidGlass>

      {/* Быстрые действия */}
      <LiquidGlass blur="medium" className="quick-actions">
        <h3>Быстрые действия</h3>
        <div className="actions-grid">
          <Button variant="glass" className="action-btn">
            <Icon name="send" />
            Перевести
          </Button>
          <Button variant="glass" className="action-btn">
            <Icon name="receive" />
            Получить
          </Button>
          <Button variant="glass" className="action-btn">
            <Icon name="card" />
            Пополнить
          </Button>
          <Button variant="glass" className="action-btn">
            <Icon name="exchange" />
            Обменять
          </Button>
        </div>
      </LiquidGlass>

      {/* История транзакций */}
      <LiquidGlass blur="light" className="transaction-history">
        <div className="history-header">
          <h3>Недавние операции</h3>
          <Button variant="ghost" size="small">
            Все операции
          </Button>
        </div>
        
        <div className="transactions-list">
          {transactions.slice(0, 5).map(transaction => (
            <div key={transaction.id} className="transaction-item">
              <div className="transaction-icon">
                <Icon
                  name={transaction.type === 'income' ? 'arrow-down' : 'arrow-up'}
                  className={transaction.type === 'income' ? 'income' : 'expense'}
                />
              </div>
              
              <div className="transaction-content">
                <div className="transaction-description">
                  <h4>{transaction.description}</h4>
                  <p>{transaction.merchant}</p>
                </div>
                <div className="transaction-amount">
                  <span className={`amount ${transaction.type}`}>
                    {transaction.type === 'income' ? '+' : '-'}₽{transaction.amount.toLocaleString()}
                  </span>
                  <span className="transaction-date">{transaction.date}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </LiquidGlass>
    </div>
  );
};
```

### Финансовая аналитика
**Назначение**: Анализ доходов и расходов  
**Компоненты**: Категории расходов, тренды, прогнозы  
**Glass эффекты**: Интерактивные диаграммы  

### Инвестиционный портфель
**Назначение**: Управление инвестициями  
**Компоненты**: Активы, доходность, риски, новости  
**Glass эффекты**: Real-time панели котировок  

---

## 🎨 Стилизация специализированных модулей

### Medical Theme
```scss
.medical-theme {
  --glass-primary: rgba(34, 197, 94, 0.1);
  --glass-secondary: rgba(239, 68, 68, 0.1);
  --glass-accent: rgba(59, 130, 246, 0.1);
  
  .secure-panel {
    @include glass-secure();
    border: 2px solid rgba(34, 197, 94, 0.3);
    
    &::before {
      content: '🔒';
      position: absolute;
      top: 8px;
      right: 8px;
      opacity: 0.6;
    }
  }

  .critical-alert {
    @include glass-critical();
    background: rgba(239, 68, 68, 0.2);
    border: 1px solid rgba(239, 68, 68, 0.4);
    animation: pulse 2s infinite;
  }
}
```

### Fitness Theme
```scss
.fitness-theme {
  --glass-primary: rgba(99, 102, 241, 0.1);
  --glass-secondary: rgba(239, 68, 68, 0.1);
  --glass-success: rgba(34, 197, 94, 0.1);
  
  .activity-ring {
    @include glass-circular();
    
    .progress-circle {
      transition: stroke-dasharray 0.5s ease-in-out;
      filter: drop-shadow(0 0 8px currentColor);
    }
  }

  .pulsing {
    animation: heartbeat 1s infinite;
  }

  @keyframes heartbeat {
    0%, 50%, 100% { transform: scale(1); }
    25%, 75% { transform: scale(1.1); }
  }
}
```

### Financial Theme
```scss
.financial-theme {
  --glass-primary: rgba(34, 197, 94, 0.1);
  --glass-danger: rgba(239, 68, 68, 0.1);
  --glass-warning: rgba(245, 158, 11, 0.1);
  
  .secure {
    @include glass-financial-secure();
    
    .amount-hidden {
      background: linear-gradient(
        90deg,
        rgba(255, 255, 255, 0.1) 0%,
        rgba(255, 255, 255, 0.2) 50%,
        rgba(255, 255, 255, 0.1) 100%
      );
      background-size: 200% 100%;
      animation: shimmer 2s infinite;
    }
  }

  @keyframes shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }
}
```

### Geolocation Theme
```scss
.geo-theme {
  .floating {
    @include glass-floating();
    z-index: 1000;
    
    &.floating-left {
      left: 20px;
      top: 50%;
      transform: translateY(-50%);
    }
    
    &.floating-bottom {
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
    }
  }

  .map-controls {
    backdrop-filter: blur(20px) saturate(1.5);
    background: rgba(255, 255, 255, 0.95);
    border-radius: 12px;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
  }
}
```

Специализированные модули готовы! Переходим к системным модулям. 🎯