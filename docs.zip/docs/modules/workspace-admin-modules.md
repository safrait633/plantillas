# Рабочие и административные модули

Модули для управления бизнес-процессами, аналитики и администрирования с применением Liquid Glass эффектов.

## 📊 Дашборды и аналитика

### Обзорная панель
**Назначение**: Главные метрики и KPI  
**Компоненты**: Виджеты метрик, графики, быстрые действия  
**Glass эффекты**: Floating виджеты, адаптивные панели  

```jsx
const DashboardOverview = ({ metrics, charts }) => (
  <div className="dashboard-container">
    {/* Главные метрики */}
    <div className="metrics-row">
      {metrics.map(metric => (
        <LiquidGlass key={metric.id} blur="medium" className="metric-card">
          <div className="metric-header">
            <Icon name={metric.icon} />
            <span className="metric-label">{metric.label}</span>
          </div>
          <div className="metric-value">
            <span className="value">{metric.value}</span>
            <span className={`trend ${metric.trend.direction}`}>
              <Icon name={metric.trend.direction === 'up' ? 'arrow-up' : 'arrow-down'} />
              {metric.trend.percentage}%
            </span>
          </div>
          <div className="metric-description">
            {metric.description}
          </div>
        </LiquidGlass>
      ))}
    </div>

    {/* Графики и диаграммы */}
    <div className="charts-grid">
      {charts.map(chart => (
        <LiquidGlass key={chart.id} blur="light" className="chart-widget">
          <div className="chart-header">
            <h3>{chart.title}</h3>
            <div className="chart-controls">
              <Select options={chart.periods} defaultValue="week" />
              <Button variant="ghost" size="small">
                <Icon name="download" />
              </Button>
            </div>
          </div>
          <div className="chart-content">
            <ChartComponent type={chart.type} data={chart.data} />
          </div>
        </LiquidGlass>
      ))}
    </div>

    {/* Быстрые действия */}
    <LiquidGlass blur="heavy" className="quick-actions floating">
      <h4>Быстрые действия</h4>
      <div className="actions-grid">
        <Button variant="glass" icon="plus">Создать проект</Button>
        <Button variant="glass" icon="user-plus">Добавить пользователя</Button>
        <Button variant="glass" icon="settings">Настройки</Button>
      </div>
    </LiquidGlass>
  </div>
);
```

### Детальная аналитика
**Назначение**: Углубленный анализ данных  
**Компоненты**: Сложные графики, фильтры, сравнения, экспорт  
**Glass эффекты**: Интерактивные панели анализа  

### Настраиваемый дашборд
**Назначение**: Виджеты по выбору пользователя  
**Компоненты**: Drag & drop виджетов, настройки отображения  
**Glass эффекты**: Перетаскиваемые glass-виджеты  

```jsx
const CustomizableDashboard = () => {
  const [widgets, setWidgets] = useState([]);
  const [isEditMode, setIsEditMode] = useState(false);

  return (
    <div className="customizable-dashboard">
      {/* Панель управления */}
      <LiquidGlass blur="medium" className="dashboard-controls">
        <div className="controls-left">
          <h2>Мой дашборд</h2>
          <Button
            variant={isEditMode ? "primary" : "ghost"}
            onClick={() => setIsEditMode(!isEditMode)}
          >
            {isEditMode ? "Сохранить" : "Редактировать"}
          </Button>
        </div>
        {isEditMode && (
          <div className="controls-right">
            <Button variant="ghost" icon="plus">Добавить виджет</Button>
            <Button variant="ghost" icon="layout">Сбросить макет</Button>
          </div>
        )}
      </LiquidGlass>

      {/* Сетка виджетов */}
      <div className={`widgets-grid ${isEditMode ? 'edit-mode' : ''}`}>
        {widgets.map(widget => (
          <LiquidGlass
            key={widget.id}
            blur="light"
            className={`dashboard-widget ${isEditMode ? 'draggable' : ''}`}
            draggable={isEditMode}
          >
            {isEditMode && (
              <div className="widget-controls">
                <Button size="small" variant="ghost">
                  <Icon name="drag" />
                </Button>
                <Button size="small" variant="ghost">
                  <Icon name="settings" />
                </Button>
                <Button size="small" variant="ghost">
                  <Icon name="close" />
                </Button>
              </div>
            )}
            
            <div className="widget-content">
              <WidgetRenderer type={widget.type} config={widget.config} />
            </div>
          </LiquidGlass>
        ))}
      </div>
    </div>
  );
};
```

---

## 🔄 Рабочие процессы

### Канбан-доска
**Назначение**: Визуальное управление задачами  
**Компоненты**: Колонки статусов, карточки задач, drag & drop  
**Glass эффекты**: Floating карточки, прозрачные колонки  

```jsx
const KanbanBoard = ({ columns, tasks, onTaskMove }) => {
  const [draggedTask, setDraggedTask] = useState(null);

  return (
    <div className="kanban-board">
      {columns.map(column => (
        <LiquidGlass key={column.id} blur="light" className="kanban-column">
          <div className="column-header">
            <h3>{column.title}</h3>
            <span className="task-count">{column.taskCount}</span>
          </div>
          
          <div
            className="column-content"
            onDrop={(e) => handleDrop(e, column.id)}
            onDragOver={handleDragOver}
          >
            {tasks
              .filter(task => task.status === column.id)
              .map(task => (
                <LiquidGlass
                  key={task.id}
                  blur="medium"
                  className="task-card draggable"
                  draggable
                  onDragStart={() => setDraggedTask(task)}
                >
                  <div className="task-header">
                    <span className={`priority ${task.priority}`}>
                      {task.priority}
                    </span>
                    <span className="task-id">#{task.id}</span>
                  </div>
                  
                  <h4 className="task-title">{task.title}</h4>
                  
                  <div className="task-meta">
                    <div className="task-assignee">
                      <Avatar src={task.assignee.avatar} size="small" />
                      <span>{task.assignee.name}</span>
                    </div>
                    <div className="task-due-date">
                      <Icon name="calendar" />
                      <span>{task.dueDate}</span>
                    </div>
                  </div>
                  
                  <div className="task-tags">
                    {task.tags.map(tag => (
                      <span key={tag} className="tag">{tag}</span>
                    ))}
                  </div>
                </LiquidGlass>
              ))}
          </div>
          
          <Button variant="ghost" className="add-task-btn">
            <Icon name="plus" />
            Добавить задачу
          </Button>
        </LiquidGlass>
      ))}
    </div>
  );
};
```

### Список задач
**Назначение**: Табличное представление дел  
**Компоненты**: Сортировка, фильтрация, массовые операции  
**Glass эффекты**: Группированные строки, sticky заголовки  

### Календарь событий
**Назначение**: Временное планирование  
**Компоненты**: Разные виды (месяц, неделя, день), события, напоминания  
**Glass эффекты**: Floating события, overlay деталей  

### Диаграмма Ганта
**Назначение**: Проектное планирование  
**Компоненты**: Временная шкала, зависимости, ресурсы  
**Glass эффекты**: Полупрозрачные полосы задач  

---

## 🛠️ Административные модули

### Панель управления
**Назначение**: Центральный админ-интерфейс  
**Компоненты**: Системная статистика, быстрые действия, мониторинг  
**Glass эффекты**: Многоуровневые панели статистики  

```jsx
const AdminPanel = ({ systemStats, recentActivity, alerts }) => (
  <div className="admin-panel">
    {/* Системные алерты */}
    {alerts.length > 0 && (
      <LiquidGlass blur="heavy" className="system-alerts">
        <div className="alerts-header">
          <Icon name="warning" />
          <h3>Системные уведомления</h3>
        </div>
        {alerts.map(alert => (
          <div key={alert.id} className={`alert ${alert.level}`}>
            <Icon name={alert.icon} />
            <span>{alert.message}</span>
            <Button size="small" variant="ghost">Скрыть</Button>
          </div>
        ))}
      </LiquidGlass>
    )}

    {/* Системная статистика */}
    <div className="admin-stats-grid">
      <LiquidGlass blur="medium" className="stats-card">
        <h4>Пользователи</h4>
        <div className="stats-value">{systemStats.users.total}</div>
        <div className="stats-details">
          <span>Активных: {systemStats.users.active}</span>
          <span>Новых за день: {systemStats.users.newToday}</span>
        </div>
      </LiquidGlass>

      <LiquidGlass blur="medium" className="stats-card">
        <h4>Система</h4>
        <div className="stats-value">{systemStats.uptime}</div>
        <div className="stats-details">
          <span>CPU: {systemStats.cpu}%</span>
          <span>RAM: {systemStats.memory}%</span>
        </div>
      </LiquidGlass>

      <LiquidGlass blur="medium" className="stats-card">
        <h4>Ошибки</h4>
        <div className="stats-value error">{systemStats.errors.count}</div>
        <div className="stats-details">
          <span>Критичных: {systemStats.errors.critical}</span>
          <span>За час: {systemStats.errors.lastHour}</span>
        </div>
      </LiquidGlass>
    </div>

    {/* Последняя активность */}
    <LiquidGlass blur="light" className="recent-activity">
      <h3>Последняя активность</h3>
      <div className="activity-list">
        {recentActivity.map(activity => (
          <div key={activity.id} className="activity-item">
            <div className="activity-icon">
              <Icon name={activity.icon} />
            </div>
            <div className="activity-content">
              <span className="activity-text">{activity.description}</span>
              <span className="activity-time">{activity.timestamp}</span>
            </div>
          </div>
        ))}
      </div>
    </LiquidGlass>
  </div>
);
```

### Управление пользователями
**Назначение**: Администрирование аккаунтов  
**Компоненты**: Список пользователей, роли, блокировки  
**Glass эффекты**: Модальные окна редактирования  

### Управление контентом
**Назначение**: Модерация и редактирование  
**Компоненты**: Очередь модерации, массовые операции  
**Glass эффекты**: Предпросмотр контента в glass-панелях  

### Системные настройки
**Назначение**: Конфигурация приложения  
**Компоненты**: Группированные настройки, валидация  
**Glass эффекты**: Секционированные панели настроек  

---

## 💬 Коммуникационные модули

### Чат один-на-один
**Назначение**: Приватная переписка  
**Компоненты**: Сообщения, файлы, статусы прочтения  
**Glass эффекты**: Floating окно чата, bubble сообщений  

```jsx
const PrivateChat = ({ conversation, currentUser }) => {
  const [message, setMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  return (
    <LiquidGlass blur="medium" className="chat-container">
      {/* Заголовок чата */}
      <LiquidGlass blur="heavy" className="chat-header">
        <div className="chat-user">
          <Avatar src={conversation.user.avatar} />
          <div className="user-info">
            <h4>{conversation.user.name}</h4>
            <span className={`status ${conversation.user.status}`}>
              {conversation.user.statusText}
            </span>
          </div>
        </div>
        <div className="chat-actions">
          <Button variant="ghost" size="small">
            <Icon name="phone" />
          </Button>
          <Button variant="ghost" size="small">
            <Icon name="video" />
          </Button>
          <Button variant="ghost" size="small">
            <Icon name="info" />
          </Button>
        </div>
      </LiquidGlass>

      {/* История сообщений */}
      <div className="chat-messages">
        {conversation.messages.map(msg => (
          <div
            key={msg.id}
            className={`message ${msg.sender === currentUser.id ? 'sent' : 'received'}`}
          >
            <LiquidGlass
              blur="light"
              className={`message-bubble ${msg.sender === currentUser.id ? 'sent' : 'received'}`}
            >
              <div className="message-content">{msg.content}</div>
              <div className="message-time">{msg.timestamp}</div>
              {msg.sender === currentUser.id && (
                <Icon
                  name={msg.read ? 'check-double' : 'check'}
                  className="read-status"
                />
              )}
            </LiquidGlass>
          </div>
        ))}
        
        {/* Индикатор печати */}
        {isTyping && (
          <div className="message received">
            <LiquidGlass blur="light" className="typing-indicator">
              <div className="typing-dots">
                <span></span>
                <span></span>
                <span></span>
              </div>
            </LiquidGlass>
          </div>
        )}
      </div>

      {/* Поле ввода */}
      <LiquidGlass blur="medium" className="chat-input">
        <div className="input-container">
          <Button variant="ghost" size="small">
            <Icon name="attachment" />
          </Button>
          <input
            type="text"
            placeholder="Введите сообщение..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
          />
          <Button variant="ghost" size="small">
            <Icon name="emoji" />
          </Button>
          <Button variant="primary" size="small" disabled={!message.trim()}>
            <Icon name="send" />
          </Button>
        </div>
      </LiquidGlass>
    </LiquidGlass>
  );
};
```

### Групповой чат
**Назначение**: Коллективное общение  
**Компоненты**: Участники, роли, модерация  
**Glass эффекты**: Панель участников, системные сообщения  

### Система уведомлений
**Назначение**: Центр всех оповещений  
**Компоненты**: Группировка, фильтрация, действия  
**Glass эффекты**: Floating центр уведомлений  

---

## 📈 Модули визуализации данных

### Графики и диаграммы
**Назначение**: Различные типы визуализации  
**Компоненты**: Линейные, круговые, столбчатые графики  
**Glass эффекты**: Интерактивные точки данных  

```jsx
const InteractiveChart = ({ data, type, config }) => {
  const [hoveredPoint, setHoveredPoint] = useState(null);
  const [selectedRange, setSelectedRange] = useState(null);

  return (
    <LiquidGlass blur="light" className="chart-container">
      <div className="chart-header">
        <h3>{config.title}</h3>
        <div className="chart-legend">
          {config.series.map(series => (
            <div key={series.name} className="legend-item">
              <span
                className="legend-color"
                style={{ backgroundColor: series.color }}
              />
              <span>{series.name}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="chart-content">
        <ChartRenderer
          type={type}
          data={data}
          config={config}
          onPointHover={setHoveredPoint}
          onRangeSelect={setSelectedRange}
        />

        {/* Tooltip для точки данных */}
        {hoveredPoint && (
          <LiquidGlass blur="heavy" className="chart-tooltip floating">
            <div className="tooltip-header">
              <strong>{hoveredPoint.label}</strong>
            </div>
            <div className="tooltip-content">
              {hoveredPoint.values.map(value => (
                <div key={value.series} className="tooltip-value">
                  <span className="value-label">{value.series}:</span>
                  <span className="value-number">{value.value}</span>
                </div>
              ))}
            </div>
          </LiquidGlass>
        )}
      </div>

      <div className="chart-controls">
        <Button variant="ghost" size="small">
          <Icon name="zoom-in" />
        </Button>
        <Button variant="ghost" size="small">
          <Icon name="download" />
        </Button>
        <Button variant="ghost" size="small">
          <Icon name="settings" />
        </Button>
      </div>
    </LiquidGlass>
  );
};
```

### Тепловые карты
**Назначение**: Визуализация плотности данных  
**Компоненты**: Цветовая схема, интерактивность, легенда  
**Glass эффекты**: Прозрачные ячейки с градиентами  

### Временные шкалы
**Назначение**: Хронологическое представление  
**Компоненты**: События, периоды, масштабирование  
**Glass эффекты**: Floating детали событий  

---

## 🎨 Стилизация рабочих модулей

### Adaptive Glass Workspace
```scss
.workspace-container {
  display: grid;
  grid-template-areas: 
    "sidebar header header"
    "sidebar main aside"
    "sidebar footer footer";
  grid-template-columns: 250px 1fr 300px;
  grid-template-rows: 60px 1fr 40px;
  height: 100vh;

  .workspace-sidebar {
    grid-area: sidebar;
    @include glass-sidebar();
    
    .nav-item {
      @include glass-nav-item();
      
      &.active {
        @include glass-active-state();
      }
    }
  }

  .workspace-main {
    grid-area: main;
    padding: 20px;
    overflow-y: auto;
  }

  .workspace-aside {
    grid-area: aside;
    @include glass-aside-panel();
  }
}

// Responsive design
@media (max-width: 1024px) {
  .workspace-container {
    grid-template-areas: 
      "header"
      "main"
      "footer";
    grid-template-columns: 1fr;
    
    .workspace-sidebar {
      transform: translateX(-100%);
      transition: transform 0.3s ease;
      
      &.open {
        transform: translateX(0);
      }
    }
  }
}
```

### Interactive States
```scss
.glass-interactive-module {
  @include glass-base();
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    @include glass-hover-enhance();
    transform: translateY(-2px);
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.15);
  }

  &.dragging {
    @include glass-dragging-state();
    transform: rotate(5deg) scale(1.05);
    z-index: 1000;
  }

  &.selected {
    @include glass-selected-state();
    border: 2px solid rgba(99, 102, 241, 0.6);
  }

  &.loading {
    @include glass-loading-state();
    pointer-events: none;
    
    &::after {
      content: '';
      @include glass-loading-overlay();
    }
  }
}
```

### Dark Mode Support
```scss
@media (prefers-color-scheme: dark) {
  .workspace-container {
    --glass-bg-primary: rgba(15, 23, 42, 0.8);
    --glass-bg-secondary: rgba(30, 41, 59, 0.6);
    --glass-border: rgba(148, 163, 184, 0.2);
    --glass-text: rgba(248, 250, 252, 0.9);
  }

  .glass-module {
    background: var(--glass-bg-primary);
    border: 1px solid var(--glass-border);
    color: var(--glass-text);
  }
}
```

Рабочие и административные модули готовы! Переходим к специализированным модулям. 🎯