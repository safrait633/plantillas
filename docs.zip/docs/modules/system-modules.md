# Системные модули

Технические модули для безопасности, интеграций, уведомлений и обработки ошибок с применением Liquid Glass эффектов.

## 🔐 Модули безопасности и доступа

### Управление правами
**Назначение**: Назначение ролей и разрешений  
**Компоненты**: Матрица ролей, иерархия доступа, аудит  
**Glass эффекты**: Secure панели управления доступом  

```jsx
const AccessControlPanel = ({ users, roles, permissions }) => {
  const [selectedUser, setSelectedUser] = useState(null);
  const [editingRole, setEditingRole] = useState(null);
  const [securityLevel, setSecurityLevel] = useState('high');

  return (
    <div className="access-control-panel">
      {/* Уровень безопасности */}
      <LiquidGlass blur="heavy" className="security-header">
        <div className="security-indicator">
          <Icon name="shield" />
          <span>Уровень безопасности: {securityLevel}</span>
        </div>
        <div className="security-controls">
          <Button variant="ghost" size="small">
            <Icon name="audit" />
            Аудит
          </Button>
          <Button variant="ghost" size="small">
            <Icon name="alert" />
            Уведомления
          </Button>
        </div>
      </LiquidGlass>

      <div className="access-layout">
        {/* Список пользователей */}
        <LiquidGlass blur="medium" className="users-panel">
          <h3>Пользователи</h3>
          <div className="users-list">
            {users.map(user => (
              <div
                key={user.id}
                className={`user-item ${selectedUser?.id === user.id ? 'selected' : ''}`}
                onClick={() => setSelectedUser(user)}
              >
                <Avatar src={user.avatar} size="small" />
                <div className="user-info">
                  <h4>{user.name}</h4>
                  <span className="user-role">{user.role}</span>
                </div>
                <div className={`user-status ${user.status}`}>
                  <Icon name={user.status === 'active' ? 'check' : 'warning'} />
                </div>
              </div>
            ))}
          </div>
        </LiquidGlass>

        {/* Управление ролями */}
        <LiquidGlass blur="light" className="roles-panel">
          <div className="panel-header">
            <h3>Роли и разрешения</h3>
            <Button variant="primary" size="small">
              <Icon name="plus" />
              Создать роль
            </Button>
          </div>
          
          <div className="roles-grid">
            {roles.map(role => (
              <LiquidGlass
                key={role.id}
                blur="medium"
                className="role-card"
                onClick={() => setEditingRole(role)}
              >
                <div className="role-header">
                  <h4>{role.name}</h4>
                  <span className="users-count">{role.usersCount} пользователей</span>
                </div>
                
                <div className="role-permissions">
                  {role.permissions.slice(0, 3).map(permission => (
                    <span key={permission} className="permission-tag">
                      {permission}
                    </span>
                  ))}
                  {role.permissions.length > 3 && (
                    <span className="more-permissions">
                      +{role.permissions.length - 3} еще
                    </span>
                  )}
                </div>
                
                <div className="role-actions">
                  <Button variant="ghost" size="small">
                    <Icon name="edit" />
                  </Button>
                  <Button variant="ghost" size="small">
                    <Icon name="copy" />
                  </Button>
                </div>
              </LiquidGlass>
            ))}
          </div>
        </LiquidGlass>

        {/* Детали пользователя */}
        {selectedUser && (
          <LiquidGlass blur="medium" className="user-details-panel">
            <div className="panel-header">
              <h3>Детали пользователя</h3>
              <Button
                variant="ghost"
                size="small"
                onClick={() => setSelectedUser(null)}
              >
                <Icon name="close" />
              </Button>
            </div>

            <div className="user-profile">
              <Avatar src={selectedUser.avatar} size="large" />
              <div className="profile-info">
                <h3>{selectedUser.name}</h3>
                <p>{selectedUser.email}</p>
                <span className="last-login">
                  Последний вход: {selectedUser.lastLogin}
                </span>
              </div>
            </div>

            <div className="permissions-matrix">
              <h4>Разрешения</h4>
              <div className="permissions-list">
                {permissions.map(permission => (
                  <div key={permission.id} className="permission-item">
                    <span className="permission-name">{permission.name}</span>
                    <Toggle
                      checked={selectedUser.permissions.includes(permission.id)}
                      onChange={(checked) => updateUserPermission(selectedUser.id, permission.id, checked)}
                    />
                  </div>
                ))}
              </div>
            </div>

            <div className="security-settings">
              <h4>Настройки безопасности</h4>
              <div className="settings-list">
                <div className="setting-item">
                  <span>Двухфакторная аутентификация</span>
                  <Toggle checked={selectedUser.twoFactorEnabled} />
                </div>
                <div className="setting-item">
                  <span>Принудительная смена пароля</span>
                  <Toggle checked={selectedUser.forcePasswordChange} />
                </div>
                <div className="setting-item">
                  <span>Блокировка аккаунта</span>
                  <Toggle checked={selectedUser.isBlocked} />
                </div>
              </div>
            </div>
          </LiquidGlass>
        )}
      </div>
    </div>
  );
};
```

### Аудит действий
**Назначение**: Логирование пользовательской активности  
**Компоненты**: Журнал событий, фильтрация, экспорт  
**Glass эффекты**: Временная лента событий  

### Мониторинг угроз
**Назначение**: Отслеживание подозрительной активности  
**Компоненты**: Детекция аномалий, алерты, блокировки  
**Glass эффекты**: Real-time панель угроз  

---

## 🔔 Модули уведомлений и связи

### Push-уведомления
**Назначение**: Мгновенные оповещения на устройства  
**Компоненты**: Создание, отправка, статистика доставки  
**Glass эффекты**: Floating уведомления  

```jsx
const NotificationCenter = ({ notifications, settings }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [showSettings, setShowSettings] = useState(false);
  const [unreadCount, setUnreadCount] = useState(notifications.filter(n => !n.read).length);

  return (
    <div className="notification-center">
      {/* Заголовок центра уведомлений */}
      <LiquidGlass blur="heavy" className="notification-header">
        <div className="header-left">
          <h2>Уведомления</h2>
          {unreadCount > 0 && (
            <span className="unread-badge">{unreadCount}</span>
          )}
        </div>
        <div className="header-actions">
          <Button variant="ghost" size="small">
            <Icon name="check-all" />
            Прочитать все
          </Button>
          <Button
            variant="ghost"
            size="small"
            onClick={() => setShowSettings(!showSettings)}
          >
            <Icon name="settings" />
          </Button>
        </div>
      </LiquidGlass>

      {/* Фильтры уведомлений */}
      <LiquidGlass blur="medium" className="notification-filters">
        {[
          { id: 'all', label: 'Все', count: notifications.length },
          { id: 'unread', label: 'Непрочитанные', count: unreadCount },
          { id: 'important', label: 'Важные', count: notifications.filter(n => n.important).length },
          { id: 'mentions', label: 'Упоминания', count: notifications.filter(n => n.type === 'mention').length }
        ].map(tab => (
          <button
            key={tab.id}
            className={`filter-tab ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => setActiveTab(tab.id)}
          >
            {tab.label}
            {tab.count > 0 && <span className="count">{tab.count}</span>}
          </button>
        ))}
      </LiquidGlass>

      {/* Список уведомлений */}
      <div className="notifications-list">
        {getFilteredNotifications(notifications, activeTab).map(notification => (
          <LiquidGlass
            key={notification.id}
            blur="light"
            className={`notification-item ${!notification.read ? 'unread' : ''} ${notification.important ? 'important' : ''}`}
          >
            <div className="notification-icon">
              <Icon name={getNotificationIcon(notification.type)} />
              {!notification.read && <div className="unread-indicator" />}
            </div>
            
            <div className="notification-content">
              <div className="notification-header">
                <h4>{notification.title}</h4>
                <span className="notification-time">{notification.timestamp}</span>
              </div>
              
              <p className="notification-message">{notification.message}</p>
              
              {notification.actions && (
                <div className="notification-actions">
                  {notification.actions.map(action => (
                    <Button
                      key={action.id}
                      variant="ghost"
                      size="small"
                      onClick={() => handleNotificationAction(notification.id, action.id)}
                    >
                      {action.label}
                    </Button>
                  ))}
                </div>
              )}
            </div>
            
            <div className="notification-controls">
              <Button variant="ghost" size="small">
                <Icon name="close" />
              </Button>
            </div>
          </LiquidGlass>
        ))}
      </div>

      {/* Настройки уведомлений */}
      {showSettings && (
        <LiquidGlass blur="heavy" className="notification-settings floating">
          <div className="settings-header">
            <h3>Настройки уведомлений</h3>
            <Button
              variant="ghost"
              size="small"
              onClick={() => setShowSettings(false)}
            >
              <Icon name="close" />
            </Button>
          </div>
          
          <div className="settings-content">
            <div className="setting-group">
              <h4>Способы доставки</h4>
              <div className="delivery-methods">
                <div className="method-item">
                  <span>Push-уведомления</span>
                  <Toggle checked={settings.push} />
                </div>
                <div className="method-item">
                  <span>Email</span>
                  <Toggle checked={settings.email} />
                </div>
                <div className="method-item">
                  <span>SMS</span>
                  <Toggle checked={settings.sms} />
                </div>
              </div>
            </div>
            
            <div className="setting-group">
              <h4>Типы уведомлений</h4>
              <div className="notification-types">
                {Object.entries(settings.types).map(([type, enabled]) => (
                  <div key={type} className="type-item">
                    <span>{getTypeLabel(type)}</span>
                    <Toggle checked={enabled} />
                  </div>
                ))}
              </div>
            </div>
            
            <div className="setting-group">
              <h4>Режим "Не беспокоить"</h4>
              <div className="dnd-settings">
                <Toggle checked={settings.doNotDisturb.enabled} />
                <span>С {settings.doNotDisturb.from} до {settings.doNotDisturb.to}</span>
              </div>
            </div>
          </div>
        </LiquidGlass>
      )}
    </div>
  );
};
```

### Центр уведомлений
**Назначение**: Единое место для всех оповещений  
**Компоненты**: Группировка, приоритеты, действия  
**Glass эффекты**: Sidebar с floating панелями  

### Email-рассылки
**Назначение**: Массовые почтовые уведомления  
**Компоненты**: Шаблоны, сегментация, аналитика  
**Glass эффекты**: Редактор шаблонов с превью  

---

## 🔗 Модули интеграций и API

### Подключение к внешним сервисам
**Назначение**: Интеграция со сторонними системами  
**Компоненты**: OAuth, API ключи, webhook'и  
**Glass эффекты**: Карточки интеграций  

```jsx
const IntegrationsManager = ({ integrations, availableServices }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showApiKeys, setShowApiKeys] = useState(false);

  return (
    <div className="integrations-manager">
      {/* Заголовок и поиск */}
      <LiquidGlass blur="medium" className="integrations-header">
        <div className="header-content">
          <h2>Интеграции</h2>
          <p>Подключите внешние сервисы для расширения функциональности</p>
        </div>
        
        <div className="header-actions">
          <div className="search-box">
            <Icon name="search" />
            <input
              type="text"
              placeholder="Поиск интеграций..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          
          <Button
            variant="primary"
            onClick={() => setShowApiKeys(!showApiKeys)}
          >
            <Icon name="key" />
            API ключи
          </Button>
        </div>
      </LiquidGlass>

      {/* Фильтры по категориям */}
      <LiquidGlass blur="light" className="category-filters">
        {[
          { id: 'all', label: 'Все', count: availableServices.length },
          { id: 'analytics', label: 'Аналитика', count: 5 },
          { id: 'payments', label: 'Платежи', count: 8 },
          { id: 'communication', label: 'Коммуникации', count: 12 },
          { id: 'storage', label: 'Хранилище', count: 6 },
          { id: 'social', label: 'Соцсети', count: 10 }
        ].map(category => (
          <button
            key={category.id}
            className={`category-filter ${categoryFilter === category.id ? 'active' : ''}`}
            onClick={() => setCategoryFilter(category.id)}
          >
            {category.label}
            <span className="count">{category.count}</span>
          </button>
        ))}
      </LiquidGlass>

      <div className="integrations-content">
        {/* Активные интеграции */}
        <div className="active-integrations">
          <h3>Активные интеграции</h3>
          <div className="integrations-grid">
            {integrations
              .filter(integration => integration.status === 'active')
              .map(integration => (
                <LiquidGlass key={integration.id} blur="medium" className="integration-card active">
                  <div className="card-header">
                    <img src={integration.logo} alt={integration.name} />
                    <div className="integration-info">
                      <h4>{integration.name}</h4>
                      <span className="integration-category">{integration.category}</span>
                    </div>
                    <div className="integration-status">
                      <Icon name="check" className="status-icon active" />
                    </div>
                  </div>
                  
                  <div className="integration-stats">
                    <div className="stat">
                      <span className="stat-label">Последняя синхронизация</span>
                      <span className="stat-value">{integration.lastSync}</span>
                    </div>
                    <div className="stat">
                      <span className="stat-label">Запросов за день</span>
                      <span className="stat-value">{integration.dailyRequests}</span>
                    </div>
                  </div>
                  
                  <div className="card-actions">
                    <Button variant="ghost" size="small">
                      <Icon name="settings" />
                      Настроить
                    </Button>
                    <Button variant="ghost" size="small">
                      <Icon name="pause" />
                      Приостановить
                    </Button>
                  </div>
                </LiquidGlass>
              ))}
          </div>
        </div>

        {/* Доступные интеграции */}
        <div className="available-integrations">
          <h3>Доступные интеграции</h3>
          <div className="integrations-grid">
            {getFilteredServices(availableServices, searchQuery, categoryFilter).map(service => (
              <LiquidGlass key={service.id} blur="light" className="integration-card available">
                <div className="card-header">
                  <img src={service.logo} alt={service.name} />
                  <div className="integration-info">
                    <h4>{service.name}</h4>
                    <span className="integration-category">{service.category}</span>
                  </div>
                  <div className="integration-rating">
                    <StarRating value={service.rating} size="small" />
                  </div>
                </div>
                
                <p className="integration-description">
                  {service.description}
                </p>
                
                <div className="integration-features">
                  {service.features.slice(0, 3).map(feature => (
                    <span key={feature} className="feature-tag">{feature}</span>
                  ))}
                </div>
                
                <div className="card-actions">
                  <Button variant="primary" size="small">
                    <Icon name="plus" />
                    Подключить
                  </Button>
                  <Button variant="ghost" size="small">
                    <Icon name="info" />
                    Подробнее
                  </Button>
                </div>
              </LiquidGlass>
            ))}
          </div>
        </div>
      </div>

      {/* Панель API ключей */}
      {showApiKeys && (
        <LiquidGlass blur="heavy" className="api-keys-panel floating">
          <div className="panel-header">
            <h3>Управление API ключами</h3>
            <Button
              variant="ghost"
              size="small"
              onClick={() => setShowApiKeys(false)}
            >
              <Icon name="close" />
            </Button>
          </div>
          
          <div className="api-keys-content">
            <Button variant="primary" className="create-key-btn">
              <Icon name="plus" />
              Создать новый ключ
            </Button>
            
            <div className="keys-list">
              {/* Список API ключей */}
              <div className="key-item">
                <div className="key-info">
                  <h4>Production API Key</h4>
                  <span className="key-value">sk_live_••••••••••••••••••••••••••••</span>
                </div>
                <div className="key-actions">
                  <Button variant="ghost" size="small">
                    <Icon name="copy" />
                  </Button>
                  <Button variant="ghost" size="small">
                    <Icon name="edit" />
                  </Button>
                  <Button variant="ghost" size="small">
                    <Icon name="trash" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </LiquidGlass>
      )}
    </div>
  );
};
```

### Webhook'и
**Назначение**: Уведомления о событиях в реальном времени  
**Компоненты**: Конфигурация, логи, retry механизм  
**Glass эффекты**: Real-time мониторинг webhook'ов  

### Синхронизация данных
**Назначение**: Согласование информации между системами  
**Компоненты**: Маппинг полей, конфликты, расписание  
**Glass эффекты**: Визуализация процесса синхронизации  

---

## ⚠️ Обработка ошибок и состояний

### Глобальная обработка ошибок
**Назначение**: Централизованное управление ошибками  
**Компоненты**: Error boundaries, логирование, восстановление  
**Glass эффекты**: Overlay ошибок  

```jsx
const ErrorBoundary = ({ children, fallback }) => {
  const [hasError, setHasError] = useState(false);
  const [error, setError] = useState(null);
  const [errorInfo, setErrorInfo] = useState(null);

  useEffect(() => {
    const handleError = (error, errorInfo) => {
      setHasError(true);
      setError(error);
      setErrorInfo(errorInfo);
      
      // Логирование ошибки
      logError(error, errorInfo);
    };

    window.addEventListener('error', handleError);
    return () => window.removeEventListener('error', handleError);
  }, []);

  if (hasError) {
    return (
      <LiquidGlass blur="heavy" className="error-boundary">
        <div className="error-content">
          <div className="error-icon">
            <Icon name="alert-triangle" size="large" />
          </div>
          
          <div className="error-message">
            <h2>Что-то пошло не так</h2>
            <p>Произошла неожиданная ошибка. Наша команда была уведомлена.</p>
          </div>
          
          <div className="error-actions">
            <Button
              variant="primary"
              onClick={() => {
                setHasError(false);
                setError(null);
                setErrorInfo(null);
              }}
            >
              Попробовать снова
            </Button>
            <Button
              variant="ghost"
              onClick={() => window.location.reload()}
            >
              Перезагрузить страницу
            </Button>
          </div>
          
          {process.env.NODE_ENV === 'development' && (
            <LiquidGlass blur="light" className="error-details">
              <h4>Детали ошибки</h4>
              <pre className="error-stack">
                {error && error.stack}
              </pre>
            </LiquidGlass>
          )}
        </div>
      </LiquidGlass>
    );
  }

  return children;
};
```

### Состояния загрузки
**Назначение**: Индикаторы процессов загрузки  
**Компоненты**: Скелетоны, спиннеры, прогресс-бары  
**Glass эффекты**: Pulsing glass скелетоны  

```jsx
const LoadingStates = {
  Skeleton: ({ className, ...props }) => (
    <LiquidGlass blur="light" className={`loading-skeleton ${className}`} {...props}>
      <div className="skeleton-content">
        <div className="skeleton-line long" />
        <div className="skeleton-line medium" />
        <div className="skeleton-line short" />
      </div>
    </LiquidGlass>
  ),

  Spinner: ({ size = 'medium', className }) => (
    <LiquidGlass blur="medium" className={`loading-spinner ${size} ${className}`}>
      <div className="spinner-container">
        <div className="spinner" />
        <span>Загрузка...</span>
      </div>
    </LiquidGlass>
  ),

  ProgressBar: ({ value, max = 100, label, className }) => (
    <LiquidGlass blur="light" className={`progress-container ${className}`}>
      <div className="progress-header">
        <span className="progress-label">{label}</span>
        <span className="progress-value">{Math.round((value / max) * 100)}%</span>
      </div>
      <div className="progress-bar">
        <div 
          className="progress-fill"
          style={{ width: `${(value / max) * 100}%` }}
        />
      </div>
    </LiquidGlass>
  )
};
```

### Offline состояния
**Назначение**: Работа без интернет-соединения  
**Компоненты**: Кэширование, синхронизация, уведомления  
**Glass эффекты**: Индикатор offline режима  

---

## 🎨 Стилизация системных модулей

### Security Theme
```scss
.security-theme {
  --glass-secure: rgba(34, 197, 94, 0.1);
  --glass-danger: rgba(239, 68, 68, 0.1);
  --glass-warning: rgba(245, 158, 11, 0.1);
  
  .secure {
    @include glass-secure();
    border: 2px solid rgba(34, 197, 94, 0.3);
    
    &::before {
      content: '🔒';
      position: absolute;
      top: 8px;
      right: 8px;
      opacity: 0.7;
    }
  }

  .audit-trail {
    @include glass-audit();
    
    .audit-item {
      border-left: 3px solid rgba(99, 102, 241, 0.5);
      padding-left: 12px;
      margin-bottom: 8px;
    }
  }
}
```

### Notification Theme
```scss
.notification-theme {
  .floating {
    @include glass-floating();
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    animation: slideInRight 0.3s ease-out;
  }

  .notification-item {
    @include glass-base();
    margin-bottom: 8px;
    
    &.unread {
      border-left: 4px solid rgba(99, 102, 241, 0.8);
    }
    
    &.important {
      @include glass-important();
      background: rgba(239, 68, 68, 0.1);
    }
  }

  @keyframes slideInRight {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
}
```

### Error States Theme
```scss
.error-theme {
  .error-boundary {
    @include glass-error();
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 99999;
    background: rgba(0, 0, 0, 0.8);
  }

  .loading-skeleton {
    @include glass-skeleton();
    
    .skeleton-line {
      background: linear-gradient(
        90deg,
        rgba(255, 255, 255, 0.1) 0%,
        rgba(255, 255, 255, 0.2) 50%,
        rgba(255, 255, 255, 0.1) 100%
      );
      background-size: 200% 100%;
      animation: shimmer 1.5s infinite;
      
      &.long { width: 100%; height: 20px; }
      &.medium { width: 70%; height: 16px; }
      &.short { width: 40%; height: 12px; }
    }
  }

  @keyframes shimmer {
    0% { background-position: -200% 0; }
    100% { background-position: 200% 0; }
  }
}
```

### Integration Theme
```scss
.integration-theme {
  .integration-card {
    @include glass-base();
    transition: all 0.3s ease;
    
    &.active {
      border: 2px solid rgba(34, 197, 94, 0.5);
      
      .status-icon {
        color: rgb(34, 197, 94);
        animation: pulse 2s infinite;
      }
    }
    
    &.available {
      &:hover {
        @include glass-hover-enhance();
        transform: translateY(-4px);
      }
    }
  }

  .api-keys-panel {
    @include glass-secure();
    
    .key-value {
      font-family: 'Monaco', 'Menlo', monospace;
      background: rgba(0, 0, 0, 0.1);
      padding: 4px 8px;
      border-radius: 4px;
    }
  }
}
```

Системные модули готовы! Теперь создам главный индекс модулей. 🎯