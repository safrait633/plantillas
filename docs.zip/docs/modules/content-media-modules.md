# Контентные и медиа модули

Модули для работы с контентом, медиафайлами и информационными структурами с применением Liquid Glass эффектов.

## 📰 Контентные страницы

### Статья/Пост
**Назначение**: Детальный материал с текстом и медиа  
**Компоненты**: Заголовок, автор, дата, содержание, теги, комментарии  
**Glass эффекты**: Читательская панель, floating навигация  

```jsx
const ArticlePage = ({ article }) => (
  <div className="article-container">
    {/* Hero секция статьи */}
    <LiquidGlass blur="heavy" className="article-hero">
      <div className="article-meta">
        <span className="article-category">{article.category}</span>
        <span className="article-date">{article.publishedAt}</span>
      </div>
      <h1 className="article-title">{article.title}</h1>
      <div className="article-author">
        <Avatar src={article.author.avatar} />
        <span>{article.author.name}</span>
      </div>
    </LiquidGlass>

    {/* Содержание статьи */}
    <LiquidGlass blur="medium" className="article-content">
      <div dangerouslySetInnerHTML={{ __html: article.content }} />
    </LiquidGlass>

    {/* Floating навигация */}
    <LiquidGlass blur="light" className="article-nav floating">
      <TableOfContents headings={article.headings} />
      <ShareButtons url={article.url} title={article.title} />
    </LiquidGlass>
  </div>
);
```

### Список статей
**Назначение**: Каталог публикаций с фильтрами  
**Компоненты**: Карточки статей, пагинация, фильтры, сортировка  
**Glass эффекты**: Карточки статей, боковая панель фильтров  

```jsx
const ArticlesList = ({ articles, filters, onFilterChange }) => (
  <div className="articles-layout">
    {/* Боковая панель фильтров */}
    <LiquidGlass blur="medium" className="filters-sidebar">
      <h3>Фильтры</h3>
      <FilterGroup
        title="Категория"
        options={filters.categories}
        onChange={onFilterChange}
      />
      <FilterGroup
        title="Дата"
        type="daterange"
        onChange={onFilterChange}
      />
      <FilterGroup
        title="Автор"
        options={filters.authors}
        onChange={onFilterChange}
      />
    </LiquidGlass>

    {/* Список статей */}
    <div className="articles-grid">
      {articles.map(article => (
        <LiquidGlass key={article.id} blur="light" className="article-card">
          <img src={article.thumbnail} alt={article.title} />
          <div className="card-content">
            <h3>{article.title}</h3>
            <p>{article.excerpt}</p>
            <div className="card-meta">
              <span>{article.author}</span>
              <span>{article.publishedAt}</span>
            </div>
          </div>
        </LiquidGlass>
      ))}
    </div>
  </div>
);
```

### Категории контента
**Назначение**: Тематическая группировка материалов  
**Компоненты**: Иерархия категорий, счетчики контента  
**Glass эффекты**: Древовидная навигация категорий  

### Архив по датам
**Назначение**: Хронологическая организация материалов  
**Компоненты**: Календарь, временная шкала, группировка  
**Glass эффекты**: Интерактивный календарь с glass-ячейками  

---

## 🔍 Модули поиска

### Простой поиск
**Назначение**: Базовая строка поиска  
**Компоненты**: Поле ввода, кнопка поиска, быстрые результаты  
**Glass эффекты**: Floating search bar, dropdown результатов  

```jsx
const SearchBox = ({ onSearch, suggestions }) => {
  const [query, setQuery] = useState('');
  const [showSuggestions, setShowSuggestions] = useState(false);

  return (
    <div className="search-container">
      <LiquidGlass blur="medium" className="search-box">
        <Icon name="search" />
        <input
          type="text"
          placeholder="Поиск..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
        />
        {query && (
          <button onClick={() => setQuery('')}>
            <Icon name="close" />
          </button>
        )}
      </LiquidGlass>

      {showSuggestions && suggestions.length > 0 && (
        <LiquidGlass blur="heavy" className="search-suggestions">
          {suggestions.map((suggestion, index) => (
            <div
              key={index}
              className="suggestion-item"
              onClick={() => onSearch(suggestion)}
            >
              <Icon name="search" />
              <span>{suggestion}</span>
            </div>
          ))}
        </LiquidGlass>
      )}
    </div>
  );
};
```

### Расширенный поиск
**Назначение**: Детальные параметры фильтрации  
**Компоненты**: Множественные критерии, логические операторы  
**Glass эффекты**: Expandable форма расширенного поиска  

### Фасетный поиск
**Назначение**: Многомерная фильтрация  
**Компоненты**: Боковые фильтры, счетчики результатов  
**Glass эффекты**: Интерактивные фасеты с live-обновлением  

### Результаты поиска
**Назначение**: Отображение найденного  
**Компоненты**: Сниппеты, релевантность, пагинация  
**Glass эффекты**: Карточки результатов с подсветкой  

---

## 🎥 Модули медиа

### Галерея изображений
**Назначение**: Коллекция фотографий  
**Компоненты**: Сетка изображений, лайтбокс, зум, слайдшоу  
**Glass эффекты**: Overlay информации, floating навигация  

```jsx
const ImageGallery = ({ images }) => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [lightboxOpen, setLightboxOpen] = useState(false);

  return (
    <>
      <div className="gallery-grid">
        {images.map((image, index) => (
          <LiquidGlass
            key={image.id}
            blur="light"
            className="gallery-item"
            onClick={() => {
              setSelectedImage(image);
              setLightboxOpen(true);
            }}
          >
            <img src={image.thumbnail} alt={image.alt} />
            <div className="image-overlay">
              <h4>{image.title}</h4>
              <p>{image.description}</p>
            </div>
          </LiquidGlass>
        ))}
      </div>

      {/* Лайтбокс */}
      {lightboxOpen && (
        <div className="lightbox-overlay" onClick={() => setLightboxOpen(false)}>
          <LiquidGlass blur="heavy" className="lightbox-content">
            <img src={selectedImage.fullSize} alt={selectedImage.alt} />
            <LiquidGlass blur="medium" className="lightbox-info">
              <h3>{selectedImage.title}</h3>
              <p>{selectedImage.description}</p>
              <div className="image-meta">
                <span>Дата: {selectedImage.date}</span>
                <span>Размер: {selectedImage.size}</span>
              </div>
            </LiquidGlass>
          </LiquidGlass>
        </div>
      )}
    </>
  );
};
```

### Видеоплеер
**Назначение**: Воспроизведение видеоконтента  
**Компоненты**: Плеер, контролы, плейлист, субтитры  
**Glass эффекты**: Floating контролы, glass-overlay информации  

```jsx
const VideoPlayer = ({ video, playlist }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showControls, setShowControls] = useState(true);

  return (
    <div className="video-container">
      <div className="video-wrapper">
        <video
          src={video.url}
          poster={video.poster}
          onPlay={() => setIsPlaying(true)}
          onPause={() => setIsPlaying(false)}
        />
        
        {/* Floating контролы */}
        {showControls && (
          <LiquidGlass blur="heavy" className="video-controls floating">
            <button onClick={() => setIsPlaying(!isPlaying)}>
              <Icon name={isPlaying ? "pause" : "play"} />
            </button>
            <div className="progress-bar">
              <div className="progress-fill" />
            </div>
            <span className="time-display">02:34 / 10:45</span>
            <button><Icon name="fullscreen" /></button>
          </LiquidGlass>
        )}

        {/* Информация о видео */}
        <LiquidGlass blur="medium" className="video-info">
          <h2>{video.title}</h2>
          <p>{video.description}</p>
          <div className="video-meta">
            <span>Просмотры: {video.views}</span>
            <span>Дата: {video.publishedAt}</span>
          </div>
        </LiquidGlass>
      </div>

      {/* Плейлист */}
      {playlist && (
        <LiquidGlass blur="light" className="video-playlist">
          <h3>Плейлист</h3>
          {playlist.map(item => (
            <div key={item.id} className="playlist-item">
              <img src={item.thumbnail} alt={item.title} />
              <div className="item-info">
                <h4>{item.title}</h4>
                <span>{item.duration}</span>
              </div>
            </div>
          ))}
        </LiquidGlass>
      )}
    </div>
  );
};
```

### Аудиоплеер
**Назначение**: Проигрывание звуковых файлов  
**Компоненты**: Плеер, эквалайзер, плейлист, визуализация  
**Glass эффекты**: Floating плеер, визуализация звуковых волн  

### Файловый менеджер
**Назначение**: Управление документами  
**Компоненты**: Дерево папок, список файлов, операции с файлами  
**Glass эффекты**: Боковая панель навигации, контекстные меню  

---

## 📊 Каталожные страницы

### Список элементов
**Назначение**: Табличное или карточное представление  
**Компоненты**: Сортировка, фильтрация, пагинация, массовые операции  
**Glass эффекты**: Sticky заголовки, hover-эффекты строк  

```jsx
const ItemsList = ({ items, columns, onSort, onFilter }) => (
  <LiquidGlass blur="light" className="items-table">
    {/* Sticky заголовок */}
    <LiquidGlass blur="medium" className="table-header sticky">
      {columns.map(column => (
        <div
          key={column.key}
          className="column-header"
          onClick={() => onSort(column.key)}
        >
          {column.label}
          <Icon name="sort" />
        </div>
      ))}
    </LiquidGlass>

    {/* Строки данных */}
    <div className="table-body">
      {items.map(item => (
        <LiquidGlass
          key={item.id}
          blur="light"
          className="table-row glass-hover"
        >
          {columns.map(column => (
            <div key={column.key} className="table-cell">
              {renderCell(item[column.key], column.type)}
            </div>
          ))}
        </LiquidGlass>
      ))}
    </div>
  </LiquidGlass>
);
```

### Детальная карточка
**Назначение**: Подробная информация об объекте  
**Компоненты**: Основная информация, дополнительные данные, действия  
**Glass эффекты**: Многослойная карточка с секциями  

### Сравнение элементов
**Назначение**: Сопоставление характеристик  
**Компоненты**: Сравнительная таблица, выбор элементов  
**Glass эффекты**: Синхронизированные панели сравнения  

---

## 📁 Управление контентом

### Редактор контента
**Назначение**: WYSIWYG создание и редактирование  
**Компоненты**: Панель инструментов, превью, автосохранение  
**Glass эффекты**: Floating панель инструментов, модальные окна  

```jsx
const ContentEditor = ({ content, onChange }) => {
  const [showToolbar, setShowToolbar] = useState(true);
  const [previewMode, setPreviewMode] = useState(false);

  return (
    <div className="editor-container">
      {/* Floating панель инструментов */}
      {showToolbar && (
        <LiquidGlass blur="heavy" className="editor-toolbar floating">
          <ToolbarGroup>
            <ToolbarButton icon="bold" title="Жирный" />
            <ToolbarButton icon="italic" title="Курсив" />
            <ToolbarButton icon="underline" title="Подчеркнутый" />
          </ToolbarGroup>
          <ToolbarGroup>
            <ToolbarButton icon="link" title="Ссылка" />
            <ToolbarButton icon="image" title="Изображение" />
            <ToolbarButton icon="video" title="Видео" />
          </ToolbarGroup>
          <ToolbarGroup>
            <ToolbarButton
              icon="preview"
              title="Превью"
              active={previewMode}
              onClick={() => setPreviewMode(!previewMode)}
            />
          </ToolbarGroup>
        </LiquidGlass>
      )}

      {/* Область редактирования */}
      <LiquidGlass blur="light" className="editor-content">
        {previewMode ? (
          <div className="content-preview" dangerouslySetInnerHTML={{ __html: content }} />
        ) : (
          <textarea
            className="content-editor"
            value={content}
            onChange={(e) => onChange(e.target.value)}
            placeholder="Начните писать..."
          />
        )}
      </LiquidGlass>

      {/* Статусная панель */}
      <LiquidGlass blur="medium" className="editor-status">
        <span>Слов: {content.split(' ').length}</span>
        <span>Символов: {content.length}</span>
        <span className="auto-save">Автосохранение: включено</span>
      </LiquidGlass>
    </div>
  );
};
```

### Система версий
**Назначение**: Отслеживание изменений документов  
**Компоненты**: История изменений, сравнение версий, откат  
**Glass эффекты**: Timeline версий, diff-панели  

### Теги и категории
**Назначение**: Организация и классификация материалов  
**Компоненты**: Дерево категорий, облако тегов, управление  
**Glass эффекты**: Интерактивное облако тегов, выпадающие категории  

---

## 🎨 Дизайн-система для контента

### Typography Glass Effects
```scss
.glass-content {
  .glass-heading {
    @include glass-text-effect();
    font-weight: 600;
    letter-spacing: -0.02em;
  }

  .glass-paragraph {
    @include glass-reading-experience();
    line-height: 1.6;
    margin-bottom: 1.2em;
  }

  .glass-quote {
    @include glass-blockquote();
    border-left: 4px solid rgba(255, 255, 255, 0.3);
    padding-left: 1rem;
    font-style: italic;
  }
}
```

### Media Containers
```scss
.glass-media-container {
  position: relative;
  border-radius: 12px;
  overflow: hidden;
  
  &.has-overlay {
    .media-overlay {
      @include glass-overlay();
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
      padding: 1rem;
    }
  }

  &.floating-controls {
    .media-controls {
      @include glass-floating();
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
  }
}
```

### Interactive States
```scss
.glass-interactive {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);

  &:hover {
    @include glass-hover-enhance();
    transform: translateY(-2px);
  }

  &:active {
    transform: translateY(0);
  }

  &.selected {
    @include glass-selected-state();
    border: 2px solid rgba(99, 102, 241, 0.6);
  }
}
```

---

## 🔧 Производительность медиа-модулей

### Lazy Loading
```jsx
const LazyImage = ({ src, alt, placeholder }) => {
  const [loaded, setLoaded] = useState(false);
  const [inView, setInView] = useState(false);
  const imgRef = useRef();

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (imgRef.current) {
      observer.observe(imgRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div ref={imgRef} className="lazy-image-container">
      {!loaded && (
        <LiquidGlass blur="light" className="image-placeholder">
          <div className="placeholder-content">
            <Icon name="image" />
            <span>Загрузка...</span>
          </div>
        </LiquidGlass>
      )}
      {inView && (
        <img
          src={src}
          alt={alt}
          onLoad={() => setLoaded(true)}
          style={{ opacity: loaded ? 1 : 0 }}
        />
      )}
    </div>
  );
};
```

### Progressive Enhancement
```jsx
const ProgressiveMediaGallery = ({ images }) => {
  const [enhancementsLoaded, setEnhancementsLoaded] = useState(false);

  useEffect(() => {
    // Загружаем улучшения после основного контента
    const timer = setTimeout(() => {
      setEnhancementsLoaded(true);
    }, 100);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="progressive-gallery">
      {/* Базовая галерея загружается сразу */}
      <div className="gallery-base">
        {images.map(image => (
          <img key={image.id} src={image.thumbnail} alt={image.alt} />
        ))}
      </div>

      {/* Glass эффекты загружаются асинхронно */}
      {enhancementsLoaded && (
        <div className="gallery-enhancements">
          {images.map(image => (
            <LiquidGlass key={`glass-${image.id}`} blur="light" className="image-glass-overlay">
              <div className="image-info">
                <h4>{image.title}</h4>
                <p>{image.description}</p>
              </div>
            </LiquidGlass>
          ))}
        </div>
      )}
    </div>
  );
};
```

Контентные и медиа модули готовы! Переходим к рабочим и административным модулям. 🎯