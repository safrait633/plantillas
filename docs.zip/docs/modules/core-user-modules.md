# Основные пользовательские модули

Базовые модули пользовательского интерфейса для создания современных веб-приложений с Liquid Glass эффектами.

## 📄 Лендинговые страницы

### Главная страница
**Назначение**: Основная точка входа с обзором сервиса  
**Компоненты**: Hero-секция, преимущества, отзывы, CTA  
**Glass эффекты**: Полупрозрачные карточки, размытые фоны  

```jsx
// Hero секция с glass эффектом
const HeroSection = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <section className="hero-container">
      <LiquidGlass 
        blur="heavy" 
        opacity={0.9} 
        className={`hero-section ${isLoaded ? 'loaded' : ''}`}
        transition="spring"
      >
        <div className="hero-content">
          <h1 className="hero-title">
            Добро пожаловать в будущее
            <span className="gradient-text">дизайна</span>
          </h1>
          <p className="hero-description">
            Революционный подход к созданию интерфейсов 
            с эффектом жидкого стекла
          </p>
          <div className="hero-actions">
            <Button variant="glass-primary">Начать бесплатно</Button>
            <Button variant="glass-outline">Смотреть демо</Button>
          </div>
        </div>
        <div className="hero-visual">
          <LiquidGlass className="floating-card" blur="light">
            <div className="card-content">
              <Icon name="sparkles" />
              <span>Live Demo</span>
            </div>
          </LiquidGlass>
        </div>
      </LiquidGlass>
    </section>
  );
};
```

```scss
.hero-container {
  min-height: 100vh;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
  
  &::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, 
      rgba(79, 172, 254, 0.1) 0%,
      rgba(0, 242, 254, 0.1) 100%);
    z-index: 0;
  }
}

.hero-section {
  width: 100%;
  padding: 120px 20px;
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 80px;
  align-items: center;
  max-width: 1200px;
  margin: 0 auto;
  position: relative;
  z-index: 1;
  
  &.loaded {
    .hero-title {
      transform: translateY(0);
      opacity: 1;
    }
    
    .hero-description {
      transform: translateY(0);
      opacity: 1;
      transition-delay: 0.2s;
    }
    
    .hero-actions {
      transform: translateY(0);
      opacity: 1;
      transition-delay: 0.4s;
    }
  }
  
  @media (max-width: 768px) {
    grid-template-columns: 1fr;
    gap: 40px;
    padding: 80px 20px;
  }
}

.hero-content {
  .hero-title {
    font-size: clamp(2.5rem, 5vw, 4rem);
    font-weight: 700;
    line-height: 1.1;
    margin: 0 0 24px 0;
    transform: translateY(30px);
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
    
    .gradient-text {
      background: linear-gradient(135deg, #4FACFE 0%, #00F2FE 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
  }
  
  .hero-description {
    font-size: 1.25rem;
    line-height: 1.6;
    color: rgba(255, 255, 255, 0.8);
    margin: 0 0 40px 0;
    transform: translateY(30px);
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
  }
  
  .hero-actions {
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
    transform: translateY(30px);
    opacity: 0;
    transition: all 0.8s cubic-bezier(0.16, 1, 0.3, 1);
  }
}

.floating-card {
  padding: 24px;
  border-radius: 16px;
  animation: float 6s ease-in-out infinite;
  
  .card-content {
    display: flex;
    align-items: center;
    gap: 12px;
    color: white;
    font-weight: 500;
  }
}

@keyframes float {
  0%, 100% { transform: translateY(0px); }
  50% { transform: translateY(-20px); }
}
```

### Промо-страница
**Назначение**: Продвижение конкретного продукта или акции  
**Компоненты**: Описание продукта, цены, форма заказа  
**Glass эффекты**: Акцентные карточки, интерактивные элементы  

```jsx
const PromoPage = () => {
  const [selectedPlan, setSelectedPlan] = useState('pro');
  
  const plans = [
    {
      id: 'basic',
      name: 'Basic',
      price: 29,
      features: ['5 проектов', 'Базовые эффекты', 'Email поддержка']
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 79,
      features: ['Безлимит проектов', 'Все эффекты', 'Priority поддержка'],
      popular: true
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: 199,
      features: ['Team collaboration', 'Custom эффекты', 'Dedicated менеджер']
    }
  ];

  return (
    <div className="promo-page">
      <LiquidGlass className="promo-header" blur="medium">
        <h1>Специальное предложение</h1>
        <p>Получите 50% скидку на годовую подписку</p>
        <div className="offer-timer">
          <CountdownTimer deadline="2025-12-31" />
        </div>
      </LiquidGlass>

      <div className="pricing-section">
        <h2>Выберите ваш план</h2>
        <div className="pricing-grid">
          {plans.map((plan) => (
            <LiquidGlass
              key={plan.id}
              className={`pricing-card ${plan.popular ? 'popular' : ''} ${
                selectedPlan === plan.id ? 'selected' : ''
              }`}
              onClick={() => setSelectedPlan(plan.id)}
              blur="light"
              interactive
            >
              {plan.popular && (
                <div className="popular-badge">
                  <span>Популярный</span>
                </div>
              )}
              
              <h3>{plan.name}</h3>
              <div className="price">
                <span className="currency">$</span>
                <span className="amount">{plan.price}</span>
                <span className="period">/мес</span>
              </div>
              
              <ul className="features">
                {plan.features.map((feature, index) => (
                  <li key={index}>
                    <Icon name="check" />
                    {feature}
                  </li>
                ))}
              </ul>
              
              <Button
                variant={selectedPlan === plan.id ? 'glass-primary' : 'glass-outline'}
                fullWidth
              >
                {selectedPlan === plan.id ? 'Выбрано' : 'Выбрать план'}
              </Button>
            </LiquidGlass>
          ))}
        </div>
      </div>

      <LiquidGlass className="order-form" blur="medium">
        <h3>Оформить заказ</h3>
        <OrderForm selectedPlan={selectedPlan} />
      </LiquidGlass>
    </div>
  );
};
```

```scss
.promo-page {
  min-height: 100vh;
  padding: 40px 20px;
  
  .promo-header {
    text-align: center;
    padding: 60px 40px;
    margin-bottom: 80px;
    border-radius: 24px;
    
    h1 {
      font-size: 3rem;
      margin-bottom: 16px;
      background: linear-gradient(135deg, #FF6B6B, #4ECDC4);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    
    p {
      font-size: 1.5rem;
      margin-bottom: 32px;
      opacity: 0.9;
    }
  }
}

.pricing-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 24px;
  margin: 40px 0;
}

.pricing-card {
  padding: 32px 24px;
  border-radius: 20px;
  text-align: center;
  position: relative;
  cursor: pointer;
  transition: all 0.3s ease;
  
  &.popular {
    border: 2px solid rgba(78, 205, 196, 0.5);
    transform: scale(1.05);
  }
  
  &.selected {
    background: rgba(78, 205, 196, 0.1);
    border: 2px solid rgba(78, 205, 196, 0.8);
  }
  
  &:hover {
    transform: translateY(-8px);
  }
  
  .popular-badge {
    position: absolute;
    top: -12px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #4ECDC4, #44A08D);
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 0.875rem;
    font-weight: 600;
    color: white;
  }
  
  .price {
    display: flex;
    align-items: baseline;
    justify-content: center;
    margin: 24px 0;
    
    .currency {
      font-size: 1.5rem;
      opacity: 0.7;
    }
    
    .amount {
      font-size: 3rem;
      font-weight: 700;
      margin: 0 4px;
    }
    
    .period {
      font-size: 1rem;
      opacity: 0.7;
    }
  }
  
  .features {
    list-style: none;
    padding: 0;
    margin: 24px 0;
    
    li {
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px 0;
      
      svg {
        color: #4ECDC4;
        flex-shrink: 0;
      }
    }
  }
}
```

### Страница захвата лидов
**Назначение**: Сбор контактов потенциальных клиентов  
**Компоненты**: Минималистичная форма, преимущества, доверие  
**Glass эффекты**: Центральная форма с glass-фреймом  

```jsx
const LeadCapturePage = () => {
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    company: '',
    interest: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Логика отправки формы
    setIsSubmitted(true);
  };

  if (isSubmitted) {
    return (
      <div className="lead-capture-success">
        <LiquidGlass className="success-card" blur="medium">
          <Icon name="check-circle" size={64} color="#4ECDC4" />
          <h2>Спасибо за интерес!</h2>
          <p>Мы свяжемся с вами в течение 24 часов</p>
          <Button onClick={() => setIsSubmitted(false)}>
            Вернуться
          </Button>
        </LiquidGlass>
      </div>
    );
  }

  return (
    <div className="lead-capture-page">
      <div className="capture-container">
        <div className="capture-content">
          <h1>Получите эксклюзивный доступ</h1>
          <p>Станьте одним из первых, кто попробует новую технологию</p>
          
          <div className="benefits">
            <div className="benefit">
              <Icon name="zap" />
              <span>Ранний доступ к бета-версии</span>
            </div>
            <div className="benefit">
              <Icon name="gift" />
              <span>50% скидка на подписку</span>
            </div>
            <div className="benefit">
              <Icon name="users" />
              <span>Приоритетная поддержка</span>
            </div>
          </div>
        </div>

        <LiquidGlass className="capture-form" blur="medium">
          <h3>Заполните форму</h3>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <input
                type="text"
                placeholder="Ваше имя"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required
              />
            </div>
            
            <div className="form-group">
              <input
                type="email"
                placeholder="Email адрес"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required
              />
            </div>
            
            <div className="form-group">
              <input
                type="text"
                placeholder="Компания (опционально)"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
              />
            </div>
            
            <div className="form-group">
              <select
                value={formData.interest}
                onChange={(e) => setFormData({...formData, interest: e.target.value})}
                required
              >
                <option value="">Что вас интересует?</option>
                <option value="product">Использование продукта</option>
                <option value="partnership">Партнерство</option>
                <option value="investment">Инвестиции</option>
              </select>
            </div>
            
            <Button type="submit" variant="glass-primary" fullWidth>
              Получить доступ
            </Button>
          </form>
          
          <div className="trust-indicators">
            <p>🔒 Ваши данные защищены</p>
            <p>📧 Никакого спама</p>
          </div>
        </LiquidGlass>
      </div>
    </div>
  );
};
```

### Coming Soon
**Назначение**: Анонс будущего запуска продукта  
**Компоненты**: Обратный отсчет, форма подписки, социальные сети  
**Glass эффекты**: Таймер с glass-панелями  

```jsx
const ComingSoonPage = () => {
  const [email, setEmail] = useState('');
  const [timeLeft, setTimeLeft] = useState({});

  useEffect(() => {
    const targetDate = new Date('2025-12-31T00:00:00');
    
    const timer = setInterval(() => {
      const now = new Date();
      const difference = targetDate - now;
      
      setTimeLeft({
        days: Math.floor(difference / (1000 * 60 * 60 * 24)),
        hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((difference / 1000 / 60) % 60),
        seconds: Math.floor((difference / 1000) % 60)
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="coming-soon-page">
      <LiquidGlass className="coming-soon-container" blur="heavy">
        <div className="logo">
          <img src="/logo.svg" alt="Logo" />
        </div>
        
        <h1>Что-то невероятное приближается</h1>
        <p>Революционная платформа для создания UI/UX дизайна</p>
        
        <div className="countdown">
          {Object.entries(timeLeft).map(([unit, value]) => (
            <LiquidGlass key={unit} className="countdown-item" blur="light">
              <div className="countdown-value">{value || 0}</div>
              <div className="countdown-label">{unit}</div>
            </LiquidGlass>
          ))}
        </div>
        
        <div className="newsletter-signup">
          <h3>Узнайте первыми о запуске</h3>
          <form onSubmit={(e) => { e.preventDefault(); /* handle signup */ }}>
            <div className="email-input-group">
              <input
                type="email"
                placeholder="Введите ваш email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" variant="glass-primary">
                Подписаться
              </Button>
            </div>
          </form>
        </div>
        
        <div className="social-links">
          <p>Следите за нами:</p>
          <div className="social-icons">
            <SocialLink platform="twitter" href="#" />
            <SocialLink platform="linkedin" href="#" />
            <SocialLink platform="github" href="#" />
          </div>
        </div>
      </LiquidGlass>
    </div>
  );
};
```

### Страница благодарности
**Назначение**: Подтверждение выполненного действия  
**Компоненты**: Подтверждающее сообщение, следующие шаги  
**Glass эффекты**: Центральная карточка подтверждения  

```jsx
const ThankYouPage = ({ type = 'signup', details = {} }) => {
  const getContent = () => {
    switch (type) {
      case 'purchase':
        return {
          icon: 'check-circle',
          title: 'Платеж успешно обработан!',
          message: 'Спасибо за покупку. Ваш заказ будет обработан в течение 24 часов.',
          actions: [
            { label: 'Перейти в личный кабинет', href: '/dashboard' },
            { label: 'Скачать чек', href: '/receipt', variant: 'outline' }
          ]
        };
      case 'signup':
        return {
          icon: 'mail',
          title: 'Добро пожаловать!',
          message: 'Мы отправили подтверждение на ваш email. Проверьте почту и подтвердите регистрацию.',
          actions: [
            { label: 'Начать работу', href: '/onboarding' },
            { label: 'Перейти на главную', href: '/', variant: 'outline' }
          ]
        };
      default:
        return {
          icon: 'check',
          title: 'Спасибо!',
          message: 'Ваше сообщение получено. Мы свяжемся с вами в ближайшее время.',
          actions: [
            { label: 'На главную', href: '/' }
          ]
        };
    }
  };

  const content = getContent();

  return (
    <div className="thank-you-page">
      <LiquidGlass className="thank-you-card" blur="medium">
        <div className="success-icon">
          <Icon name={content.icon} size={80} color="#4ECDC4" />
        </div>
        
        <h1>{content.title}</h1>
        <p>{content.message}</p>
        
        {details.orderNumber && (
          <div className="order-details">
            <p>Номер заказа: <strong>{details.orderNumber}</strong></p>
          </div>
        )}
        
        <div className="action-buttons">
          {content.actions.map((action, index) => (
            <Button
              key={index}
              href={action.href}
              variant={action.variant || 'glass-primary'}
            >
              {action.label}
            </Button>
          ))}
        </div>
        
        <div className="additional-info">
          <p>
            Нужна помощь? <a href="/support">Свяжитесь с поддержкой</a>
          </p>
        </div>
      </LiquidGlass>
    </div>
  );
};  

---

## 🔐 Аутентификация

### Вход в систему
**Назначение**: Форма авторизации пользователя  
**Компоненты**: Email/пароль, запомнить меня, восстановление пароля  
**Glass эффекты**: Центральная форма с полупрозрачным фоном  

```jsx
const LoginPage = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errors, setErrors] = useState({});

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrors({});
    
    try {
      await authService.login(formData);
      // Redirect to dashboard
    } catch (error) {
      setErrors(error.fieldErrors || { general: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <LiquidGlass className="auth-card" blur="medium">
          <div className="auth-header">
            <h1>Вход в систему</h1>
            <p>Добро пожаловать! Войдите в свой аккаунт</p>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            {errors.general && (
              <div className="error-message">
                <Icon name="alert-circle" />
                {errors.general}
              </div>
            )}

            <div className="form-group">
              <label htmlFor="email">Email адрес</label>
              <div className="input-wrapper">
                <Icon name="mail" className="input-icon" />
                <input
                  id="email"
                  type="email"
                  placeholder="example@company.com"
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className={errors.email ? 'error' : ''}
                  required
                />
              </div>
              {errors.email && <span className="field-error">{errors.email}</span>}
            </div>

            <div className="form-group">
              <label htmlFor="password">Пароль</label>
              <div className="input-wrapper">
                <Icon name="lock" className="input-icon" />
                <PasswordInput
                  id="password"
                  placeholder="Введите пароль"
                  value={formData.password}
                  onChange={(value) => setFormData({...formData, password: value})}
                  className={errors.password ? 'error' : ''}
                  required
                />
              </div>
              {errors.password && <span className="field-error">{errors.password}</span>}
            </div>

            <div className="form-options">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={formData.rememberMe}
                  onChange={(e) => setFormData({...formData, rememberMe: e.target.checked})}
                />
                <span className="checkmark"></span>
                Запомнить меня
              </label>
              
              <a href="/forgot-password" className="forgot-link">
                Забыли пароль?
              </a>
            </div>

            <Button
              type="submit"
              variant="glass-primary"
              fullWidth
              loading={isLoading}
            >
              Войти
            </Button>
          </form>

          <div className="auth-divider">
            <span>или</span>
          </div>

          <div className="social-auth">
            <Button variant="glass-outline" fullWidth className="google-btn">
              <Icon name="google" />
              Войти через Google
            </Button>
            <Button variant="glass-outline" fullWidth className="github-btn">
              <Icon name="github" />
              Войти через GitHub
            </Button>
          </div>

          <div className="auth-footer">
            <p>
              Нет аккаунта? <a href="/register">Зарегистрироваться</a>
            </p>
          </div>
        </LiquidGlass>
      </div>
    </div>
  );
};
```

```scss
.auth-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  background: linear-gradient(135deg, 
    rgba(79, 172, 254, 0.1) 0%,
    rgba(0, 242, 254, 0.1) 100%);
}

.auth-container {
  width: 100%;
  max-width: 420px;
}

.auth-card {
  padding: 40px;
  border-radius: 24px;
  width: 100%;
  
  .auth-header {
    text-align: center;
    margin-bottom: 32px;
    
    h1 {
      font-size: 2rem;
      margin-bottom: 8px;
      color: white;
    }
    
    p {
      color: rgba(255, 255, 255, 0.7);
      font-size: 0.95rem;
    }
  }
}

.auth-form {
  .form-group {
    margin-bottom: 24px;
    
    label {
      display: block;
      margin-bottom: 8px;
      font-weight: 500;
      color: rgba(255, 255, 255, 0.9);
      font-size: 0.9rem;
    }
    
    .input-wrapper {
      position: relative;
      
      .input-icon {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: rgba(255, 255, 255, 0.5);
        z-index: 2;
      }
      
      input {
        width: 100%;
        padding: 16px 16px 16px 48px;
        border: 1px solid rgba(255, 255, 255, 0.2);
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.1);
        color: white;
        font-size: 1rem;
        transition: all 0.3s ease;
        
        &:focus {
          outline: none;
          border-color: rgba(78, 205, 196, 0.6);
          background: rgba(255, 255, 255, 0.15);
          box-shadow: 0 0 0 3px rgba(78, 205, 196, 0.1);
        }
        
        &.error {
          border-color: rgba(255, 107, 107, 0.6);
        }
        
        &::placeholder {
          color: rgba(255, 255, 255, 0.5);
        }
      }
    }
    
    .field-error {
      display: block;
      color: rgba(255, 107, 107, 0.9);
      font-size: 0.85rem;
      margin-top: 6px;
    }
  }
  
  .form-options {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 32px;
    
    .checkbox-label {
      display: flex;
      align-items: center;
      cursor: pointer;
      font-size: 0.9rem;
      color: rgba(255, 255, 255, 0.8);
      
      input[type="checkbox"] {
        display: none;
      }
      
      .checkmark {
        width: 18px;
        height: 18px;
        border: 2px solid rgba(255, 255, 255, 0.3);
        border-radius: 4px;
        margin-right: 8px;
        position: relative;
        transition: all 0.3s ease;
        
        &::after {
          content: '';
          position: absolute;
          width: 6px;
          height: 10px;
          border: solid white;
          border-width: 0 2px 2px 0;
          transform: rotate(45deg) scale(0);
          top: 1px;
          left: 5px;
          transition: all 0.3s ease;
        }
      }
      
      input:checked + .checkmark {
        background: rgba(78, 205, 196, 0.8);
        border-color: rgba(78, 205, 196, 0.8);
        
        &::after {
          transform: rotate(45deg) scale(1);
        }
      }
    }
    
    .forgot-link {
      color: rgba(78, 205, 196, 0.9);
      text-decoration: none;
      font-size: 0.9rem;
      transition: color 0.3s ease;
      
      &:hover {
        color: rgba(78, 205, 196, 1);
      }
    }
  }
}

.error-message {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  background: rgba(255, 107, 107, 0.1);
  border: 1px solid rgba(255, 107, 107, 0.3);
  border-radius: 8px;
  color: rgba(255, 107, 107, 0.9);
  font-size: 0.9rem;
  margin-bottom: 24px;
}

.auth-divider {
  position: relative;
  text-align: center;
  margin: 32px 0;
  
  &::before {
    content: '';
    position: absolute;
    top: 50%;
    left: 0;
    right: 0;
    height: 1px;
    background: rgba(255, 255, 255, 0.2);
  }
  
  span {
    background: inherit;
    padding: 0 16px;
    color: rgba(255, 255, 255, 0.6);
    font-size: 0.9rem;
  }
}

.social-auth {
  display: flex;
  flex-direction: column;
  gap: 12px;
  margin-bottom: 32px;
  
  .google-btn {
    border-color: rgba(234, 67, 53, 0.3);
    
    &:hover {
      background: rgba(234, 67, 53, 0.1);
    }
  }
  
  .github-btn {
    border-color: rgba(255, 255, 255, 0.3);
    
    &:hover {
      background: rgba(255, 255, 255, 0.1);
    }
  }
}

.auth-footer {
  text-align: center;
  
  p {
    color: rgba(255, 255, 255, 0.7);
    font-size: 0.9rem;
    
    a {
      color: rgba(78, 205, 196, 0.9);
      text-decoration: none;
      
      &:hover {
        color: rgba(78, 205, 196, 1);
      }
    }
  }
}
```

### Регистрация
**Назначение**: Создание нового аккаунта пользователя  
**Компоненты**: Форма регистрации, подтверждение пароля, соглашение  
**Glass эффекты**: Многоступенчатая форма с анимацией  

```jsx
const RegisterPage = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    password: '',
    confirmPassword: '',
    agreeToTerms: false,
    marketingEmails: false
  });
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const validateStep = (currentStep) => {
    const newErrors = {};
    
    if (currentStep === 1) {
      if (!formData.firstName.trim()) newErrors.firstName = 'Имя обязательно';
      if (!formData.lastName.trim()) newErrors.lastName = 'Фамилия обязательна';
      if (!formData.email.trim()) newErrors.email = 'Email обязателен';
      else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Неверный формат email';
    }
    
    if (currentStep === 2) {
      if (!formData.password) newErrors.password = 'Пароль обязателен';
      else if (formData.password.length < 8) newErrors.password = 'Пароль должен содержать минимум 8 символов';
      
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Пароли не совпадают';
      }
      
      if (!formData.agreeToTerms) {
        newErrors.agreeToTerms = 'Необходимо принять условия использования';
      }
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validateStep(step)) {
      setStep(step + 1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validateStep(2)) return;
    
    setIsLoading(true);
    try {
      await authService.register(formData);
      // Redirect to email verification page
    } catch (error) {
      setErrors(error.fieldErrors || { general: error.message });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <LiquidGlass className="auth-card register-card" blur="medium">
          <div className="auth-header">
            <h1>Создать аккаунт</h1>
            <p>Присоединяйтесь к нашему сообществу</p>
          </div>

          <div className="progress-indicator">
            <div className={`progress-step ${step >= 1 ? 'active' : ''}`}>
              <span>1</span>
              <label>Личная информация</label>
            </div>
            <div className="progress-line"></div>
            <div className={`progress-step ${step >= 2 ? 'active' : ''}`}>
              <span>2</span>
              <label>Безопасность</label>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            {errors.general && (
              <div className="error-message">
                <Icon name="alert-circle" />
                {errors.general}
              </div>
            )}

            {step === 1 && (
              <div className="step-content" key="step1">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="firstName">Имя</label>
                    <input
                      id="firstName"
                      type="text"
                      placeholder="Иван"
                      value={formData.firstName}
                      onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                      className={errors.firstName ? 'error' : ''}
                    />
                    {errors.firstName && <span className="field-error">{errors.firstName}</span>}
                  </div>

                  <div className="form-group">
                    <label htmlFor="lastName">Фамилия</label>
                    <input
                      id="lastName"
                      type="text"
                      placeholder="Иванов"
                      value={formData.lastName}
                      onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                      className={errors.lastName ? 'error' : ''}
                    />
                    {errors.lastName && <span className="field-error">{errors.lastName}</span>}
                  </div>
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email адрес</label>
                  <div className="input-wrapper">
                    <Icon name="mail" className="input-icon" />
                    <input
                      id="email"
                      type="email"
                      placeholder="ivan@example.com"
                      value={formData.email}
                      onChange={(e) => setFormData({...formData, email: e.target.value})}
                      className={errors.email ? 'error' : ''}
                    />
                  </div>
                  {errors.email && <span className="field-error">{errors.email}</span>}
                </div>

                <Button
                  type="button"
                  onClick={handleNext}
                  variant="glass-primary"
                  fullWidth
                >
                  Продолжить
                </Button>
              </div>
            )}

            {step === 2 && (
              <div className="step-content" key="step2">
                <div className="form-group">
                  <label htmlFor="password">Пароль</label>
                  <div className="input-wrapper">
                    <Icon name="lock" className="input-icon" />
                    <PasswordInput
                      id="password"
                      placeholder="Минимум 8 символов"
                      value={formData.password}
                      onChange={(value) => setFormData({...formData, password: value})}
                      className={errors.password ? 'error' : ''}
                      showStrength
                    />
                  </div>
                  {errors.password && <span className="field-error">{errors.password}</span>}
                </div>

                <div className="form-group">
                  <label htmlFor="confirmPassword">Подтвердить пароль</label>
                  <div className="input-wrapper">
                    <Icon name="lock" className="input-icon" />
                    <PasswordInput
                      id="confirmPassword"
                      placeholder="Повторите пароль"
                      value={formData.confirmPassword}
                      onChange={(value) => setFormData({...formData, confirmPassword: value})}
                      className={errors.confirmPassword ? 'error' : ''}
                    />
                  </div>
                  {errors.confirmPassword && <span className="field-error">{errors.confirmPassword}</span>}
                </div>

                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.agreeToTerms}
                      onChange={(e) => setFormData({...formData, agreeToTerms: e.target.checked})}
                    />
                    <span className="checkmark"></span>
                    Я принимаю <a href="/terms" target="_blank">условия использования</a> и <a href="/privacy" target="_blank">политику конфиденциальности</a>
                  </label>
                  {errors.agreeToTerms && <span className="field-error">{errors.agreeToTerms}</span>}
                </div>

                <div className="form-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.marketingEmails}
                      onChange={(e) => setFormData({...formData, marketingEmails: e.target.checked})}
                    />
                    <span className="checkmark"></span>
                    Получать новости и обновления по email
                  </label>
                </div>

                <div className="form-actions">
                  <Button
                    type="button"
                    onClick={() => setStep(1)}
                    variant="glass-outline"
                  >
                    Назад
                  </Button>
                  <Button
                    type="submit"
                    variant="glass-primary"
                    loading={isLoading}
                  >
                    Создать аккаунт
                  </Button>
                </div>
              </div>
            )}
          </form>

          <div className="auth-footer">
            <p>
              Уже есть аккаунт? <a href="/login">Войти</a>
            </p>
          </div>
        </LiquidGlass>
      </div>
    </div>
  );
};
```

### Восстановление пароля
**Назначение**: Сброс забытого пароля  
**Компоненты**: Email форма, инструкции, ссылка на вход  
**Glass эффекты**: Простая форма с фокусом на email поле  

```jsx
const ForgotPasswordPage = () => {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email.trim()) {
      setError('Email адрес обязателен');
      return;
    }

    setIsLoading(true);
    setError('');
    
    try {
      await authService.requestPasswordReset(email);
      setIsSubmitted(true);
    } catch (error) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="auth-page">
        <div className="auth-container">
          <LiquidGlass className="auth-card" blur="medium">
            <div className="success-content">
              <Icon name="mail" size={64} color="#4ECDC4" />
              <h1>Проверьте почту</h1>
              <p>
                Мы отправили инструкции по восстановлению пароля на адрес:
                <strong>{email}</strong>
              </p>
              <p className="hint">
                Не видите письмо? Проверьте папку "Спам" или попробуйте еще раз.
              </p>
              
              <div className="action-buttons">
                <Button href="/login" variant="glass-primary">
                  Вернуться к входу
                </Button>
                <Button
                  onClick={() => setIsSubmitted(false)}
                  variant="glass-outline"
                >
                  Изменить email
                </Button>
              </div>
            </div>
          </LiquidGlass>
        </div>
      </div>
    );
  }

  return (
    <div className="auth-page">
      <div className="auth-container">
        <LiquidGlass className="auth-card" blur="medium">
          <div className="auth-header">
            <h1>Забыли пароль?</h1>
            <p>Введите ваш email и мы отправим инструкции по восстановлению</p>
          </div>

          <form onSubmit={handleSubmit} className="auth-form">
            {error && (
              <div className="error-message">
                <Icon name="alert-circle" />
                {error}
              </div>
            )}

            <div className="form-group">
              <label htmlFor="email">Email адрес</label>
              <div className="input-wrapper">
                <Icon name="mail" className="input-icon" />
                <input
                  id="email"
                  type="email"
                  placeholder="example@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={error ? 'error' : ''}
                  required
                  autoFocus
                />
              </div>
            </div>

            <Button
              type="submit"
              variant="glass-primary"
              fullWidth
              loading={isLoading}
            >
              Отправить инструкции
            </Button>
          </form>

          <div className="auth-footer">
            <p>
              Вспомнили пароль? <a href="/login">Войти</a>
            </p>
          </div>
        </LiquidGlass>
      </div>
    </div>
  );
};  
**Компоненты**: Поля email/пароль, "Запомнить меня", восстановление  
**Glass эффекты**: Центральная форма входа  

```jsx
const LoginForm = () => (
  <LiquidGlass blur="medium" opacity={0.8} className="auth-form">
    <form>
      <Input type="email" placeholder="Email" glass />
      <Input type="password" placeholder="Пароль" glass />
      <Checkbox>Запомнить меня</Checkbox>
      <Button type="submit" variant="glass-primary">Войти</Button>
      <Link to="/forgot">Забыли пароль?</Link>
    </form>
  </LiquidGlass>
);
```

### Регистрация
**Назначение**: Создание нового аккаунта  
**Компоненты**: Регистрационная форма, согласие с условиями  
**Glass эффекты**: Многоступенчатая форма с glass-переходами  

### Восстановление пароля
**Назначение**: Сброс забытого пароля  
**Компоненты**: Поле email, инструкции по восстановлению  
**Glass эффекты**: Простая glass-форма с обратной связью  

### Подтверждение аккаунта
**Назначение**: Активация через email или SMS  
**Компоненты**: Код подтверждения, повторная отправка  
**Glass эффекты**: Код-панель с glass-цифрами  

### Двухфакторная аутентификация
**Назначение**: Дополнительная проверка безопасности  
**Компоненты**: QR-код, поле для кода, backup-коды  
**Glass эффекты**: Безопасная панель настроек  

---

## 👤 Пользовательские профили

### Личный профиль
**Назначение**: Информация о пользователе  
**Компоненты**: Аватар, личные данные, статистика активности  
**Glass эффекты**: Карточка профиля, информационные панели  

```jsx
const UserProfile = ({ user }) => (
  <div className="profile-container">
    <LiquidGlass blur="light" className="profile-header">
      <Avatar src={user.avatar} size="large" />
      <h1>{user.name}</h1>
      <p>{user.title}</p>
    </LiquidGlass>
    
    <LiquidGlass blur="medium" className="profile-stats">
      <StatCard label="Проекты" value={user.projects} />
      <StatCard label="Подписчики" value={user.followers} />
      <StatCard label="Рейтинг" value={user.rating} />
    </LiquidGlass>
  </div>
);
```

### Редактирование профиля
**Назначение**: Изменение персональных данных  
**Компоненты**: Редактируемые поля, загрузка фото, сохранение  
**Glass эффекты**: Интерактивные поля с glass-валидацией  

### Настройки аккаунта
**Назначение**: Конфигурация параметров  
**Компоненты**: Группированные настройки, переключатели  
**Glass эффекты**: Секционированные панели настроек  

### Настройки приватности
**Назначение**: Управление видимостью данных  
**Компоненты**: Уровни приватности, разрешения  
**Glass эффекты**: Защищенные панели настроек  

### Настройки уведомлений
**Назначение**: Конфигурация оповещений  
**Компоненты**: Типы уведомлений, каналы доставки  
**Glass эффекты**: Переключатели с glass-анимациями  

---

## 📝 Формы и взаимодействие

### Простая форма
**Назначение**: Базовый сбор информации  
**Компоненты**: Стандартные поля ввода, кнопка отправки  
**Glass эффекты**: Прозрачные поля ввода  

```jsx
const ContactForm = () => (
  <LiquidGlass blur="medium" className="contact-form">
    <h2>Связаться с нами</h2>
    <Input placeholder="Имя" glass />
    <Input type="email" placeholder="Email" glass />
    <Textarea placeholder="Сообщение" glass />
    <Button type="submit" variant="glass-accent">Отправить</Button>
  </LiquidGlass>
);
```

### Многошаговая форма
**Назначение**: Разбитый на этапы процесс  
**Компоненты**: Прогресс-бар, навигация между шагами  
**Glass эффекты**: Плавные переходы между этапами  

### Форма обратной связи
**Назначение**: Связь с поддержкой или командой  
**Компоненты**: Категория проблемы, описание, приложения  
**Glass эффекты**: Структурированная форма с glass-секциями  

### Анкета/Опрос
**Назначение**: Сбор мнений и данных исследований  
**Компоненты**: Различные типы вопросов, прогресс  
**Glass эффекты**: Интерактивные варианты ответов  

---

## 📊 Информационные страницы

### FAQ (Часто задаваемые вопросы)
**Назначение**: Ответы на популярные вопросы  
**Компоненты**: Аккордеон вопросов, поиск, категории  
**Glass эффекты**: Раскрывающиеся секции с glass-эффектами  

```jsx
const FAQItem = ({ question, answer, isOpen, onToggle }) => (
  <LiquidGlass 
    blur={isOpen ? "medium" : "light"} 
    className="faq-item"
    onClick={onToggle}
  >
    <div className="faq-question">
      {question}
      <Icon name={isOpen ? "chevron-up" : "chevron-down"} />
    </div>
    {isOpen && (
      <div className="faq-answer glass-reveal">
        {answer}
      </div>
    )}
  </LiquidGlass>
);
```

### О компании/проекте
**Назначение**: Описание организации  
**Компоненты**: История, миссия, команда, достижения  
**Glass эффекты**: Карточки команды, временная линия  

### Контакты
**Назначение**: Способы связи и реквизиты  
**Компоненты**: Карта, адреса, телефоны, форма связи  
**Glass эффекты**: Контактные карточки, интерактивная карта  

### Помощь и поддержка
**Назначение**: Центр помощи пользователям  
**Компоненты**: База знаний, поиск, чат поддержки  
**Glass эффекты**: Панель быстрой помощи  

---

## ⚠️ Состояния и ошибки

### 404 - Не найдено
**Назначение**: Страница отсутствует  
**Компоненты**: Сообщение об ошибке, навигация, поиск  
**Glass эффекты**: Центральная карточка с ошибкой  

```jsx
const NotFoundPage = () => (
  <div className="error-container">
    <LiquidGlass blur="heavy" className="error-card">
      <h1>404</h1>
      <p>Страница не найдена</p>
      <Button variant="glass" onClick={() => history.back()}>
        Вернуться назад
      </Button>
    </LiquidGlass>
  </div>
);
```

### 500 - Ошибка сервера
**Назначение**: Технические проблемы  
**Компоненты**: Сообщение об ошибке, обновление страницы  
**Glass эффекты**: Предупреждающая glass-карточка  

### Пустое состояние
**Назначение**: Отсутствие данных для отображения  
**Компоненты**: Объяснение, действия для заполнения  
**Glass эффекты**: Мотивирующая карточка действий  

### Состояние загрузки
**Назначение**: Индикаторы процесса  
**Компоненты**: Спиннеры, прогресс-бары, скелетоны  
**Glass эффекты**: Пульсирующие glass-скелетоны  

---

## 🎨 Дизайн-система модулей

### Glass UI Kit
```scss
// Базовые стили для модулей
.glass-module {
  @include glass-effect();
  border-radius: 16px;
  padding: 24px;
  margin: 16px 0;
  
  &.glass-interactive {
    @include glass-hover();
    cursor: pointer;
  }
  
  &.glass-elevated {
    @include glass-elevation(2);
  }
}

// Анимации переходов
.glass-transition {
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}

// Адаптивность
@media (max-width: 768px) {
  .glass-module {
    padding: 16px;
    margin: 8px 0;
  }
}
```

### Компонентная архитектура
```jsx
// Базовый HOC для glass-модулей
const withGlassEffect = (Component) => {
  return forwardRef((props, ref) => {
    const { glass = true, ...otherProps } = props;
    
    return (
      <LiquidGlass
        ref={ref}
        blur="medium"
        opacity={0.8}
        className={`glass-module ${props.className || ''}`}
        {...(glass && { 'data-glass': true })}
      >
        <Component {...otherProps} />
      </LiquidGlass>
    );
  });
};

// Использование
const GlassCard = withGlassEffect(Card);
const GlassForm = withGlassEffect(Form);
```

---

## 📱 Мобильная адаптация

### Responsive Glass Effects
```jsx
const MobileGlassModule = ({ children, ...props }) => {
  const isMobile = useMediaQuery('(max-width: 768px)');
  
  return (
    <LiquidGlass
      blur={isMobile ? "light" : "medium"}
      opacity={isMobile ? 0.95 : 0.8}
      className="mobile-adaptive-glass"
      {...props}
    >
      {children}
    </LiquidGlass>
  );
};
```

### Touch-Friendly Interactions
```scss
.glass-module {
  // Увеличенные touch-targets на мобильных
  @media (max-width: 768px) {
    min-height: 44px;
    
    .glass-button {
      min-height: 44px;
      padding: 12px 16px;
    }
  }
}
```

---

## ♿ Accessibility

### Screen Reader Support
```jsx
const AccessibleGlassModule = ({ children, ariaLabel, ...props }) => (
  <LiquidGlass
    role="region"
    aria-label={ariaLabel}
    className="glass-module accessible"
    {...props}
  >
    {children}
  </LiquidGlass>
);
```

### High Contrast Mode
```scss
@media (prefers-contrast: high) {
  .glass-module {
    background: rgba(255, 255, 255, 0.95);
    border: 2px solid currentColor;
    backdrop-filter: none;
  }
}

@media (prefers-reduced-motion: reduce) {
  .glass-module {
    transition: none;
    animation: none;
  }
}
```

Основные пользовательские модули готовы! Переходим к созданию контентных и медиа модулей. 🎯