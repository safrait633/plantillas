# Liquid Glass - Оптимизация производительности: Memory Management

Вторая часть комплексного руководства по оптимизации производительности Liquid Glass эффектов, фокусирующаяся на управлении памятью и профилировании.

## Содержание

1. [Memory Management](#memory-management)
2. [Профилирование blur эффектов](#профилирование-blur-эффектов)
3. [Мониторинг производительности](#мониторинг-производительности)
4. [Оптимизация утечек памяти](#оптимизация-утечек-памяти)

---

## Memory Management

### JavaScript Memory Optimization

```javascript
class MemoryOptimizedGlass {
  constructor() {
    this.textureCache = new Map();
    this.geometryPool = [];
    this.maxCacheSize = 50;
    
    this.setupMemoryMonitoring();
  }
  
  setupMemoryMonitoring() {
    if ('memory' in performance) {
      setInterval(() => {
        const memory = performance.memory;
        const usedMemory = memory.usedJSHeapSize;
        const totalMemory = memory.totalJSHeapSize;
        
        if (usedMemory / totalMemory > 0.8) {
          this.cleanupMemory();
        }
      }, 5000);
    }
  }
  
  cleanupMemory() {
    // Очистка текстурного кэша
    if (this.textureCache.size > this.maxCacheSize) {
      const entries = Array.from(this.textureCache.entries());
      const toDelete = entries.slice(0, entries.length - this.maxCacheSize);
      
      toDelete.forEach(([key, texture]) => {
        texture.dispose?.();
        this.textureCache.delete(key);
      });
    }
    
    // Принудительная сборка мусора (если доступна)
    if (window.gc) {
      window.gc();
    }
  }
  
  createOptimizedTexture(width, height) {
    const key = `${width}x${height}`;
    
    if (this.textureCache.has(key)) {
      return this.textureCache.get(key);
    }
    
    // Используем object pooling для текстур
    const texture = this.geometryPool.pop() || this.createNewTexture();
    texture.resize(width, height);
    
    this.textureCache.set(key, texture);
    return texture;
  }
  
  disposeTexture(texture) {
    // Возвращаем в pool вместо удаления
    texture.clear();
    this.geometryPool.push(texture);
  }
}

// Weak references для предотвращения утечек памяти
class GlassElementRegistry {
  constructor() {
    this.elements = new WeakMap();
    this.observers = new WeakSet();
  }
  
  register(element, glassEffect) {
    this.elements.set(element, glassEffect);
    
    // Автоматическая очистка при удалении элемента
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.removedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE && this.elements.has(node)) {
            const effect = this.elements.get(node);
            effect.dispose?.();
            this.elements.delete(node);
          }
        });
      });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
    this.observers.add(observer);
  }
}
```

### Swift Memory Management

```swift
import UIKit

class MemoryEfficientGlassView: UIView {
    private var blurEffectView: UIVisualEffectView?
    private var memoryWarningObserver: NSObjectProtocol?
    private static var textureCache = NSCache<NSString, UIImage>()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupMemoryManagement()
    }
    
    private func setupMemoryManagement() {
        // Настройка кэша
        Self.textureCache.countLimit = 20
        Self.textureCache.totalCostLimit = 50 * 1024 * 1024 // 50MB
        
        // Слушатель предупреждений о памяти
        memoryWarningObserver = NotificationCenter.default.addObserver(
            forName: UIApplication.didReceiveMemoryWarningNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            self?.handleMemoryWarning()
        }
    }
    
    private func handleMemoryWarning() {
        // Очистка кэша при нехватке памяти
        Self.textureCache.removeAllObjects()
        
        // Уменьшение качества blur
        if let blurEffect = blurEffectView?.effect as? UIBlurEffect {
            let lighterEffect = UIBlurEffect(style: .light) // Менее ресурсоемкий
            blurEffectView?.effect = lighterEffect
        }
    }
    
    func applyGlassEffect(intensity: CGFloat) {
        // Ленивая инициализация
        if blurEffectView == nil {
            let blurEffect = UIBlurEffect(style: .regular)
            blurEffectView = UIVisualEffectView(effect: blurEffect)
            blurEffectView?.frame = bounds
            blurEffectView?.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            addSubview(blurEffectView!)
        }
        
        // Используем animator для эффективных анимаций
        let animator = UIViewPropertyAnimator(duration: 0.3, curve: .easeInOut) {
            self.blurEffectView?.alpha = intensity
        }
        animator.startAnimation()
    }
    
    deinit {
        if let observer = memoryWarningObserver {
            NotificationCenter.default.removeObserver(observer)
        }
    }
}

// MARK: - Texture Management
extension MemoryEfficientGlassView {
    private func getCachedTexture(for size: CGSize) -> UIImage? {
        let key = "\(size.width)x\(size.height)" as NSString
        return Self.textureCache.object(forKey: key)
    }
    
    private func setCachedTexture(_ image: UIImage, for size: CGSize) {
        let key = "\(size.width)x\(size.height)" as NSString
        let cost = Int(size.width * size.height * 4) // RGBA bytes
        Self.textureCache.setObject(image, forKey: key, cost: cost)
    }
}
```

### Android Memory Optimization

```kotlin
class MemoryOptimizedGlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    
    companion object {
        private val bitmapCache = LruCache<String, Bitmap>(
            (Runtime.getRuntime().maxMemory() / 8).toInt()
        )
        
        private const val MAX_TEXTURE_SIZE = 2048
    }
    
    private var blurBitmap: Bitmap? = null
    private var canvas: Canvas? = null
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    
    init {
        setupMemoryManagement()
    }
    
    private fun setupMemoryManagement() {
        // Мониторинг памяти
        registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                when (level) {
                    ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE,
                    ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW,
                    ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL -> {
                        clearMemoryCache()
                    }
                }
            }
            
            override fun onConfigurationChanged(newConfig: Configuration) {}
            override fun onLowMemory() {
                clearMemoryCache()
            }
        })
    }
    
    private fun clearMemoryCache() {
        bitmapCache.evictAll()
        blurBitmap?.recycle()
        blurBitmap = null
        System.gc() // Принудительная сборка мусора
    }
    
    fun applyBlurEffect(radius: Float) {
        val key = "${width}x${height}_$radius"
        
        // Проверяем кэш
        var cached = bitmapCache.get(key)
        if (cached != null && !cached.isRecycled) {
            blurBitmap = cached
            invalidate()
            return
        }
        
        // Создаем оптимизированную текстуру
        val scaledWidth = minOf(width, MAX_TEXTURE_SIZE)
        val scaledHeight = minOf(height, MAX_TEXTURE_SIZE)
        
        try {
            blurBitmap = Bitmap.createBitmap(
                scaledWidth, 
                scaledHeight, 
                Bitmap.Config.ARGB_8888
            )
            
            // Применяем blur с RenderScript для GPU ускорения
            applyRenderScriptBlur(blurBitmap!!, radius)
            
            // Кэшируем результат
            bitmapCache.put(key, blurBitmap)
            
        } catch (e: OutOfMemoryError) {
            // Fallback при нехватке памяти
            clearMemoryCache()
            // Пробуем с меньшим размером
            applyFallbackBlur(radius / 2)
        }
        
        invalidate()
    }
    
    private fun applyRenderScriptBlur(bitmap: Bitmap, radius: Float) {
        val renderScript = RenderScript.create(context)
        val input = Allocation.createFromBitmap(renderScript, bitmap)
        val output = Allocation.createTyped(renderScript, input.type)
        val script = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript))
        
        script.setRadius(radius.coerceIn(0.1f, 25.0f))
        script.setInput(input)
        script.forEach(output)
        output.copyTo(bitmap)
        
        // Cleanup
        input.destroy()
        output.destroy()
        script.destroy()
        renderScript.destroy()
    }
    
    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        blurBitmap?.recycle()
        blurBitmap = null
    }
}
```

---

## Профилирование blur эффектов

### Web Performance Profiling

```javascript
class BlurPerformanceProfiler {
  constructor() {
    this.metrics = {
      renderTimes: [],
      memoryUsage: [],
      frameDrops: 0,
      gpuUtilization: []
    };
    
    this.setupProfiling();
  }
  
  setupProfiling() {
    // Performance Observer для мониторинга
    if ('PerformanceObserver' in window) {
      const observer = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (entry.entryType === 'measure' && entry.name.includes('blur-render')) {
            this.metrics.renderTimes.push(entry.duration);
          }
        }
      });
      
      observer.observe({ entryTypes: ['measure'] });
    }
    
    // RAF для мониторинга FPS
    this.startFPSMonitoring();
  }
  
  startFPSMonitoring() {
    let frameCount = 0;
    let lastTime = performance.now();
    
    const countFPS = () => {
      frameCount++;
      const currentTime = performance.now();
      
      if (currentTime - lastTime >= 1000) {
        const fps = Math.round((frameCount * 1000) / (currentTime - lastTime));
        
        if (fps < 55) { // Порог для 60fps
          this.metrics.frameDrops++;
          this.optimizeBlurQuality();
        }
        
        frameCount = 0;
        lastTime = currentTime;
      }
      
      requestAnimationFrame(countFPS);
    };
    
    requestAnimationFrame(countFPS);
  }
  
  profileBlurOperation(blurRadius, elementCount) {
    const startTime = performance.now();
    
    // Замеряем память до операции
    const memoryBefore = this.getMemoryUsage();
    
    performance.mark('blur-start');
    
    // Выполняем blur операцию
    this.applyBlurToElements(blurRadius, elementCount);
    
    performance.mark('blur-end');
    performance.measure('blur-render', 'blur-start', 'blur-end');
    
    const endTime = performance.now();
    const memoryAfter = this.getMemoryUsage();
    
    // Записываем метрики
    this.recordMetrics({
      duration: endTime - startTime,
      memoryDelta: memoryAfter - memoryBefore,
      blurRadius,
      elementCount
    });
  }
  
  getMemoryUsage() {
    if ('memory' in performance) {
      return performance.memory.usedJSHeapSize;
    }
    return 0;
  }
  
  recordMetrics(metrics) {
    console.log('Blur Performance Metrics:', {
      duration: `${metrics.duration.toFixed(2)}ms`,
      memoryDelta: `${(metrics.memoryDelta / 1024 / 1024).toFixed(2)}MB`,
      efficiency: `${(metrics.elementCount / metrics.duration * 1000).toFixed(0)} elements/sec`
    });
    
    // Адаптивная оптимизация
    if (metrics.duration > 16.67) { // > 60fps
      this.suggestOptimizations(metrics);
    }
  }
  
  suggestOptimizations(metrics) {
    const suggestions = [];
    
    if (metrics.blurRadius > 15) {
      suggestions.push('Reduce blur radius for better performance');
    }
    
    if (metrics.elementCount > 10) {
      suggestions.push('Consider blur batching or element culling');
    }
    
    if (metrics.memoryDelta > 10 * 1024 * 1024) { // 10MB
      suggestions.push('Memory usage is high, implement texture pooling');
    }
    
    console.warn('Performance Suggestions:', suggestions);
  }
  
  optimizeBlurQuality() {
    // Автоматическое снижение качества
    document.documentElement.style.setProperty('--blur-quality', 'low');
    
    setTimeout(() => {
      document.documentElement.style.setProperty('--blur-quality', 'high');
    }, 2000);
  }
  
  generateReport() {
    const avgRenderTime = this.metrics.renderTimes.reduce((a, b) => a + b, 0) / this.metrics.renderTimes.length;
    
    return {
      averageRenderTime: avgRenderTime.toFixed(2) + 'ms',
      frameDrops: this.metrics.frameDrops,
      memoryPeak: Math.max(...this.metrics.memoryUsage),
      recommendations: this.getRecommendations(avgRenderTime)
    };
  }
  
  getRecommendations(avgRenderTime) {
    const recommendations = [];
    
    if (avgRenderTime > 16.67) {
      recommendations.push('Consider reducing blur complexity');
      recommendations.push('Implement blur LOD (Level of Detail)');
    }
    
    if (this.metrics.frameDrops > 5) {
      recommendations.push('Enable adaptive quality scaling');
    }
    
    return recommendations;
  }
}

// Использование
const profiler = new BlurPerformanceProfiler();
profiler.profileBlurOperation(12, 5);
```

### iOS Instruments Integration

```swift
import os.signpost

class iOSBlurProfiler {
    private let subsystem = "com.app.liquidglass"
    private let category = "BlurPerformance"
    private lazy var logger = OSLog(subsystem: subsystem, category: category)
    
    func profileBlurOperation<T>(
        name: String,
        operation: () throws -> T
    ) rethrows -> T {
        let signpostID = OSSignpostID(log: logger)
        
        os_signpost(.begin, log: logger, name: "Blur Operation", signpostID: signpostID,
                   "Operation: %{public}s", name)
        
        let startTime = CACurrentMediaTime()
        let startMemory = mach_task_basic_info()
        
        defer {
            let duration = CACurrentMediaTime() - startTime
            let endMemory = mach_task_basic_info()
            let memoryDelta = endMemory.resident_size - startMemory.resident_size
            
            os_signpost(.end, log: logger, name: "Blur Operation", signpostID: signpostID,
                       "Duration: %.2fms, Memory: %lld bytes", duration * 1000, memoryDelta)
        }
        
        return try operation()
    }
    
    private func mach_task_basic_info() -> mach_task_basic_info {
        var info = mach_task_basic_info()
        var count = mach_msg_type_number_t(MemoryLayout<mach_task_basic_info>.size) / 4
        
        let result = withUnsafeMutablePointer(to: &info) {
            $0.withMemoryRebound(to: integer_t.self, capacity: 1) {
                task_info(mach_task_self_, task_flavor_t(MACH_TASK_BASIC_INFO), $0, &count)
            }
        }
        
        guard result == KERN_SUCCESS else { return mach_task_basic_info() }
        return info
    }
    
    func measureFrameRate(duration: TimeInterval = 5.0) {
        var frameCount = 0
        let startTime = CACurrentMediaTime()
        
        let displayLink = CADisplayLink(target: self, selector: #selector(frameCallback))
        displayLink.add(to: .main, forMode: .common)
        
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            displayLink.invalidate()
            let actualDuration = CACurrentMediaTime() - startTime
            let fps = Double(frameCount) / actualDuration
            
            os_log(.info, log: self.logger, "Average FPS: %.1f", fps)
            
            if fps < 55 {
                os_log(.error, log: self.logger, "Performance warning: Low FPS detected")
            }
        }
        
        @objc func frameCallback() {
            frameCount += 1
        }
    }
}

// Использование в SwiftUI
struct ProfiledGlassView: View {
    private let profiler = iOSBlurProfiler()
    
    var body: some View {
        VStack {
            Text("Content")
        }
        .background(.ultraThinMaterial)
        .onAppear {
            profiler.profileBlurOperation(name: "Glass View Setup") {
                // Setup код
            }
            
            profiler.measureFrameRate()
        }
    }
}
```

### Android Profiling

```kotlin
class AndroidBlurProfiler {
    private val choreographer = Choreographer.getInstance()
    private var frameCallback: Choreographer.FrameCallback? = null
    private var frameCount = 0
    private var startTime = 0L
    
    fun profileBlurOperation(name: String, operation: () -> Unit) {
        val startTime = System.nanoTime()
        val startMemory = getMemoryUsage()
        
        Trace.beginSection("BlurOperation_$name")
        
        try {
            operation()
        } finally {
            Trace.endSection()
            
            val duration = (System.nanoTime() - startTime) / 1_000_000.0 // ms
            val endMemory = getMemoryUsage()
            val memoryDelta = endMemory - startMemory
            
            Log.d("BlurProfiler", """
                Operation: $name
                Duration: ${duration.format(2)}ms
                Memory Delta: ${(memoryDelta / 1024 / 1024).format(2)}MB
            """.trimIndent())
            
            if (duration > 16.67) {
                Log.w("BlurProfiler", "Performance warning: Operation took ${duration.format(2)}ms")
            }
        }
    }
    
    private fun getMemoryUsage(): Long {
        val runtime = Runtime.getRuntime()
        return runtime.totalMemory() - runtime.freeMemory()
    }
    
    fun startFPSMonitoring() {
        startTime = System.currentTimeMillis()
        frameCount = 0
        
        frameCallback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                frameCount++
                choreographer.postFrameCallback(this)
                
                // Проверяем каждую секунду
                if (frameCount % 60 == 0) {
                    val currentTime = System.currentTimeMillis()
                    val actualDuration = currentTime - startTime
                    val fps = (frameCount * 1000.0) / actualDuration
                    
                    Log.d("BlurProfiler", "Current FPS: ${fps.format(1)}")
                    
                    if (fps < 55) {
                        Log.w("BlurProfiler", "Low FPS detected: ${fps.format(1)}")
                    }
                }
            }
        }
        
        choreographer.postFrameCallback(frameCallback!!)
    }
    
    fun stopFPSMonitoring() {
        frameCallback?.let { choreographer.removeFrameCallback(it) }
        frameCallback = null
    }
    
    private fun Double.format(digits: Int) = "%.${digits}f".format(this)
}

// GPU профилирование
class GPUProfiler {
    fun measureGPUUsage(): Float {
        return try {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memoryInfo = ActivityManager.MemoryInfo()
            activityManager.getMemoryInfo(memoryInfo)
            
            // Приблизительная оценка GPU использования
            val totalMemory = memoryInfo.totalMem.toFloat()
            val availableMemory = memoryInfo.availMem.toFloat()
            val usedMemory = totalMemory - availableMemory
            
            (usedMemory / totalMemory) * 100
        } catch (e: Exception) {
            0f
        }
    }
    
    fun detectThermalThrottling(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val thermalService = context.getSystemService(Context.THERMAL_SERVICE) as ThermalManager
            thermalService.currentThermalStatus >= ThermalManager.THERMAL_STATUS_MODERATE
        } else {
            false
        }
    }
}
```

---

## Мониторинг производительности

### Real-time Memory Monitoring

```javascript
class MemoryMonitor {
  constructor(options = {}) {
    this.thresholds = {
      warning: options.warningThreshold || 70, // %
      critical: options.criticalThreshold || 85, // %
      ...options.thresholds
    };
    
    this.callbacks = {
      warning: [],
      critical: [],
      normal: []
    };
    
    this.isMonitoring = false;
    this.monitoringInterval = null;
  }
  
  startMonitoring(interval = 1000) {
    if (this.isMonitoring) return;
    
    this.isMonitoring = true;
    this.monitoringInterval = setInterval(() => {
      this.checkMemoryUsage();
    }, interval);
  }
  
  stopMonitoring() {
    if (this.monitoringInterval) {
      clearInterval(this.monitoringInterval);
      this.monitoringInterval = null;
    }
    this.isMonitoring = false;
  }
  
  checkMemoryUsage() {
    if (!('memory' in performance)) return;
    
    const memory = performance.memory;
    const usagePercent = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
    
    let status = 'normal';
    if (usagePercent >= this.thresholds.critical) {
      status = 'critical';
    } else if (usagePercent >= this.thresholds.warning) {
      status = 'warning';
    }
    
    this.triggerCallbacks(status, {
      usagePercent,
      usedMemory: memory.usedJSHeapSize,
      totalMemory: memory.jsHeapSizeLimit,
      availableMemory: memory.jsHeapSizeLimit - memory.usedJSHeapSize
    });
  }
  
  onMemoryStatus(status, callback) {
    if (!this.callbacks[status]) {
      this.callbacks[status] = [];
    }
    this.callbacks[status].push(callback);
  }
  
  triggerCallbacks(status, memoryInfo) {
    this.callbacks[status]?.forEach(callback => {
      try {
        callback(memoryInfo);
      } catch (error) {
        console.error('Memory monitor callback error:', error);
      }
    });
  }
  
  getMemoryReport() {
    if (!('memory' in performance)) {
      return { error: 'Memory API not available' };
    }
    
    const memory = performance.memory;
    return {
      used: this.formatBytes(memory.usedJSHeapSize),
      total: this.formatBytes(memory.jsHeapSizeLimit),
      usagePercent: ((memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100).toFixed(2) + '%',
      available: this.formatBytes(memory.jsHeapSizeLimit - memory.usedJSHeapSize)
    };
  }
  
  formatBytes(bytes) {
    const units = ['B', 'KB', 'MB', 'GB'];
    let size = bytes;
    let unitIndex = 0;
    
    while (size >= 1024 && unitIndex < units.length - 1) {
      size /= 1024;
      unitIndex++;
    }
    
    return `${size.toFixed(2)} ${units[unitIndex]}`;
  }
}

// Использование
const memoryMonitor = new MemoryMonitor({
  warningThreshold: 60,
  criticalThreshold: 80
});

memoryMonitor.onMemoryStatus('warning', (info) => {
  console.warn('Memory usage warning:', info.usagePercent);
  // Снижаем качество blur
  document.documentElement.style.setProperty('--blur-quality', 'medium');
});

memoryMonitor.onMemoryStatus('critical', (info) => {
  console.error('Critical memory usage:', info.usagePercent);
  // Минимальное качество blur
  document.documentElement.style.setProperty('--blur-quality', 'minimal');
  // Очищаем кэши
  window.glassEffectManager?.clearCaches();
});

memoryMonitor.startMonitoring();
```

---

## Оптимизация утечек памяти

### Leak Detection and Prevention

```javascript
class LeakDetector {
  constructor() {
    this.trackedObjects = new WeakSet();
    this.objectCounts = new Map();
    this.leakThreshold = 100; // объектов одного типа
  }
  
  track(object, type = 'unknown') {
    this.trackedObjects.add(object);
    
    const count = this.objectCounts.get(type) || 0;
    this.objectCounts.set(type, count + 1);
    
    // Проверяем на потенциальные утечки
    if (count > this.leakThreshold) {
      console.warn(`Potential memory leak detected: ${type} (${count} objects)`);
    }
  }
  
  untrack(object, type = 'unknown') {
    if (this.trackedObjects.has(object)) {
      this.trackedObjects.delete(object);
      
      const count = this.objectCounts.get(type) || 0;
      if (count > 0) {
        this.objectCounts.set(type, count - 1);
      }
    }
  }
  
  getLeakReport() {
    const report = {};
    for (const [type, count] of this.objectCounts.entries()) {
      if (count > this.leakThreshold / 2) {
        report[type] = {
          count,
          status: count > this.leakThreshold ? 'warning' : 'watching'
        };
      }
    }
    return report;
  }
}

// Автоматическое отслеживание DOM элементов
class DOMLeakDetector {
  constructor() {
    this.elementCounts = new Map();
    this.observer = new MutationObserver(this.handleMutations.bind(this));
    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'data-glass']
    });
  }
  
  handleMutations(mutations) {
    mutations.forEach(mutation => {
      mutation.addedNodes.forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          this.trackElement(node);
        }
      });
      
      mutation.removedNodes.forEach(node => {
        if (node.nodeType === Node.ELEMENT_NODE) {
          this.untrackElement(node);
        }
      });
    });
  }
  
  trackElement(element) {
    const className = element.className || 'no-class';
    const count = this.elementCounts.get(className) || 0;
    this.elementCounts.set(className, count + 1);
  }
  
  untrackElement(element) {
    const className = element.className || 'no-class';
    const count = this.elementCounts.get(className) || 0;
    if (count > 0) {
      this.elementCounts.set(className, count - 1);
    }
  }
  
  getDOMReport() {
    return Array.from(this.elementCounts.entries())
      .filter(([, count]) => count > 50)
      .sort((a, b) => b[1] - a[1]);
  }
}

// Глобальные детекторы
const leakDetector = new LeakDetector();
const domLeakDetector = new DOMLeakDetector();

// Интеграция с Glass компонентами
class LeakSafeGlassComponent {
  constructor(element) {
    this.element = element;
    this.resources = [];
    
    leakDetector.track(this, 'GlassComponent');
  }
  
  addResource(resource) {
    this.resources.push(resource);
    leakDetector.track(resource, 'GlassResource');
  }
  
  dispose() {
    // Очищаем все ресурсы
    this.resources.forEach(resource => {
      resource.dispose?.();
      leakDetector.untrack(resource, 'GlassResource');
    });
    
    this.resources = [];
    leakDetector.untrack(this, 'GlassComponent');
  }
}
```

---

## Заключение части 2

Во второй части мы рассмотрели:

### 🧠 **Memory Management:**
1. **JavaScript** - texture caching, object pooling, WeakMap/WeakSet
2. **Swift** - NSCache, memory warnings, автоматическая очистка
3. **Android** - LruCache, ComponentCallbacks2, OOM handling

### 📊 **Профилирование:**
- **Web** - Performance API, FPS мониторинг, memory tracking
- **iOS** - Instruments integration, os_signpost, mach_task_basic_info
- **Android** - Choreographer, Trace API, memory profiling

### 🔍 **Мониторинг:**
- Real-time memory monitoring
- Leak detection и prevention
- Автоматическое отслеживание DOM

**📋 Связанные документы:**
- [Liquid-Glass-Performance-GPU.md] - GPU оптимизация
- [Liquid-Glass-Performance-Platform.md] - платформо-специфичные оптимизации