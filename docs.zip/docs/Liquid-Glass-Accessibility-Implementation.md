# Liquid Glass - Accessibility: Техническая реализация

Подробное руководство по технической реализации accessibility в Liquid Glass эффектах на всех платформах.

## Содержание

1. [Screen Readers поддержка](#screen-readers-поддержка)
2. [High Contrast Implementation](#high-contrast-implementation)
3. [Reduce Motion Implementation](#reduce-motion-implementation)
4. [Keyboard Navigation](#keyboard-navigation)
5. [Platform Accessibility APIs](#platform-accessibility-apis)
6. [ARIA и семантика](#aria-и-семантика)

---

## Screen Readers поддержка

### Web Screen Readers

```javascript
class ScreenReaderGlassSupport {
  constructor() {
    this.setupScreenReaderSupport();
    this.enhanceGlassElements();
  }
  
  setupScreenReaderSupport() {
    // Определяем активность screen reader
    this.isScreenReaderActive = this.detectScreenReader();
    
    if (this.isScreenReaderActive) {
      this.applyScreenReaderOptimizations();
    }
  }
  
  detectScreenReader() {
    // Несколько методов детекции
    const checks = [
      // Проверка на NVDA/JAWS
      () => window.speechSynthesis && window.speechSynthesis.getVoices().length > 0,
      
      // Проверка navigator properties
      () => navigator.userAgent.includes('NVDA') || 
            navigator.userAgent.includes('JAWS') ||
            navigator.userAgent.includes('Window-Eyes'),
      
      // Проверка на VoiceOver (macOS)
      () => window.navigator.platform.includes('Mac') && 
            window.speechSynthesis,
      
      // Проверка accessibility API
      () => 'speechSynthesis' in window || 'webkitSpeechSynthesis' in window
    ];
    
    return checks.some(check => check());
  }
  
  applyScreenReaderOptimizations() {
    // Отключаем сложные визуальные эффекты
    document.documentElement.classList.add('screen-reader-active');
    
    // Упрощаем glass эффекты
    const style = document.createElement('style');
    style.textContent = `
      .screen-reader-active .glass-element {
        backdrop-filter: none !important;
        background: rgba(255, 255, 255, 0.95) !important;
        border: 2px solid #000 !important;
      }
    `;
    document.head.appendChild(style);
  }
  
  enhanceGlassElements() {
    const glassElements = document.querySelectorAll('.glass-element');
    
    glassElements.forEach(element => {
      this.addScreenReaderSupport(element);
    });
  }
  
  addScreenReaderSupport(element) {
    // Добавляем ARIA attributes
    if (!element.getAttribute('role')) {
      element.setAttribute('role', 'region');
    }
    
    // Описание для screen reader
    if (!element.getAttribute('aria-describedby')) {
      const descriptionId = `glass-desc-${Math.random().toString(36).substr(2, 9)}`;
      const description = document.createElement('span');
      description.id = descriptionId;
      description.className = 'sr-only';
      description.textContent = this.generateGlassDescription(element);
      
      element.appendChild(description);
      element.setAttribute('aria-describedby', descriptionId);
    }
    
    // Live region для динамических изменений
    if (element.hasAttribute('data-dynamic')) {
      element.setAttribute('aria-live', 'polite');
      element.setAttribute('aria-atomic', 'true');
    }
  }
  
  generateGlassDescription(element) {
    const computedStyle = window.getComputedStyle(element);
    const hasBlur = computedStyle.backdropFilter !== 'none';
    const opacity = parseFloat(computedStyle.opacity || '1');
    
    let description = 'Контейнер';
    
    if (hasBlur) {
      description += ' с эффектом размытого стекла';
    }
    
    if (opacity < 0.9) {
      description += ', полупрозрачный';
    }
    
    // Определяем содержимое
    const hasInteractiveContent = element.querySelector('button, a, input, select, textarea');
    if (hasInteractiveContent) {
      description += ', содержит интерактивные элементы';
    }
    
    return description;
  }
  
  announceGlassStateChange(element, newState) {
    if (!this.isScreenReaderActive) return;
    
    const announcement = document.createElement('div');
    announcement.setAttribute('aria-live', 'assertive');
    announcement.setAttribute('aria-atomic', 'true');
    announcement.className = 'sr-only';
    announcement.textContent = `Состояние элемента изменено: ${newState}`;
    
    document.body.appendChild(announcement);
    
    setTimeout(() => {
      document.body.removeChild(announcement);
    }, 1000);
  }
}

// Utility для screen-reader only контента
class ScreenReaderUtils {
  static createSROnlyElement(text, tag = 'span') {
    const element = document.createElement(tag);
    element.className = 'sr-only';
    element.textContent = text;
    return element;
  }
  
  static addSRDescription(element, description) {
    const descId = `sr-desc-${Date.now()}`;
    const descElement = this.createSROnlyElement(description);
    descElement.id = descId;
    
    element.appendChild(descElement);
    element.setAttribute('aria-describedby', descId);
  }
  
  static announce(message, priority = 'polite') {
    const announcer = document.createElement('div');
    announcer.setAttribute('aria-live', priority);
    announcer.setAttribute('aria-atomic', 'true');
    announcer.className = 'sr-only';
    announcer.textContent = message;
    
    document.body.appendChild(announcer);
    
    setTimeout(() => {
      if (document.body.contains(announcer)) {
        document.body.removeChild(announcer);
      }
    }, 1000);
  }
}

// CSS для screen reader support
const srOnlyCSS = `
.sr-only {
  position: absolute !important;
  width: 1px !important;
  height: 1px !important;
  padding: 0 !important;
  margin: -1px !important;
  overflow: hidden !important;
  clip: rect(0, 0, 0, 0) !important;
  white-space: nowrap !important;
  border: 0 !important;
}

.sr-only:focus {
  position: static !important;
  width: auto !important;
  height: auto !important;
  padding: 0.5rem !important;
  margin: 0 !important;
  overflow: visible !important;
  clip: auto !important;
  white-space: normal !important;
  background: #fff !important;
  color: #000 !important;
  border: 2px solid #000 !important;
}
`;

// Добавляем CSS
const style = document.createElement('style');
style.textContent = srOnlyCSS;
document.head.appendChild(style);
```

### iOS VoiceOver Support

```swift
import UIKit
import AVFoundation

class VoiceOverGlassView: UIView {
    private var glassDescription: String = ""
    private var isVoiceOverRunning: Bool {
        return UIAccessibility.isVoiceOverRunning
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupVoiceOverSupport()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupVoiceOverSupport()
    }
    
    private func setupVoiceOverSupport() {
        // Базовая настройка accessibility
        isAccessibilityElement = true
        accessibilityTraits = .none
        
        // Мониторинг VoiceOver состояния
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(voiceOverStatusChanged),
            name: UIAccessibility.voiceOverStatusDidChangeNotification,
            object: nil
        )
        
        updateVoiceOverOptimizations()
    }
    
    @objc private func voiceOverStatusChanged() {
        updateVoiceOverOptimizations()
    }
    
    private func updateVoiceOverOptimizations() {
        if isVoiceOverRunning {
            // Упрощаем визуальные эффекты для VoiceOver
            applyVoiceOverOptimizations()
        } else {
            // Восстанавливаем полные эффекты
            restoreFullVisualEffects()
        }
        
        updateAccessibilityDescription()
    }
    
    private func applyVoiceOverOptimizations() {
        // Отключаем сложные blur эффекты
        subviews.compactMap { $0 as? UIVisualEffectView }.forEach { effectView in
            effectView.alpha = 0.3
            effectView.effect = UIBlurEffect(style: .light)
        }
        
        // Увеличиваем контраст
        backgroundColor = UIColor.systemBackground.withAlphaComponent(0.95)
        layer.borderWidth = 2
        layer.borderColor = UIColor.label.cgColor
    }
    
    private func restoreFullVisualEffects() {
        subviews.compactMap { $0 as? UIVisualEffectView }.forEach { effectView in
            effectView.alpha = 1.0
            effectView.effect = UIBlurEffect(style: .systemMaterial)
        }
        
        backgroundColor = UIColor.clear
        layer.borderWidth = 0
    }
    
    private func updateAccessibilityDescription() {
        var description = "Карточка"
        
        // Определяем тип содержимого
        let hasButtons = subviews.contains { $0 is UIButton }
        let hasLabels = subviews.contains { $0 is UILabel }
        let hasImages = subviews.contains { $0 is UIImageView }
        
        if hasButtons {
            description += " с кнопками"
        }
        
        if hasImages {
            description += " с изображениями"
        }
        
        if hasLabels {
            description += " с текстовой информацией"
        }
        
        description += ". Полупрозрачный фон с эффектом размытого стекла"
        
        accessibilityLabel = description
        accessibilityHint = "Двойной тап для взаимодействия"
        
        // Группировка дочерних элементов
        accessibilityElements = subviews.filter { view in
            view.isAccessibilityElement || view.subviews.contains { $0.isAccessibilityElement }
        }
    }
    
    // Custom accessibility actions
    override var accessibilityCustomActions: [UIAccessibilityCustomAction]? {
        get {
            var actions: [UIAccessibilityCustomAction] = []
            
            // Добавляем действие для описания эффекта
            let describeEffectAction = UIAccessibilityCustomAction(
                name: "Описать визуальный эффект",
                target: self,
                selector: #selector(describeVisualEffect)
            )
            actions.append(describeEffectAction)
            
            // Добавляем действие для переключения контраста
            let toggleContrastAction = UIAccessibilityCustomAction(
                name: "Переключить высокий контраст",
                target: self,
                selector: #selector(toggleHighContrast)
            )
            actions.append(toggleContrastAction)
            
            return actions
        }
        set { }
    }
    
    @objc private func describeVisualEffect() -> Bool {
        let description = "Данный элемент использует эффект матового стекла с размытием фона и полупрозрачностью для создания глубины интерфейса"
        
        UIAccessibility.post(notification: .announcement, argument: description)
        return true
    }
    
    @objc private func toggleHighContrast() -> Bool {
        let isHighContrast = layer.borderWidth > 0
        
        if isHighContrast {
            restoreFullVisualEffects()
            UIAccessibility.post(notification: .announcement, argument: "Обычный режим включен")
        } else {
            applyVoiceOverOptimizations()
            UIAccessibility.post(notification: .announcement, argument: "Режим высокого контраста включен")
        }
        
        return true
    }
    
    // Поддержка navigation
    override func accessibilityIncrement() {
        // Переход к следующему элементу в группе
        moveToNextAccessibleElement()
    }
    
    override func accessibilityDecrement() {
        // Переход к предыдущему элементу в группе
        moveToPreviousAccessibleElement()
    }
    
    private func moveToNextAccessibleElement() {
        guard let accessibleElements = accessibilityElements,
              let currentIndex = accessibleElements.firstIndex(where: { element in
                return (element as? UIView)?.accessibilityElementIsFocused() == true
              }) else { return }
        
        let nextIndex = (currentIndex + 1) % accessibleElements.count
        let nextElement = accessibleElements[nextIndex]
        
        UIAccessibility.post(notification: .layoutChanged, argument: nextElement)
    }
    
    private func moveToPreviousAccessibleElement() {
        guard let accessibleElements = accessibilityElements,
              let currentIndex = accessibleElements.firstIndex(where: { element in
                return (element as? UIView)?.accessibilityElementIsFocused() == true
              }) else { return }
        
        let previousIndex = currentIndex > 0 ? currentIndex - 1 : accessibleElements.count - 1
        let previousElement = accessibleElements[previousIndex]
        
        UIAccessibility.post(notification: .layoutChanged, argument: previousElement)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}

// Extension для accessibility helpers
extension UIView {
    func addGlassAccessibilitySupport(description: String? = nil) {
        let glassDescription = description ?? "Полупрозрачная область с эффектом размытого стекла"
        
        if !isAccessibilityElement {
            accessibilityLabel = glassDescription
            accessibilityTraits = .none
            isAccessibilityElement = true
        } else {
            // Добавляем к существующему описанию
            let currentLabel = accessibilityLabel ?? ""
            accessibilityLabel = currentLabel.isEmpty ? glassDescription : "\(currentLabel). \(glassDescription)"
        }
        
        // Добавляем gesture для VoiceOver
        let gestureRecognizer = UIAccessibilityCustomAction(
            name: "Описать визуальный эффект",
            target: self,
            selector: #selector(announceGlassEffect)
        )
        
        accessibilityCustomActions = (accessibilityCustomActions ?? []) + [gestureRecognizer]
    }
    
    @objc private func announceGlassEffect() -> Bool {
        let description = "Этот элемент имеет полупрозрачный фон с размытием, создающий эффект матового стекла"
        UIAccessibility.post(notification: .announcement, argument: description)
        return true
    }
}
```

### Android TalkBack Support

```kotlin
class TalkBackGlassView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {
    
    private val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) 
        as AccessibilityManager
    
    private var isTalkBackEnabled: Boolean = false
        get() = accessibilityManager.isEnabled && 
                accessibilityManager.getEnabledAccessibilityServiceList(
                    AccessibilityServiceInfo.FEEDBACK_SPOKEN
                ).isNotEmpty()
    
    init {
        setupTalkBackSupport()
    }
    
    private fun setupTalkBackSupport() {
        // Базовая настройка accessibility
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        
        // Мониторинг TalkBack состояния
        accessibilityManager.addAccessibilityStateChangeListener { enabled ->
            updateTalkBackOptimizations()
        }
        
        updateTalkBackOptimizations()
    }
    
    private fun updateTalkBackOptimizations() {
        if (isTalkBackEnabled) {
            applyTalkBackOptimizations()
        } else {
            restoreFullVisualEffects()
        }
        
        updateContentDescription()
    }
    
    private fun applyTalkBackOptimizations() {
        // Увеличиваем контраст для TalkBack
        setBackgroundColor(ContextCompat.getColor(context, android.R.color.white))
        background?.alpha = 240 // ~94% opacity
        
        // Добавляем видимые границы
        val border = ContextCompat.getDrawable(context, R.drawable.accessibility_border)
        foreground = border
    }
    
    private fun restoreFullVisualEffects() {
        setBackgroundColor(Color.TRANSPARENT)
        foreground = null
    }
    
    private fun updateContentDescription() {
        val description = buildString {
            append("Карточка с эффектом стекла")
            
            // Анализируем содержимое
            val childViews = getAllChildViews()
            val hasButtons = childViews.any { it is Button }
            val hasText = childViews.any { it is TextView }
            val hasImages = childViews.any { it is ImageView }
            
            if (hasButtons) append(", содержит кнопки")
            if (hasText) append(", содержит текст")
            if (hasImages) append(", содержит изображения")
            
            append(". Полупрозрачный фон с размытием")
        }
        
        contentDescription = description
    }
    
    private fun getAllChildViews(): List<View> {
        val views = mutableListOf<View>()
        
        fun collectViews(parent: ViewGroup) {
            for (i in 0 until parent.childCount) {
                val child = parent.getChildAt(i)
                views.add(child)
                if (child is ViewGroup) {
                    collectViews(child)
                }
            }
        }
        
        if (this is ViewGroup) {
            collectViews(this)
        }
        
        return views
    }
    
    // Custom AccessibilityDelegate
    init {
        ViewCompat.setAccessibilityDelegate(this, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(
                host: View,
                info: AccessibilityNodeInfoCompat
            ) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                
                // Устанавливаем тип элемента
                info.className = "GlassCard"
                
                // Добавляем действия
                info.addAction(
                    AccessibilityNodeInfoCompat.AccessibilityActionCompat(
                        AccessibilityNodeInfoCompat.ACTION_CLICK,
                        "Открыть содержимое"
                    )
                )
                
                info.addAction(
                    AccessibilityNodeInfoCompat.AccessibilityActionCompat(
                        AccessibilityNodeInfoCompat.ACTION_LONG_CLICK,
                        "Описать визуальный эффект"
                    )
                )
                
                // Группировка содержимого
                info.isHeading = hasAttribute("data-heading")
                
                // Дополнительные состояния
                if (isSelected) {
                    info.isSelected = true
                }
                
                if (isEnabled) {
                    info.isEnabled = true
                } else {
                    info.removeAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_CLICK)
                }
            }
            
            override fun performAccessibilityAction(
                host: View,
                action: Int,
                args: Bundle?
            ): Boolean {
                return when (action) {
                    AccessibilityNodeInfoCompat.ACTION_CLICK -> {
                        performClick()
                        true
                    }
                    AccessibilityNodeInfoCompat.ACTION_LONG_CLICK -> {
                        announceGlassEffect()
                        true
                    }
                    else -> super.performAccessibilityAction(host, action, args)
                }
            }
        })
    }
    
    private fun announceGlassEffect() {
        val description = "Данный элемент использует эффект матового стекла " +
                         "с размытым полупрозрачным фоном для создания визуальной глубины"
        
        announceForAccessibility(description)
    }
    
    // Helper для атрибутов
    private fun hasAttribute(name: String): Boolean {
        return getTag(name.hashCode()) != null
    }
    
    fun setAttribute(name: String, value: Any) {
        setTag(name.hashCode(), value)
        
        // Обновляем accessibility info при изменении атрибутов
        if (isTalkBackEnabled) {
            updateContentDescription()
        }
    }
}

// Extension функции для TalkBack support
fun View.addGlassAccessibilitySupport(description: String? = null) {
    val glassDescription = description ?: "Полупрозрачная область с эффектом размытого стекла"
    
    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
    
    // Обновляем существующее описание
    val currentDescription = contentDescription?.toString() ?: ""
    contentDescription = if (currentDescription.isEmpty()) {
        glassDescription
    } else {
        "$currentDescription. $glassDescription"
    }
}

fun View.announceAccessibilityChange(message: String) {
    if (context.getSystemService(Context.ACCESSIBILITY_SERVICE) is AccessibilityManager) {
        announceForAccessibility(message)
    }
}

// Глобальный TalkBack detector
object TalkBackDetector {
    fun isTalkBackEnabled(context: Context): Boolean {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) 
            as AccessibilityManager
        
        return accessibilityManager.isEnabled && 
               accessibilityManager.getEnabledAccessibilityServiceList(
                   AccessibilityServiceInfo.FEEDBACK_SPOKEN
               ).isNotEmpty()
    }
    
    fun registerTalkBackStateListener(
        context: Context, 
        listener: (Boolean) -> Unit
    ): AccessibilityManager.AccessibilityStateChangeListener {
        val accessibilityManager = context.getSystemService(Context.ACCESSIBILITY_SERVICE) 
            as AccessibilityManager
        
        val stateListener = AccessibilityManager.AccessibilityStateChangeListener { enabled ->
            listener(enabled && accessibilityManager.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_SPOKEN
            ).isNotEmpty())
        }
        
        accessibilityManager.addAccessibilityStateChangeListener(stateListener)
        return stateListener
    }
}
```

---

## High Contrast Implementation

### CSS High Contrast Support

```css
/* Полная поддержка high contrast modes */

/* Windows High Contrast Mode */
@media (prefers-contrast: high) {
  .glass-element {
    /* Отключаем blur эффекты */
    backdrop-filter: none !important;
    filter: none !important;
    
    /* Максимальный контраст */
    background: rgba(255, 255, 255, 0.98) !important;
    border: 2px solid #000000 !important;
    color: #000000 !important;
    
    /* Убираем тени */
    box-shadow: none !important;
    text-shadow: none !important;
  }
  
  /* Темная high contrast тема */
  .glass-element.dark-theme {
    background: rgba(0, 0, 0, 0.98) !important;
    border: 2px solid #ffffff !important;
    color: #ffffff !important;
  }
  
  /* Focus indicators становятся более контрастными */
  .glass-element:focus {
    outline: 4px solid #0000ff !important;
    outline-offset: 2px !important;
  }
  
  /* Кнопки в high contrast mode */
  .glass-button {
    background: ButtonFace !important;
    color: ButtonText !important;
    border: 2px solid ButtonText !important;
  }
  
  .glass-button:hover {
    background: Highlight !important;
    color: HighlightText !important;
  }
  
  .glass-button:active {
    background: ActiveCaption !important;
    color: CaptionText !important;
  }
}

/* Windows specific high contrast detection */
@media screen and (-ms-high-contrast: active) {
  .glass-element {
    background: window !important;
    color: windowText !important;
    border: 1px solid windowText !important;
    backdrop-filter: none !important;
  }
  
  .glass-button {
    background: buttonFace !important;
    color: buttonText !important;
    border: 1px solid buttonText !important;
  }
}

/* Forced colors mode (более новый стандарт) */
@media (forced-colors: active) {
  .glass-element {
    background: Canvas !important;
    color: CanvasText !important;
    border: 1px solid CanvasText !important;
    backdrop-filter: none !important;
    forced-color-adjust: none;
  }
  
  .glass-button {
    background: ButtonFace !important;
    color: ButtonText !important;
    border: 1px solid ButtonText !important;
  }
  
  .glass-button:focus {
    outline: 2px solid Highlight !important;
  }
}

/* Custom high contrast toggle */
.high-contrast-mode {
  .glass-element {
    background: #ffffff !important;
    color: #000000 !important;
    border: 3px solid #000000 !important;
    backdrop-filter: none !important;
    filter: contrast(2) !important;
  }
  
  .glass-element.inverted {
    background: #000000 !important;
    color: #ffffff !important;
    border: 3px solid #ffffff !important;
  }
}
```

### JavaScript High Contrast Manager

```javascript
class HighContrastManager {
  constructor() {
    this.isHighContrastActive = false;
    this.userPreference = 'auto'; // 'auto', 'high', 'normal'
    
    this.setupHighContrastDetection();
    this.createToggleControl();
  }
  
  setupHighContrastDetection() {
    // Медиа-запросы для автоопределения
    const queries = [
      window.matchMedia('(prefers-contrast: high)'),
      window.matchMedia('(prefers-contrast: more)'),
      window.matchMedia('(-ms-high-contrast: active)'),
      window.matchMedia('(forced-colors: active)')
    ];
    
    queries.forEach(query => {
      query.addEventListener('change', () => {
        this.updateHighContrastState();
      });
    });
    
    // Проверяем localStorage
    const saved = localStorage.getItem('liquid-glass-high-contrast');
    if (saved) {
      this.userPreference = saved;
    }
    
    this.updateHighContrastState();
  }
  
  updateHighContrastState() {
    const systemPreference = this.detectSystemHighContrast();
    
    switch (this.userPreference) {
      case 'high':
        this.isHighContrastActive = true;
        break;
      case 'normal':
        this.isHighContrastActive = false;
        break;
      default: // 'auto'
        this.isHighContrastActive = systemPreference;
    }
    
    this.applyHighContrastState();
  }
  
  detectSystemHighContrast() {
    const queries = [
      '(prefers-contrast: high)',
      '(prefers-contrast: more)',
      '(-ms-high-contrast: active)',
      '(forced-colors: active)'
    ];
    
    return queries.some(query => window.matchMedia(query).matches);
  }
  
  applyHighContrastState() {
    const root = document.documentElement;
    
    if (this.isHighContrastActive) {
      root.classList.add('high-contrast-mode');
      root.style.setProperty('--glass-backdrop-filter', 'none');
      root.style.setProperty('--glass-background', 'rgba(255, 255, 255, 0.98)');
      root.style.setProperty('--glass-border', '2px solid #000000');
      root.style.setProperty('--glass-text-color', '#000000');
    } else {
      root.classList.remove('high-contrast-mode');
      root.style.removeProperty('--glass-backdrop-filter');
      root.style.removeProperty('--glass-background');
      root.style.removeProperty('--glass-border');
      root.style.removeProperty('--glass-text-color');
    }
    
    // Уведомляем компоненты об изменении
    this.dispatchContrastChangeEvent();
  }
  
  dispatchContrastChangeEvent() {
    const event = new CustomEvent('high-contrast-changed', {
      detail: {
        isActive: this.isHighContrastActive,
        preference: this.userPreference
      }
    });
    
    window.dispatchEvent(event);
  }
  
  setUserPreference(preference) {
    this.userPreference = preference;
    localStorage.setItem('liquid-glass-high-contrast', preference);
    this.updateHighContrastState();
  }
  
  createToggleControl() {
    const control = document.createElement('div');
    control.className = 'high-contrast-control';
    control.innerHTML = `
      <label for="high-contrast-select">Контрастность:</label>
      <select id="high-contrast-select" aria-label="Выберите режим контрастности">
        <option value="auto">Автоматически</option>
        <option value="normal">Обычный</option>
        <option value="high">Высокий контраст</option>
      </select>
    `;
    
    const select = control.querySelector('select');
    select.value = this.userPreference;
    select.addEventListener('change', (e) => {
      this.setUserPreference(e.target.value);
    });
    
    // Добавляем в accessibility панель, если она существует
    const accessibilityPanel = document.querySelector('.accessibility-controls');
    if (accessibilityPanel) {
      accessibilityPanel.appendChild(control);
    }
  }
  
  // API для компонентов
  getContrastState() {
    return {
      isActive: this.isHighContrastActive,
      preference: this.userPreference,
      systemDetected: this.detectSystemHighContrast()
    };
  }
}

// Глобальная инициализация
const highContrastManager = new HighContrastManager();

// Utility функции для компонентов
window.liquidGlass = window.liquidGlass || {};
window.liquidGlass.highContrast = {
  isActive: () => highContrastManager.isHighContrastActive,
  setPreference: (pref) => highContrastManager.setUserPreference(pref),
  getState: () => highContrastManager.getContrastState()
};
```

---

## Reduce Motion Implementation

### CSS Reduce Motion Support

```css
/* Полная поддержка reduce motion */

/* Основное правило для отключения анимаций */
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
  
  /* Специфично для glass элементов */
  .glass-element {
    transition: none !important;
    animation: none !important;
    transform: none !important;
  }
  
  /* Отключаем parallax эффекты */
  .glass-parallax {
    transform: none !important;
  }
  
  /* Убираем hover анимации */
  .glass-element:hover {
    transition: none !important;
    animation: none !important;
  }
  
  /* Статичные альтернативы для анимированных состояний */
  .glass-loading {
    animation: none !important;
  }
  
  .glass-loading::after {
    content: "Загрузка...";
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
}

/* Reduce motion с сохранением essential анимаций */
@media (prefers-reduced-motion: reduce) {
  /* Допускаем fade transitions для accessibility */
  .glass-fade-essential {
    transition: opacity 0.15s ease !important;
  }
  
  /* Допускаем важные UI state changes */
  .glass-state-change {
    transition: background-color 0.1s ease !important;
  }
  
  /* Focus indicators остаются анимированными */
  .glass-element:focus {
    transition: outline-color 0.15s ease !important;
  }
}
```

### JavaScript Reduce Motion Manager

```javascript
class ReduceMotionManager {
  constructor() {
    this.isReduceMotionActive = false;
    this.userPreference = 'auto'; // 'auto', 'reduce', 'normal'
    this.essentialAnimations = new Set();
    
    this.setupReduceMotionDetection();
    this.setupAnimationRegistry();
  }
  
  setupReduceMotionDetection() {
    // Медиа-запрос для системных предпочтений
    const reduceMotionQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    reduceMotionQuery.addEventListener('change', () => {
      this.updateReduceMotionState();
    });
    
    // Загружаем пользовательские предпочтения
    const saved = localStorage.getItem('liquid-glass-reduce-motion');
    if (saved) {
      this.userPreference = saved;
    }
    
    this.updateReduceMotionState();
  }
  
  updateReduceMotionState() {
    const systemPreference = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    
    switch (this.userPreference) {
      case 'reduce':
        this.isReduceMotionActive = true;
        break;
      case 'normal':
        this.isReduceMotionActive = false;
        break;
      default: // 'auto'
        this.isReduceMotionActive = systemPreference;
    }
    
    this.applyReduceMotionState();
  }
  
  applyReduceMotionState() {
    const root = document.documentElement;
    
    if (this.isReduceMotionActive) {
      root.classList.add('reduce-motion');
      this.disableNonEssentialAnimations();
    } else {
      root.classList.remove('reduce-motion');
      this.enableAllAnimations();
    }
    
    this.dispatchMotionChangeEvent();
  }
  
  disableNonEssentialAnimations() {
    const style = document.createElement('style');
    style.id = 'reduce-motion-override';
    style.textContent = `
      .reduce-motion * {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
      }
      
      .reduce-motion .glass-element:not(.essential-animation) {
        animation: none !important;
        transition: none !important;
      }
      
      .reduce-motion .glass-parallax {
        transform: none !important;
      }
    `;
    
    // Удаляем предыдущий стиль, если есть
    const existing = document.getElementById('reduce-motion-override');
    if (existing) {
      existing.remove();
    }
    
    document.head.appendChild(style);
  }
  
  enableAllAnimations() {
    const existing = document.getElementById('reduce-motion-override');
    if (existing) {
      existing.remove();
    }
  }
  
  setupAnimationRegistry() {
    // Реестр для управления анимациями
    this.animations = new Map();
    
    // Наблюдатель за новыми анимированными элементами
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            this.registerElementAnimations(node);
          }
        });
      });
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  registerElementAnimations(element) {
    // Проверяем анимации элемента
    const computedStyle = window.getComputedStyle(element);
    const hasAnimations = computedStyle.animationName !== 'none' ||
                         computedStyle.transitionProperty !== 'none';
    
    if (hasAnimations) {
      const animationId = `anim-${Date.now()}-${Math.random()}`;
      this.animations.set(animationId, {
        element,
        originalAnimations: {
          animationName: computedStyle.animationName,
          animationDuration: computedStyle.animationDuration,
          transitionProperty: computedStyle.transitionProperty,
          transitionDuration: computedStyle.transitionDuration
        },
        isEssential: element.classList.contains('essential-animation')
      });
      
      element.dataset.animationId = animationId;
      
      if (this.isReduceMotionActive) {
        this.disableElementAnimation(element, animationId);
      }
    }
  }
  
  disableElementAnimation(element, animationId) {
    const animation = this.animations.get(animationId);
    if (!animation || animation.isEssential) return;
    
    element.style.animationDuration = '0.01ms';
    element.style.animationIterationCount = '1';
    element.style.transitionDuration = '0.01ms';
  }
  
  enableElementAnimation(element, animationId) {
    const animation = this.animations.get(animationId);
    if (!animation) return;
    
    element.style.animationDuration = '';
    element.style.animationIterationCount = '';
    element.style.transitionDuration = '';
  }
  
  markAsEssential(element) {
    element.classList.add('essential-animation');
    const animationId = element.dataset.animationId;
    
    if (animationId && this.animations.has(animationId)) {
      this.animations.get(animationId).isEssential = true;
      
      if (this.isReduceMotionActive) {
        this.enableElementAnimation(element, animationId);
      }
    }
  }
  
  createSafeAnimation(element, keyframes, options = {}) {
    if (this.isReduceMotionActive && !options.essential) {
      // Возвращаем завершенную "анимацию"
      return {
        finished: Promise.resolve(),
        cancel: () => {},
        finish: () => {},
        pause: () => {},
        play: () => {}
      };
    }
    
    // Стандартная Web Animations API
    return element.animate(keyframes, options);
  }
  
  dispatchMotionChangeEvent() {
    const event = new CustomEvent('reduce-motion-changed', {
      detail: {
        isActive: this.isReduceMotionActive,
        preference: this.userPreference
      }
    });
    
    window.dispatchEvent(event);
  }
  
  setUserPreference(preference) {
    this.userPreference = preference;
    localStorage.setItem('liquid-glass-reduce-motion', preference);
    this.updateReduceMotionState();
  }
  
  // Public API
  shouldReduceMotion() {
    return this.isReduceMotionActive;
  }
  
  createMotionSafeTransition(property, duration = '300ms', easing = 'ease') {
    return this.isReduceMotionActive ? 'none' : `${property} ${duration} ${easing}`;
  }
}

// Глобальная инициализация
const reduceMotionManager = new ReduceMotionManager();

// Utility функции
window.liquidGlass = window.liquidGlass || {};
window.liquidGlass.motion = {
  shouldReduce: () => reduceMotionManager.shouldReduceMotion(),
  createSafeAnimation: (el, kf, opt) => reduceMotionManager.createSafeAnimation(el, kf, opt),
  createSafeTransition: (prop, dur, ease) => reduceMotionManager.createMotionSafeTransition(prop, dur, ease),
  markAsEssential: (el) => reduceMotionManager.markAsEssential(el),
  setPreference: (pref) => reduceMotionManager.setUserPreference(pref)
};
```

---

## Продолжение в следующих документах

Это первая часть технической реализации accessibility. Остальные разделы:

### 📋 **Следующие части:**
- **Keyboard Navigation** - управление с клавиатуры
- **Platform Accessibility APIs** - iOS, Android, Web APIs
- **ARIA и семантика** - правильная разметка

### 🔗 **Связанные документы:**
- [Liquid-Glass-Accessibility.md] - Основы и принципы ✅
- [Liquid-Glass-Accessibility-Testing.md] - Тестирование доступности (скоро)

Техническая реализация accessibility требует детального подхода на каждой платформе для обеспечения полной инклюзивности! ♿️🚀